<?php
/**
 * Plugin Name:  SEO Control Layer
 * Description:  Native SEO control layer for the remediation pipeline.
 *               Manages title/meta, schema injection, image ALT text, llms.txt,
 *               XML sitemap, cache purge, and self-updates. Reads legacy rank_math_*
 *               post-meta as a migration fallback; RankMath is not required.
 * Version:      3.11.0
 * Author:       AMS
 * Author URI:   https://adventuremarketingsolutions.com/
 * Requires PHP: 7.4
 * Requires WP:  5.9
 * Tested up to: 7.0
 * Text Domain:  rankrocket-seo
 *
 * @package RankRocket_SEO
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'RMB_VERSION', '3.11.0' );
define( 'RMB_PLUGIN_FILE', __FILE__ );
define( 'RMB_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'RMB_SNIPPETS_KEY', 'rmb_managed_snippets' );
define( 'RMB_UPDATE_URL', 'https://raw.githubusercontent.com/PenZenMaster/rankmath-rest-bridge/main/update-manifest.json' );

// Native post-meta keys written by this plugin.
define(
	'RR_SEO_META_KEYS',
	array(
		'title'               => 'rr_seo_title',
		'description'         => 'rr_seo_description',
		'focus_keyword'       => 'rr_seo_focus_keyword',
		'robots'              => 'rr_seo_robots',
		'og_title'            => 'rr_seo_og_title',
		'og_description'      => 'rr_seo_og_description',
		'og_image'            => 'rr_seo_og_image',
		'canonical'           => '_rr_seo_canonical',
		'twitter_card'        => '_rr_seo_twitter_card',
		'twitter_title'       => '_rr_seo_twitter_title',
		'twitter_description' => '_rr_seo_twitter_description',
		'twitter_image'       => '_rr_seo_twitter_image',
	)
);

// Legacy RankMath keys — read-only migration fallback when native key is absent.
define(
	'RR_SEO_LEGACY_META_KEYS',
	array(
		'title'               => 'rank_math_title',
		'description'         => 'rank_math_description',
		'focus_keyword'       => 'rank_math_focus_keyword',
		'robots'              => 'rank_math_robots',
		'og_title'            => 'rank_math_og_title',
		'og_description'      => 'rank_math_og_description',
		'og_image'            => 'rank_math_og_image',
		'canonical'           => 'rank_math_canonical_url',
		'twitter_card'        => 'rank_math_twitter_card_type',
		'twitter_title'       => 'rank_math_twitter_title',
		'twitter_description' => 'rank_math_twitter_description',
		'twitter_image'       => 'rank_math_twitter_image',
	)
);

// Schema + audit log meta keys.
define( 'RR_SCHEMA_META_KEY', '_rrseo_schema_graph' );
define( 'RR_CHANGE_LOG_KEY', '_rrseo_change_log' );

// Per-post list of schema.org @type names to strip from third-party (non-
// plugin) JSON-LD found in <head> — issue #23 schema hygiene.
define( 'RR_SCHEMA_STRIP_KEY', '_rrseo_schema_strip_third_party' );

// HTML comment markers bracketing this plugin's own schema <script> block
// so rr_schema_hygiene_strip_html() never strips its own output.
define( 'RR_SCHEMA_HYGIENE_MARKER_START', '<!-- rrseo-schema-graph -->' );
define( 'RR_SCHEMA_HYGIENE_MARKER_END', '<!-- /rrseo-schema-graph -->' );

// Validation allowlists.
define( 'RR_ALLOWED_POST_TYPES', array( 'post', 'page', 'product' ) );

define(
	'RR_ALLOWED_ROBOTS',
	array(
		'index',
		'noindex',
		'follow',
		'nofollow',
		'noarchive',
		'noodp',
		'noimageindex',
		'nosnippet',
	)
);

define(
	'RR_ALLOWED_SCHEMA_TYPES',
	array(
		'Article',
		'BlogPosting',
		'NewsArticle',
		'WebPage',
		'FAQPage',
		'HowTo',
		'Product',
		'LocalBusiness',
		'Organization',
		'Person',
		'Event',
		'Recipe',
		'VideoObject',
		'ImageObject',
		'BreadcrumbList',
		'Review',
		'Service',
	)
);

// Hard limits for AI-generated content.
define( 'RR_TITLE_MAX', 120 ); // Chars; hard error above this.
define( 'RR_TITLE_WARN_MAX', 60 ); // Chars; warning above this.
define( 'RR_TITLE_WARN_MIN', 30 ); // Chars; warning below this.
define( 'RR_DESC_MAX', 320 ); // Chars; hard error above this.
define( 'RR_DESC_WARN_MAX', 160 ); // Chars; warning above this.
define( 'RR_DESC_WARN_MIN', 50 ); // Chars; warning below this.
define( 'RR_BATCH_MAX', 100 ); // Default batch cap; override via rrseo_batch_max filter.

// llms.txt config option key (replaces legacy 'rmb_llms_config'; both are read during migration).
define( 'RR_LLMS_CONFIG_KEY', 'rrseo_llms_config' );

// Sitemap / discovery exclusion rules option key (term IDs, term slugs, taxonomies, post slugs).
define( 'RR_SITEMAP_EXCLUSIONS_KEY', 'rrseo_sitemap_exclusions' );

// Performance module option keys (G-04 dequeue rules, G-05 defer handles).
define( 'RR_PERF_DEQUEUE_KEY', 'rrseo_perf_dequeue_rules' );
define( 'RR_PERF_DEFER_KEY', 'rrseo_perf_defer_handles' );

// Media upload meta keys + validation allowlists (issue #14).
define( 'RR_MEDIA_SOURCE_META_KEY', '_rrseo_media_source' );
define( 'RR_MEDIA_PLACEHOLDER_META_KEY', '_rrseo_media_placeholder' );
define( 'RR_MEDIA_MAX_BYTES', 10 * 1024 * 1024 ); // 10 MB hard cap.

define(
	'RR_MEDIA_ALLOWED_MIME_TYPES',
	array(
		'image/jpeg',
		'image/png',
		'image/webp',
		'image/avif',
	)
);

define(
	'RR_MEDIA_ALLOWED_SOURCES',
	array(
		'ai_placeholder',
		'client_supplied',
		'reused',
		'stock',
		'screenshot',
	)
);

// Elementor set-data meta keys + top-level shape allowlist (issue #12).
define( 'RR_ELEMENTOR_DATA_META_KEY', '_elementor_data' );
define( 'RR_ELEMENTOR_EDIT_MODE_META_KEY', '_elementor_edit_mode' );
define( 'RR_ELEMENTOR_TEMPLATE_TYPE_META_KEY', '_elementor_template_type' );
define( 'RR_ELEMENTOR_PAGE_SETTINGS_META_KEY', '_elementor_page_settings' );

define( 'RR_ELEMENTOR_ALLOWED_TOP_LEVEL_TYPES', array( 'section', 'container' ) );

// Best-effort list of Elementor (free) core widgetType values, used only to
// produce a non-blocking warning when a payload references a widget that
// might require Elementor Pro or a third-party addon. Not authoritative --
// override via the rrseo_elementor_core_widget_types filter.
define(
	'RR_ELEMENTOR_CORE_WIDGET_TYPES',
	array(
		'heading',
		'image',
		'text-editor',
		'video',
		'button',
		'divider',
		'spacer',
		'image-box',
		'icon-box',
		'icon',
		'social-icons',
		'image-gallery',
		'image-carousel',
		'icon-list',
		'counter',
		'progress',
		'testimonial',
		'tabs',
		'accordion',
		'toggle',
		'alert',
		'audio',
		'shortcode',
		'html',
		'menu-anchor',
		'sidebar',
		'google_maps',
		'star-rating',
		'text-path',
		'read-more',
	)
);

// Whitelist of WordPress conditional functions accepted in dequeue rule when_not arrays.
// Validated at write time (REST handler) and at apply time (wp_enqueue_scripts hook).
define(
	'RR_PERF_ALLOWED_CONDITIONALS',
	array(
		'is_front_page',
		'is_home',
		'is_singular',
		'is_page',
		'is_single',
		'is_archive',
		'is_category',
		'is_tag',
		'is_tax',
		'is_search',
		'is_404',
		'is_woocommerce',
		'is_cart',
		'is_checkout',
		'is_account_page',
		'is_product',
		'is_product_category',
		'is_product_tag',
		'is_shop',
		'is_admin',
	)
);

/**
 * Returns the effective batch size cap for bulk REST endpoints.
 *
 * Filterable via the rrseo_batch_max filter so individual sites can raise or
 * lower the limit without modifying plugin code.
 *
 * Example (wp-config.php or a mu-plugin):
 *   add_filter( 'rrseo_batch_max', function() { return 200; } );
 *
 * @return int
 */
function rrseo_batch_max(): int {
	return (int) apply_filters( 'rrseo_batch_max', RR_BATCH_MAX );
}

/**
 * Busts the WordPress object cache for a single option after a write.
 *
 * Persistent object caches (LiteSpeed, Redis, Memcached) can serve stale
 * data after update_option() because they cache both the individual option
 * and the alloptions bundle. Deleting both entries forces a DB read on the
 * next get_option() call in the same or subsequent requests.
 *
 * @param string $option_key The option name passed to update_option().
 */
function rrseo_bust_option_cache( string $option_key ): void {
	wp_cache_delete( $option_key, 'options' );
	wp_cache_delete( 'alloptions', 'options' );
}

/**
 * Purges page-level cache entries for specific REST endpoints.
 *
 * Fires LiteSpeed Cache's URL purge action (and future equivalents for other
 * supported cache plugins) so that page-cached GET responses for these endpoints
 * are invalidated immediately after a write, not just after a full cache flush.
 *
 * @param string[] $endpoints Endpoint slugs relative to rankrocket-seo/v1/,
 *                            e.g. array( 'status', 'snippets' ).
 */
function rrseo_purge_rest_cache( array $endpoints ): void {
	foreach ( $endpoints as $endpoint ) {
		$url = get_rest_url( null, 'rankrocket-seo/v1/' . ltrim( $endpoint, '/' ) );
		do_action( 'litespeed_purge_url', $url );
	}
}

// robots.txt directive config option key.
define( 'RR_ROBOTS_CONFIG_KEY', 'rrseo_robots_config' );

// Post meta key for per-post llms.txt section override (set via POST /update or /meta/bulk-update).
define( 'META_LLMS_SECTION', '_rrseo_llms_section' );


// ── Canonical URL Set helper ──────────────────────────────────────────────────
// Loaded unconditionally — required by sitemaps, llms.txt, and REST preview endpoints.
require_once RMB_PLUGIN_DIR . 'includes/class-rrseo-canonical.php';

// ── llms.txt generator (section classifier, business_facts, renderer) ─────────
require_once RMB_PLUGIN_DIR . 'includes/class-rrseo-llms.php';

// ── AEO/GEO audit data layer (canonical preview, readiness, entity, schema, sync) ──
require_once RMB_PLUGIN_DIR . 'includes/class-rrseo-aeo-geo.php';

// ── v3.0 Bite 1: observation endpoints (heading hierarchy, links, ALT, schema, llms drift) ──
require_once RMB_PLUGIN_DIR . 'includes/class-rrseo-observe.php';

// ── v3.0 Bite 2: typed action engine (dry-run/execute, whitelisted actions) ───
require_once RMB_PLUGIN_DIR . 'includes/class-rrseo-actions.php';

// ── v3.9.0: REST-managed redirects (issue #21 Stage 1) ─────────────────────
require_once RMB_PLUGIN_DIR . 'includes/class-rrseo-redirects.php';

// ── Schema hygiene: strip third-party JSON-LD (issue #23) ──────────────────
require_once RMB_PLUGIN_DIR . 'includes/class-rrseo-schema-hygiene.php';


// ── Admin UI (loaded only in the WordPress admin; zero front-end cost) ─────────
if ( is_admin() ) {
	require_once RMB_PLUGIN_DIR . 'includes/class-rrseo-white-label.php';
	require_once RMB_PLUGIN_DIR . 'includes/class-rrseo-admin.php';
	require_once RMB_PLUGIN_DIR . 'includes/class-rrseo-metabox.php';
	new RRSEO_White_Label();
	new RRSEO_Admin();
	new RRSEO_MetaBox();

	add_filter(
		'plugin_row_meta',
		function ( $links, $plugin_file ) {
			if ( plugin_basename( RMB_PLUGIN_FILE ) !== $plugin_file ) {
				return $links;
			}
			foreach ( $links as $key => $link ) {
				if ( false !== strpos( $link, 'plugin-install.php' ) ) {
					unset( $links[ $key ] );
				}
			}
			return $links;
		},
		10,
		2
	);
}


// ── Auto-update via plugin-update-checker ─────────────────────────────────────
// Stored globally so rmb_check_updates() can trigger an immediate manifest
// fetch without contacting WordPress.org (this is a private plugin).
add_action(
	'init',
	function () {
		$puc_loader = RMB_PLUGIN_DIR . 'vendor/plugin-update-checker/plugin-update-checker.php';
		if ( file_exists( $puc_loader ) ) {
			require_once $puc_loader;
			$GLOBALS['rrseo_puc_checker'] = YahnisElsts\PluginUpdateChecker\v5\PucFactory::buildUpdateChecker(
				RMB_UPDATE_URL,
				RMB_PLUGIN_FILE,
				'rankmath-rest-bridge', // GitHub repo slug; must match repo folder name.
				// Check period in hours — filterable so staging can reduce to 1h for testing.
				(int) apply_filters( 'rrseo_puc_check_period_hours', 12 )
			);
		}
	}
);


// ── Activation hook ──────────────────────────────────────────────────────────
// On activation (including upgrades), sync any existing rrseo_robots_txt content
// to a physical file at the webroot so it persists even when the plugin is inactive.
register_activation_hook(
	RMB_PLUGIN_FILE,
	function () {
		$content = (string) get_option( 'rrseo_robots_txt', '' );
		if ( '' !== $content && ! file_exists( ABSPATH . 'robots.txt' ) ) {
			// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
			file_put_contents( ABSPATH . 'robots.txt', $content );
		}
	}
);

// ── Capability cleanup ────────────────────────────────────────────────────────
// v3.0.0 removed POST /snippets/replace-all. The capability that guarded it
// (granted to administrator since v2.3.1) is persisted in the DB with the
// role, so revoke it once here; the check keeps the write from repeating.
add_action(
	'init',
	function () {
		$role = get_role( 'administrator' );
		if ( $role && $role->has_cap( 'rrseo_replace_all_snippets' ) ) {
			$role->remove_cap( 'rrseo_replace_all_snippets' );
		}
	}
);

// ── Post meta registration ────────────────────────────────────────────────────
// Declares all plugin-owned meta keys to WordPress core: type coercion,
// sanitize callbacks, show_in_rest visibility, and auth_callback. Using ''
// as $object_type registers for all post types in one pass.
add_action(
	'init',
	function () {
		$url_fields = array( 'og_image', 'canonical', 'twitter_image' );
		$auth       = function () {
			return current_user_can( 'manage_options' );
		};

		foreach ( RR_SEO_META_KEYS as $param => $meta_key ) {
			if ( in_array( $param, $url_fields, true ) ) {
				$sanitize = 'esc_url_raw';
			} elseif ( 'twitter_card' === $param ) {
				$sanitize = 'sanitize_key';
			} else {
				$sanitize = 'sanitize_text_field';
			}
			register_post_meta(
				'',
				$meta_key,
				array(
					'type'              => 'string',
					'single'            => true,
					'show_in_rest'      => true,
					'sanitize_callback' => $sanitize,
					'auth_callback'     => $auth,
				)
			);
		}

		// Per-post llms.txt section classification.
		register_post_meta(
			'',
			META_LLMS_SECTION,
			array(
				'type'              => 'string',
				'single'            => true,
				'show_in_rest'      => true,
				'sanitize_callback' => 'sanitize_text_field',
				'auth_callback'     => $auth,
			)
		);

		// RR_SCHEMA_META_KEY and RR_CHANGE_LOG_KEY are intentionally NOT
		// registered. Both store arrays; a registered sanitize_callback runs
		// on every update_post_meta() and the string sanitizers flatten
		// arrays to '', silently discarding the value (issue #3). The keys
		// are underscore-prefixed (protected meta) and validated upstream
		// via rr_validate_schema() / rr_audit_log() before every write.
	}
);


// ── Output managed snippets ───────────────────────────────────────────────────
// Hook + default priority per snippet location. The defaults preserve
// pre-v3.2.0 behavior for snippets without a stored priority:
//
// head      → wp_head:20
// body_open → wp_body_open:10
// footer    → wp_footer:10
//
// Snippets may override with an explicit priority (0-10000, issue #7) so
// perf-remediation snippets (preload/onload swaps, critical CSS) can emit
// before theme-enqueued styles at wp_head:5-10. Priorities 0-1 interleave
// with the plugin's own canonical / Twitter / robots emission (wp_head:1);
// same-priority callbacks run in registration order.
//
// rmb_output_snippets() short-circuits on admin / REST / AJAX requests and on
// the rrseo_emit_snippets option, so the hooks are cheap when disabled.
define(
	'RR_SNIPPET_LOCATION_HOOKS',
	array(
		'head'      => array( 'wp_head', 20 ),
		'body_open' => array( 'wp_body_open', 10 ),
		'footer'    => array( 'wp_footer', 10 ),
	)
);
define( 'RR_SNIPPET_PRIORITY_MAX', 10000 );

/**
 * Returns a snippet's effective emission priority for its location.
 *
 * @param array  $snippet  Stored snippet array.
 * @param string $location Snippet location (head, body_open, footer).
 * @return int Stored priority when present, else the location default.
 */
function rmb_snippet_priority( array $snippet, $location ) {
	if ( isset( $snippet['priority'] ) && is_numeric( $snippet['priority'] ) ) {
		return (int) $snippet['priority'];
	}
	return isset( RR_SNIPPET_LOCATION_HOOKS[ $location ] ) ? RR_SNIPPET_LOCATION_HOOKS[ $location ][1] : 10;
}

/**
 * Decodes a base64 snippet body from a write request (issue #8).
 *
 * Transport encoding only: some WAF/CDN rulesets (Cloudflare managed XSS
 * rules) 403 any request body containing on*= attribute patterns, which
 * blocks legitimate preload/onload perf snippets. Callers may send the body
 * base64-encoded as code_b64; it is decoded here and stored/emitted exactly
 * like a plain-text body. Authorization and storage semantics are unchanged.
 *
 * @param mixed $value Raw code_b64 request value.
 * @return string|null Decoded UTF-8 body, or null when the value is not
 *                     valid base64 or does not decode to valid UTF-8.
 */
function rr_decode_snippet_b64( $value ) {
	if ( ! is_string( $value ) || '' === $value ) {
		return null;
	}
	// phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode -- transport decoding for admin-authenticated snippet writes (issue #8); strict mode + UTF-8 check below, result stored as plain HTML.
	$decoded = base64_decode( $value, true );
	if ( false === $decoded || '' === $decoded ) {
		return null;
	}
	if ( 1 !== preg_match( '//u', $decoded ) ) {
		return null;
	}
	return $decoded;
}

/**
 * Validates a snippet priority value from a write request.
 *
 * @param mixed $value Raw request value.
 * @return int|null Normalized integer priority, or null when invalid.
 */
function rr_validate_snippet_priority( $value ) {
	if ( is_bool( $value ) ) {
		return null;
	}
	if ( ! is_int( $value ) && ! ( is_string( $value ) && 1 === preg_match( '/^\d+$/', $value ) ) ) {
		return null;
	}
	$int = (int) $value;
	return ( $int >= 0 && $int <= RR_SNIPPET_PRIORITY_MAX ) ? $int : null;
}

/**
 * Registers one emitter per (location, priority) bucket found in the snippet
 * store, plus the three location defaults. Runs at plugin load so custom
 * priorities land before WordPress fires wp_head.
 *
 * @return void
 */
function rmb_register_snippet_emitters() {
	$buckets = array();
	foreach ( RR_SNIPPET_LOCATION_HOOKS as $location => $hook_pair ) {
		$buckets[ $location ] = array( $hook_pair[1] => true );
	}

	$snippets = get_option( RMB_SNIPPETS_KEY, array() );
	if ( is_array( $snippets ) ) {
		foreach ( $snippets as $snippet ) {
			if ( ! is_array( $snippet ) ) {
				continue;
			}
			$location = isset( $snippet['location'] ) ? (string) $snippet['location'] : 'footer';
			if ( ! isset( RR_SNIPPET_LOCATION_HOOKS[ $location ] ) ) {
				continue;
			}
			$buckets[ $location ][ rmb_snippet_priority( $snippet, $location ) ] = true;
		}
	}

	foreach ( $buckets as $location => $priorities ) {
		$hook = RR_SNIPPET_LOCATION_HOOKS[ $location ][0];
		foreach ( array_keys( $priorities ) as $priority ) {
			add_action(
				$hook,
				function () use ( $location, $priority ) {
					rmb_output_snippets( $location, $priority );
				},
				$priority
			);
		}
	}
}
rmb_register_snippet_emitters();

/**
 * Outputs active managed snippets for the given location.
 *
 * Storage lives in the `rmb_managed_snippets` option (an associative array
 * keyed by snippet id, see RMB_SNIPPETS_KEY). Snippet bodies are written by
 * authenticated administrators via /snippets and are emitted verbatim — they
 * are HTML/JSON-LD <script> blocks that must not be escaped through
 * wp_kses_post or esc_html.
 *
 * Supported `location` values: `head`, `body_open`, `footer`. Unknown values
 * are silently skipped.
 *
 * Supported `display_on` values:
 *   sitewide           → every front-end page (also: all, entire_website)
 *   home               → is_front_page() || is_home() (also: homepage, front_page)
 *   singular           → is_singular() (any single post/page/CPT)
 *   all_pages          → is_page() (legacy)
 *   all_posts          → is_single() (legacy)
 *   page_id:NNN        → singular page whose queried object id is NNN
 *   post_type:slug     → is_singular( 'slug' )
 *   NNN (bare integer) → singular page whose queried object id is NNN (legacy)
 *
 * Unknown display_on values are silently skipped to keep the renderer
 * forward-compatible with new RankRocket targeting values.
 *
 * Each call emits one (location, priority) bucket: snippets whose effective
 * priority (stored `priority`, else the location default) matches $priority.
 * Buckets are registered by rmb_register_snippet_emitters().
 *
 * @param string   $location One of: head, body_open, footer.
 * @param int|null $priority Priority bucket to emit; null means the
 *                           location's default bucket (pre-v3.2.0 behavior).
 * @return void
 */
function rmb_output_snippets( $location, $priority = null ) {
	// Never emit inside admin screens, REST calls, or AJAX endpoints — those
	// surfaces don't render a public page and would inject script bodies into
	// API responses, which can corrupt JSON payloads.
	if ( is_admin() ) {
		return;
	}
	if ( defined( 'REST_REQUEST' ) && REST_REQUEST ) {
		return;
	}
	if ( function_exists( 'wp_doing_ajax' ) && wp_doing_ajax() ) {
		return;
	}

	// Killswitch — admins can disable emission without deleting snippets.
	if ( ! (bool) get_option( 'rrseo_emit_snippets', true ) ) {
		return;
	}

	// Per-request filter — themes / mu-plugins can suppress emission
	// (for example, on a maintenance template).
	if ( ! apply_filters( 'rrseo_render_snippets', true ) ) {
		return;
	}

	$snippets = get_option( RMB_SNIPPETS_KEY, array() );
	if ( empty( $snippets ) || ! is_array( $snippets ) ) {
		return;
	}

	if ( null === $priority ) {
		$priority = isset( RR_SNIPPET_LOCATION_HOOKS[ $location ] ) ? RR_SNIPPET_LOCATION_HOOKS[ $location ][1] : 10;
	}

	foreach ( $snippets as $id => $snippet ) {
		if ( ! is_array( $snippet ) ) {
			continue;
		}

		$snippet_data = array_merge( $snippet, array( 'id' => $id ) );

		if ( ( $snippet['status'] ?? 'active' ) !== 'active' ) {
			do_action( 'rrseo_snippet_skipped', $snippet_data, 'inactive', $location );
			continue;
		}
		if ( ( $snippet['location'] ?? 'footer' ) !== $location ) {
			continue;
		}
		// Belongs to a different priority bucket; its own emitter handles it.
		if ( rmb_snippet_priority( $snippet, $location ) !== (int) $priority ) {
			continue;
		}

		$content = (string) ( $snippet['content'] ?? '' );
		if ( '' === $content ) {
			do_action( 'rrseo_snippet_skipped', $snippet_data, 'empty_content', $location );
			continue;
		}

		if ( ! rmb_snippet_matches_display( (string) ( $snippet['display_on'] ?? 'sitewide' ) ) ) {
			do_action( 'rrseo_snippet_skipped', $snippet_data, 'display_on_mismatch', $location );
			continue;
		}

		$user_filter = (string) ( $snippet['display_on_user'] ?? 'all' );
		if ( 'anonymous' === $user_filter && is_user_logged_in() ) {
			do_action( 'rrseo_snippet_skipped', $snippet_data, 'user_logged_in', $location );
			continue;
		}
		if ( 'logged_in' === $user_filter && ! is_user_logged_in() ) {
			do_action( 'rrseo_snippet_skipped', $snippet_data, 'user_anonymous', $location );
			continue;
		}

		$marker_id = is_string( $id ) || is_int( $id ) ? (string) $id : '';
		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- managed snippets are admin-only, capability-guarded at write; must not strip <script>/<style>/JSON-LD.
		echo "\n<!-- rrseo:snippet id=\"" . esc_attr( $marker_id ) . "\" -->\n" . $content . "\n<!-- /rrseo:snippet -->\n";
		do_action( 'rrseo_snippet_emitted', $snippet_data, $location );
	}
}

/**
 * Returns true when the current request is any taxonomy archive page.
 *
 * WordPress's is_tax() returns false for built-in category and tag archives;
 * those only satisfy is_category() and is_tag() respectively. This helper
 * normalises all three into a single boolean.
 *
 * @return bool
 */
function rr_is_any_tax_archive(): bool {
	return is_tax() || is_category() || is_tag();
}


/**
 * Returns true when the current request matches the snippet's display_on rule.
 *
 * Supported value vocabulary:
 *   sitewide / all / entire_website   -- every front-end page
 *   home / homepage / front_page      -- front page only
 *   singular                          -- any singular post/page/CPT
 *   all_pages                         -- is_page()
 *   all_posts                         -- is_single()
 *   page_id:<int>                     -- specific post/page by ID
 *   post_type:<slug>                  -- singular CPT by post_type slug
 *   term:<taxonomy>:<slug>            -- specific term archive
 *   term_id:<int>                     -- any term archive by term ID
 *   tax:<taxonomy>                    -- all archives for a taxonomy
 *   url:/<path>                       -- exact URL path match
 *   <int>                             -- legacy bare integer (= page_id:<int>)
 *
 * Unknown values return false so the renderer skips them silently.
 *
 * @param string $display_on Targeting rule from the snippet record.
 * @return bool
 */
function rmb_snippet_matches_display( string $display_on ): bool {
	$display_on = trim( $display_on );
	if ( '' === $display_on ) {
		return false;
	}

	switch ( $display_on ) {
		case 'sitewide':
		case 'all':
		case 'entire_website':
			return true;
		case 'home':
		case 'homepage':
		case 'front_page':
			return is_front_page() || is_home();
		case 'singular':
			return is_singular();
		case 'all_pages':
			return is_page();
		case 'all_posts':
			return is_single();
	}

	if ( str_starts_with( $display_on, 'page_id:' ) || str_starts_with( $display_on, 'post_id:' ) ) {
		$page_id = (int) substr( $display_on, 8 );
		return $page_id > 0 && is_singular() && get_queried_object_id() === $page_id;
	}

	if ( str_starts_with( $display_on, 'post_type:' ) ) {
		$slug = trim( substr( $display_on, 10 ) );
		return '' !== $slug && is_singular( $slug );
	}

	if ( str_starts_with( $display_on, 'term:' ) ) {
		$rest = substr( $display_on, 5 );
		$sep  = strpos( $rest, ':' );
		if ( false === $sep ) {
			return false;
		}
		$taxonomy = substr( $rest, 0, $sep );
		$slug     = substr( $rest, $sep + 1 );
		if ( '' === $taxonomy || '' === $slug ) {
			return false;
		}
		if ( 'category' === $taxonomy ) {
			return is_category( $slug );
		}
		if ( 'post_tag' === $taxonomy ) {
			return is_tag( $slug );
		}
		return is_tax( $taxonomy, $slug );
	}

	if ( str_starts_with( $display_on, 'term_id:' ) ) {
		$term_id = (int) substr( $display_on, 8 );
		return $term_id > 0 && rr_is_any_tax_archive() && (int) get_queried_object_id() === $term_id;
	}

	if ( str_starts_with( $display_on, 'tax:' ) ) {
		$taxonomy = trim( substr( $display_on, 4 ) );
		if ( '' === $taxonomy ) {
			return false;
		}
		if ( 'category' === $taxonomy ) {
			return is_category();
		}
		if ( 'post_tag' === $taxonomy ) {
			return is_tag();
		}
		return is_tax( $taxonomy );
	}

	if ( str_starts_with( $display_on, 'url:' ) ) {
		$pattern = substr( $display_on, 4 );
		if ( '' === $pattern ) {
			return false;
		}
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- path is only compared, never output or used in DB.
		$request_uri  = isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '';
		$current_path = (string) wp_parse_url( $request_uri, PHP_URL_PATH );
		return rtrim( $current_path, '/' ) === rtrim( $pattern, '/' );
	}

	if ( is_numeric( $display_on ) ) {
		$page_id = (int) $display_on;
		return $page_id > 0 && is_singular() && get_queried_object_id() === $page_id;
	}

	return false;
}


// ── Document <title> override ─────────────────────────────────────────────────
// Must be registered at plugin-load time, NOT inside a wp_head callback.
// WordPress core hooks _wp_render_title_tag() to wp_head at priority 1, and it
// was registered before this plugin loaded, so it always fires first at priority 1.
// Any add_filter( 'pre_get_document_title', ... ) call made inside a same-priority
// wp_head callback therefore runs after the <title> has already been rendered.
// Registering here guarantees the filter is in place when _wp_render_title_tag() runs.
add_filter( 'pre_get_document_title', 'rr_override_document_title', 20 );

// ── Canonical URL count cache invalidation ────────────────────────────────────
// Clears the rrseo_canonical_counts transient whenever site content changes so
// /status?include_counts=true always reflects the current canonical URL set.
add_action( 'save_post', 'rr_invalidate_canonical_cache' );
add_action( 'delete_post', 'rr_invalidate_canonical_cache' );
add_action( 'transition_post_status', 'rr_invalidate_canonical_cache' );
add_action( 'update_option_' . RR_LLMS_CONFIG_KEY, 'rr_invalidate_canonical_cache' );
add_action( 'update_option_rrseo_robots_txt', 'rr_invalidate_canonical_cache' );

// ── Legacy namespace alias ────────────────────────────────────────────────────
// Intercepts REST requests to /rankmath-bridge/v1/... (the original namespace
// before the v2.2.0 rename) and re-dispatches them to /rankrocket-seo/v1/...
// using the same method and body. Appends a _deprecated field to every response
// so callers know they need to update their base URL.
// Uses rest_pre_dispatch so WordPress never tries to match the old namespace
// against registered routes — no duplicate route registrations needed.
add_filter(
	'rest_pre_dispatch',
	'rr_legacy_namespace_proxy',
	10,
	3
);

/**
 * Re-dispatches legacy rankmath-bridge/v1 requests to rankrocket-seo/v1.
 *
 * @param mixed           $result  Pre-dispatch result (null when not short-circuited).
 * @param WP_REST_Server  $server  The REST server instance.
 * @param WP_REST_Request $request Incoming request object.
 * @return mixed WP_REST_Response for old-namespace requests; original $result otherwise.
 */
function rr_legacy_namespace_proxy( $result, WP_REST_Server $server, WP_REST_Request $request ) {
	$route      = $request->get_route();
	$old_prefix = '/rankmath-bridge/v1';

	if ( 0 !== strpos( $route, $old_prefix ) ) {
		return $result;
	}

	$new_route   = '/rankrocket-seo/v1' . substr( $route, strlen( $old_prefix ) );
	$new_request = new WP_REST_Request( $request->get_method(), $new_route );
	$new_request->set_query_params( $request->get_query_params() );
	$new_request->set_body( $request->get_body() );
	$new_request->set_headers( $request->get_headers() );

	$response = $server->dispatch( $new_request );

	if ( is_a( $response, 'WP_REST_Response' ) ) {
		$data = $response->get_data();
		if ( is_array( $data ) ) {
			$data['_deprecated'] = array(
				'deprecated_namespace' => 'rankmath-bridge/v1',
				'preferred_namespace'  => 'rankrocket-seo/v1',
				'message'              => 'This namespace was renamed in v2.2.0. Update your client to use rankrocket-seo/v1.',
			);
			$response->set_data( $data );
		}
	}

	return $response;
}

// ── robots.txt override ───────────────────────────────────────────────────────
// Priority 99 to run after other plugins. Only applies when WordPress is serving
// its virtual robots.txt; a physical robots.txt file in the webroot takes
// precedence at the web-server level and bypasses this filter entirely.
add_filter( 'robots_txt', 'rr_robots_txt_output', 99, 2 );

// ── wp_robots() consolidation ─────────────────────────────────────────────────
// Merges per-post robots directives into the single <meta name="robots"> tag
// WordPress core emits via wp_robots(). When rrseo_consolidate_wp_robots is
// enabled (default), the standalone tag previously written by the RankRocket
// wp_head callback is suppressed and the directives are folded into core's
// associative array — preserving max-image-preview:large alongside our values.
add_filter( 'wp_robots', 'rr_merge_wp_robots', 20 );

// ── SEO meta output — description, robots, OG tags ───────────────────────────
// Title is handled above via pre_get_document_title; only echoed tags go here.
add_action(
	'wp_head',
	function () {
		if ( class_exists( 'RankMath' ) ) {
			return; // RankMath handles its own meta.
		}

		if ( ! is_singular() ) {
			return;
		}
		$post_id = get_queried_object_id();

		$desc   = rr_get_seo_meta( $post_id, 'description' );
		$robots = rr_get_seo_meta( $post_id, 'robots' );
		$desc   = $desc ? rmb_resolve_tokens( $desc, $post_id ) : '';

		// Fallback to excerpt then first content paragraph when no explicit description
		// is stored. Skips the title-only fallback — an absent tag is preferable to
		// a duplicate of the page title in the description slot.
		if ( ! $desc ) {
			$post_obj = get_post( $post_id );
			if ( $post_obj instanceof WP_Post ) {
				$fallback_max = (int) apply_filters( 'rrseo_excerpt_fallback_length', 155 );
				$fallback     = rr_get_discovery_description( $post_obj, $fallback_max );
				if ( 'title' !== $fallback['source'] ) {
					$desc = $fallback['description'];
				}
			}
		}

		if ( $desc ) {
			echo '<meta name="description" content="' . esc_attr( $desc ) . '">' . "\n";
		}
		// Emit a standalone <meta name="robots"> only when consolidation with WP
		// core's wp_robots() is disabled. When enabled, rr_merge_wp_robots()
		// merges our directives into the single tag core renders.
		$consolidate = (bool) get_option( 'rrseo_consolidate_wp_robots', true );
		if ( ! $consolidate && $robots && ! empty( $robots ) ) {
			$robots_val = is_array( $robots ) ? implode( ',', $robots ) : $robots;
			if ( $robots_val ) {
				echo '<meta name="robots" content="' . esc_attr( $robots_val ) . '">' . "\n";
			}
		}

		$og_title = rr_get_seo_meta( $post_id, 'og_title' );
		$og_desc  = rr_get_seo_meta( $post_id, 'og_description' );
		$og_image = rr_get_seo_meta( $post_id, 'og_image' );
		if ( ! $og_image ) {
			$thumb_id = get_post_thumbnail_id( $post_id );
			if ( $thumb_id ) {
				$og_image = wp_get_attachment_image_url( $thumb_id, 'large' );
			}
		}
		if ( $og_title ) {
			echo '<meta property="og:title" content="' . esc_attr( rmb_resolve_tokens( $og_title, $post_id ) ) . '">' . "\n";
		}
		if ( $og_desc ) {
			echo '<meta property="og:description" content="' . esc_attr( rmb_resolve_tokens( $og_desc, $post_id ) ) . '">' . "\n";
		}
		if ( $og_image ) {
			echo '<meta property="og:image" content="' . esc_url( $og_image ) . '">' . "\n";
		}
	},
	1
);


// ── Canonical URL emission ────────────────────────────────────────────────────
// Emits <link rel="canonical"> for singular posts/pages/products in the allowed
// post types. Source precedence: (1) per-post _rr_seo_canonical override,
// (2) computed canonical from rr_get_post_canonical_url(), (3) get_permalink().
// Suppressed when the post robots meta declares noindex, when another emitter
// has already written a canonical tag during this request, or when the
// rrseo_emit_canonical filter returns false.
// When this emitter DOES write a tag it unhooks WP core's rel_canonical
// (wp_head:10) so the page carries exactly one canonical (issue #4). On every
// bail path core's emitter is left in place so those pages keep a canonical.
/**
 * Emits the plugin canonical tag for singular pages on wp_head:1.
 *
 * @return void
 */
function rr_emit_singular_canonical() {
	if ( class_exists( 'RankMath' ) ) {
		return; // RankMath handles its own canonical.
	}
	if ( ! is_singular() ) {
		return;
	}
	$post_id = get_queried_object_id();
	if ( ! $post_id ) {
		return;
	}
	$post = get_post( $post_id );
	if ( ! $post ) {
		return;
	}

	$allowed_types = apply_filters( 'rrseo_allowed_post_types', RR_ALLOWED_POST_TYPES );
	if ( ! in_array( $post->post_type, $allowed_types, true ) ) {
		return;
	}

	// Suppress when the post is marked noindex.
	$robots = rr_get_seo_meta( $post_id, 'robots' );
	if ( $robots ) {
		$robots_val = is_array( $robots ) ? implode( ',', $robots ) : (string) $robots;
		if ( false !== stripos( $robots_val, 'noindex' ) ) {
			return;
		}
	}

	// Allow external suppression (e.g. another SEO plugin already emitted one).
	if ( ! apply_filters( 'rrseo_emit_canonical', true, $post_id ) ) {
		return;
	}

	// Source priority: per-post override → computed canonical → permalink.
	$override = (string) get_post_meta( $post_id, '_rr_seo_canonical', true );
	if ( '' === $override ) {
		// Legacy RankMath fallback.
		$override = (string) get_post_meta( $post_id, 'rank_math_canonical_url', true );
	}

	if ( '' !== $override ) {
		$canonical_url = $override;
	} else {
		$canonical_url = (string) get_permalink( $post );
	}

	$canonical_url = (string) apply_filters( 'rrseo_canonical_url', $canonical_url, $post_id );

	if ( '' === $canonical_url ) {
		return;
	}

	// We are committed to emitting: drop WP core's rel_canonical
	// (wp_head:10) so the page does not carry two canonical tags.
	remove_action( 'wp_head', 'rel_canonical' );

	echo '<link rel="canonical" href="' . esc_url( $canonical_url ) . '">' . "\n";
}
add_action( 'wp_head', 'rr_emit_singular_canonical', 1 );


// ── Taxonomy archive SEO meta output ──────────────────────────────────────────
// Emits description, robots (when consolidation is off), and OG tags for
// taxonomy archive pages (categories, tags, custom taxonomies). Reads from
// term meta written by /update; falls back to the term's own description field
// when no explicit rr_seo_description has been stored.
add_action(
	'wp_head',
	function () {
		if ( class_exists( 'RankMath' ) ) {
			return;
		}
		if ( ! rr_is_any_tax_archive() ) {
			return;
		}
		$term_id = get_queried_object_id();
		if ( ! $term_id ) {
			return;
		}

		$desc = rr_get_term_seo_meta( $term_id, 'description' );
		if ( ! $desc ) {
			$term = get_queried_object();
			if ( $term && ! empty( $term->description ) ) {
				$desc = rr_trim_chars( wp_strip_all_tags( $term->description ), 160 );
			}
		}
		if ( $desc ) {
			echo '<meta name="description" content="' . esc_attr( $desc ) . '">' . "\n";
		}

		$consolidate = (bool) get_option( 'rrseo_consolidate_wp_robots', true );
		if ( ! $consolidate ) {
			$robots = rr_get_term_seo_meta( $term_id, 'robots' );
			if ( $robots ) {
				$robots_val = is_array( $robots ) ? implode( ',', $robots ) : $robots;
				if ( $robots_val ) {
					echo '<meta name="robots" content="' . esc_attr( $robots_val ) . '">' . "\n";
				}
			}
		}

		$og_title = rr_get_term_seo_meta( $term_id, 'og_title' );
		$og_desc  = rr_get_term_seo_meta( $term_id, 'og_description' );
		$og_image = rr_get_term_seo_meta( $term_id, 'og_image' );
		if ( ! $og_image ) {
			$term     = isset( $term ) ? $term : get_queried_object();
			$thumb_id = $term ? (int) get_term_meta( $term_id, 'thumbnail_id', true ) : 0;
			if ( $thumb_id ) {
				$og_image = (string) wp_get_attachment_image_url( $thumb_id, 'large' );
			}
		}
		if ( $og_title ) {
			echo '<meta property="og:title" content="' . esc_attr( $og_title ) . '">' . "\n";
		}
		if ( $og_desc ) {
			echo '<meta property="og:description" content="' . esc_attr( $og_desc ) . '">' . "\n";
		}
		if ( $og_image ) {
			echo '<meta property="og:image" content="' . esc_url( $og_image ) . '">' . "\n";
		}
	},
	1
);


// ── Taxonomy archive canonical emission ───────────────────────────────────────
// Emits <link rel="canonical"> for taxonomy archive pages. Source precedence:
// (1) per-term _rr_seo_canonical override via /update, (2) get_term_link().
// Suppressed when the term's rr_seo_robots declares noindex.
add_action(
	'wp_head',
	function () {
		if ( class_exists( 'RankMath' ) ) {
			return;
		}
		if ( ! rr_is_any_tax_archive() ) {
			return;
		}
		$term_id = get_queried_object_id();
		if ( ! $term_id ) {
			return;
		}

		$robots = rr_get_term_seo_meta( $term_id, 'robots' );
		if ( $robots ) {
			$robots_val = is_array( $robots ) ? implode( ',', $robots ) : (string) $robots;
			if ( false !== stripos( $robots_val, 'noindex' ) ) {
				return;
			}
		}

		if ( ! apply_filters( 'rrseo_emit_canonical', true, $term_id ) ) {
			return;
		}

		$override = rr_get_term_seo_meta( $term_id, 'canonical' );
		if ( '' !== $override ) {
			$canonical_url = $override;
		} else {
			$term          = get_queried_object();
			$link          = $term ? get_term_link( $term ) : '';
			$canonical_url = is_wp_error( $link ) ? '' : (string) $link;
		}

		$canonical_url = (string) apply_filters( 'rrseo_canonical_url', $canonical_url, $term_id );
		if ( '' === $canonical_url ) {
			return;
		}

		echo '<link rel="canonical" href="' . esc_url( $canonical_url ) . '">' . "\n";
	},
	1
);


// ── Twitter Card emission ─────────────────────────────────────────────────────
// Emits twitter:card, twitter:title, twitter:description, and twitter:image for
// singular posts in the allowed post types. Per-post _rr_seo_twitter_* values
// take precedence; otherwise we fall back to OG fields, then post defaults.
add_action(
	'wp_head',
	function () {
		if ( class_exists( 'RankMath' ) ) {
			return; // RankMath handles its own Twitter tags.
		}
		if ( ! is_singular() ) {
			return;
		}
		$post_id = get_queried_object_id();
		if ( ! $post_id ) {
			return;
		}
		$post = get_post( $post_id );
		if ( ! $post ) {
			return;
		}

		$allowed_types = apply_filters( 'rrseo_allowed_post_types', RR_ALLOWED_POST_TYPES );
		if ( ! in_array( $post->post_type, $allowed_types, true ) ) {
			return;
		}

		if ( ! apply_filters( 'rrseo_emit_twitter_cards', true, $post_id ) ) {
			return;
		}

		// Card type — default summary_large_image, overridable per post.
		$card = rr_get_seo_meta( $post_id, 'twitter_card' );
		if ( ! $card ) {
			$card = 'summary_large_image';
		}

		// Title precedence: twitter_title → og_title → rr_seo_title → post title.
		$title = rr_get_seo_meta( $post_id, 'twitter_title' );
		if ( ! $title ) {
			$title = rr_get_seo_meta( $post_id, 'og_title' );
		}
		if ( ! $title ) {
			$title = rr_get_seo_meta( $post_id, 'title' );
		}
		if ( ! $title ) {
			$title = get_the_title( $post );
		}
		$title = rmb_resolve_tokens( $title, $post_id );

		// Description precedence: twitter_description → og_description → rr_seo_description → excerpt.
		$description = rr_get_seo_meta( $post_id, 'twitter_description' );
		if ( ! $description ) {
			$description = rr_get_seo_meta( $post_id, 'og_description' );
		}
		if ( ! $description ) {
			$description = rr_get_seo_meta( $post_id, 'description' );
		}
		if ( ! $description ) {
			$excerpt     = $post->post_excerpt ? $post->post_excerpt : $post->post_content;
			$description = rr_trim_chars( wp_strip_all_tags( $excerpt ), 200 );
		}
		$description = rmb_resolve_tokens( $description, $post_id );

		// Image precedence: twitter_image → og_image → featured image.
		$image = rr_get_seo_meta( $post_id, 'twitter_image' );
		if ( ! $image ) {
			$image = rr_get_seo_meta( $post_id, 'og_image' );
		}
		if ( ! $image ) {
			$thumb_id = get_post_thumbnail_id( $post_id );
			if ( $thumb_id ) {
				$image = wp_get_attachment_image_url( $thumb_id, 'large' );
			}
		}

		echo '<meta name="twitter:card" content="' . esc_attr( $card ) . '">' . "\n";
		if ( $title ) {
			echo '<meta name="twitter:title" content="' . esc_attr( $title ) . '">' . "\n";
		}
		if ( $description ) {
			echo '<meta name="twitter:description" content="' . esc_attr( $description ) . '">' . "\n";
		}
		if ( $image ) {
			echo '<meta name="twitter:image" content="' . esc_url( $image ) . '">' . "\n";
		}
	},
	1
);


// ── Schema JSON-LD output ─────────────────────────────────────────────────────
// Outputs whatever graph is stored in _rrseo_schema_graph for singular posts:
// a single node object, or a { "@context", "@graph": [...] } envelope for
// multi-node writes (see rr_validate_schema_graph()). Either shape is emitted
// verbatim in one <script> tag. Safe to coexist with RankMath (different
// @type values produce separate blocks).
add_action(
	'wp_head',
	function () {
		if ( ! is_singular() ) {
			return;
		}
		$post_id = get_queried_object_id();
		$schema  = get_post_meta( $post_id, RR_SCHEMA_META_KEY, true );
		if ( ! $schema || ! is_array( $schema ) ) {
			return;
		}
		// Markers let rr_schema_hygiene_strip_html() (issue #23) tell this
		// plugin's own schema block apart from third-party JSON-LD in the
		// same <head> so it never strips its own output.
		echo RR_SCHEMA_HYGIENE_MARKER_START . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- constant, not user input.
		echo '<script type="application/ld+json">' . "\n";
		echo wp_json_encode( $schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT );
		echo "\n</script>\n";
		echo RR_SCHEMA_HYGIENE_MARKER_END . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- constant, not user input.
	},
	5
);


// ── Character-bounded word-safe trim ──────────────────────────────────────────
/**
 * Trims a string to at most $max characters without cutting mid-word.
 *
 * Used for the Twitter description excerpt fallback where the social card
 * surface caps display at roughly 200 characters. We trim to the byte limit,
 * back off to the last whitespace, then append an ellipsis when truncation
 * occurred. Multibyte-safe via mb_substr / mb_strlen when available.
 *
 * @param string $text Source text (already strip-tagged).
 * @param int    $max  Maximum character count for the returned string,
 *                     excluding the trailing ellipsis. Default 200.
 * @return string
 */
function rr_trim_chars( string $text, int $max = 200 ): string {
	$text = trim( preg_replace( '/\s+/', ' ', $text ) );
	if ( '' === $text ) {
		return '';
	}
	if ( function_exists( 'mb_strlen' ) ) {
		if ( mb_strlen( $text ) <= $max ) {
			return $text;
		}
		$slice = mb_substr( $text, 0, $max );
	} else {
		if ( strlen( $text ) <= $max ) {
			return $text;
		}
		$slice = substr( $text, 0, $max );
	}
	$last_space = strrpos( $slice, ' ' );
	if ( false !== $last_space && $last_space > 0 ) {
		$slice = substr( $slice, 0, $last_space );
	}
	return rtrim( $slice ) . '…';
}


// ── Token resolver ────────────────────────────────────────────────────────────
/**
 * Replaces %title%, %sitename%, %sep%, and %excerpt% tokens in a string.
 *
 * @param string $str     The template string.
 * @param int    $post_id Post ID for token resolution context.
 * @return string
 */
function rmb_resolve_tokens( $str, $post_id ) {
	if ( ! $str ) {
		return $str;
	}
	$post    = get_post( $post_id );
	$excerpt = $post ? ( $post->post_excerpt ? $post->post_excerpt : $post->post_content ) : '';
	$tokens  = array(
		'%title%'    => $post ? get_the_title( $post ) : '',
		'%sitename%' => get_bloginfo( 'name' ),
		'%sep%'      => '|',
		'%excerpt%'  => $post ? wp_trim_words( $excerpt, 20 ) : '',
	);
	$result  = str_replace( array_keys( $tokens ), array_values( $tokens ), $str );
	// Collapse runs of spaces/tabs left by empty-token substitution; trim edges.
	return trim( preg_replace( '/[ \t]+/', ' ', $result ) );
}


// ── Document title override callback ─────────────────────────────────────────
/**
 * Overrides the document title with the stored rr_seo_title for singular posts.
 *
 * Registered on pre_get_document_title at plugin-load time (not inside wp_head)
 * so the filter is in place before _wp_render_title_tag() fires at priority 1.
 *
 * @param string $title The default document title.
 * @return string
 */
function rr_override_document_title( $title ) {
	if ( class_exists( 'RankMath' ) ) {
		return $title;
	}
	if ( is_singular() ) {
		$post_id   = get_queried_object_id();
		$seo_title = rr_get_seo_meta( $post_id, 'title' );
		if ( ! $seo_title ) {
			return $title;
		}
		return rmb_resolve_tokens( $seo_title, $post_id );
	}
	if ( rr_is_any_tax_archive() ) {
		$term_id   = get_queried_object_id();
		$seo_title = rr_get_term_seo_meta( $term_id, 'title' );
		if ( $seo_title ) {
			return $seo_title;
		}
	}
	return $title;
}


// ── Canonical cache helper ────────────────────────────────────────────────────
/**
 * Deletes the cached canonical URL counts transient.
 * Hooked to save_post, delete_post, transition_post_status, and option updates.
 */
function rr_invalidate_canonical_cache(): void {
	delete_transient( 'rrseo_canonical_counts' );
}


// ── SEO meta read helpers ─────────────────────────────────────────────────────
/**
 * Reads the native rr_seo_* key; falls back to rank_math_* when unset.
 *
 * @param int    $post_id Post ID.
 * @param string $field   Field key (e.g. 'title', 'description').
 * @return mixed
 */
function rr_get_seo_meta( $post_id, $field ) {
	$val = get_post_meta( $post_id, RR_SEO_META_KEYS[ $field ], true );
	if ( '' === $val || false === $val ) {
		$val = get_post_meta( $post_id, RR_SEO_LEGACY_META_KEYS[ $field ], true );
	}
	return $val;
}

/**
 * Reads the rr_seo_* term meta key for a taxonomy term.
 *
 * No RankMath fallback -- term meta was never written by RankMath's migration.
 *
 * @param int    $term_id Term ID.
 * @param string $field   Field key (e.g. 'title', 'description').
 * @return string
 */
function rr_get_term_seo_meta( int $term_id, string $field ): string {
	if ( ! isset( RR_SEO_META_KEYS[ $field ] ) ) {
		return '';
	}
	$val = get_term_meta( $term_id, RR_SEO_META_KEYS[ $field ], true );
	if ( false === $val || '' === $val ) {
		return '';
	}
	return (string) $val;
}

/**
 * Resolves an integer ID to either a WP_Post or a WP_Term.
 *
 * Post IDs and term IDs share the same numeric namespace in WordPress.
 * This helper tries get_post() first (the common case), then get_term().
 * Returns an array with 'type' ('post', 'term', or 'none') and 'object'
 * (the resolved object or null).
 *
 * @param int $id The integer ID to resolve.
 * @return array{type: string, object: WP_Post|WP_Term|null}
 */
function rr_resolve_id( int $id ): array {
	if ( $id <= 0 ) {
		return array(
			'type'   => 'none',
			'object' => null,
		);
	}
	$post = get_post( $id );
	if ( $post instanceof WP_Post ) {
		return array(
			'type'   => 'post',
			'object' => $post,
		);
	}
	$term = get_term( $id );
	if ( $term instanceof WP_Term ) {
		return array(
			'type'   => 'term',
			'object' => $term,
		);
	}
	return array(
		'type'   => 'none',
		'object' => null,
	);
}


// ── Validation layer ──────────────────────────────────────────────────────────

/**
 * Validates SEO field values for a given post.
 *
 * Returns array( 'errors' => string[], 'warnings' => string[] ).
 * Errors are hard failures; warnings are advisory.
 *
 * @param array    $fields  Map of field name => value.
 * @param int|null $post_id Optional post ID for post-type validation.
 * @return array{errors: string[], warnings: string[]}
 */
function rr_validate_seo_fields( array $fields, $post_id = null ) {
	$errors   = array();
	$warnings = array();

	if ( null !== $post_id ) {
		$post = get_post( $post_id );
		if ( ! $post ) {
			$errors[] = "post_id {$post_id}: post not found";
		} else {
			$allowed_types = apply_filters( 'rrseo_allowed_post_types', RR_ALLOWED_POST_TYPES );
			if ( ! in_array( $post->post_type, $allowed_types, true ) ) {
				$errors[] = "post_id {$post_id}: post type '{$post->post_type}' not allowed. Allowed: " . implode( ', ', $allowed_types );
			}
		}
	}

	if ( isset( $fields['title'] ) && '' !== $fields['title'] ) {
		$len = mb_strlen( $fields['title'] );
		if ( $len > RR_TITLE_MAX ) {
			$errors[] = "title: {$len} chars — exceeds hard limit of " . RR_TITLE_MAX;
		} elseif ( $len > RR_TITLE_WARN_MAX ) {
			$warnings[] = "title: {$len} chars — above recommended maximum of " . RR_TITLE_WARN_MAX;
		} elseif ( $len < RR_TITLE_WARN_MIN ) {
			$warnings[] = "title: {$len} chars — below recommended minimum of " . RR_TITLE_WARN_MIN;
		}
	}

	if ( isset( $fields['description'] ) && '' !== $fields['description'] ) {
		$len = mb_strlen( $fields['description'] );
		if ( $len > RR_DESC_MAX ) {
			$errors[] = "description: {$len} chars — exceeds hard limit of " . RR_DESC_MAX;
		} elseif ( $len > RR_DESC_WARN_MAX ) {
			$warnings[] = "description: {$len} chars — above recommended maximum of " . RR_DESC_WARN_MAX;
		} elseif ( $len < RR_DESC_WARN_MIN ) {
			$warnings[] = "description: {$len} chars — below recommended minimum of " . RR_DESC_WARN_MIN;
		}
	}

	if ( isset( $fields['og_image'] ) && '' !== $fields['og_image'] ) {
		if ( ! filter_var( $fields['og_image'], FILTER_VALIDATE_URL ) ) {
			$errors[] = 'og_image: not a valid URL';
		}
	}

	if ( isset( $fields['canonical'] ) && '' !== $fields['canonical'] ) {
		if ( ! filter_var( $fields['canonical'], FILTER_VALIDATE_URL ) ) {
			$errors[] = 'canonical: not a valid URL';
		}
	}

	if ( isset( $fields['twitter_image'] ) && '' !== $fields['twitter_image'] ) {
		if ( ! filter_var( $fields['twitter_image'], FILTER_VALIDATE_URL ) ) {
			$errors[] = 'twitter_image: not a valid URL';
		}
	}

	if ( isset( $fields['twitter_card'] ) && '' !== $fields['twitter_card'] ) {
		// Twitter/X has historically added card types (e.g. summary_large_image, app,
		// player, and forthcoming variants). We prefer caller flexibility over
		// rejecting forward-compatible values, so only enforce a permissive sanitised
		// shape: a slug-like token of <= 32 chars. The runtime emitter passes the
		// value through esc_attr() before rendering.
		$len = strlen( $fields['twitter_card'] );
		if ( $len > 32 ) {
			$errors[] = "twitter_card: {$len} chars — exceeds hard limit of 32";
		}
	}

	if ( isset( $fields['robots'] ) && '' !== $fields['robots'] ) {
		$values  = array_map( 'trim', explode( ',', $fields['robots'] ) );
		$invalid = array_diff( $values, RR_ALLOWED_ROBOTS );
		if ( $invalid ) {
			$errors[] = 'robots: invalid value(s): ' . implode( ', ', $invalid )
				. '. Allowed: ' . implode( ', ', RR_ALLOWED_ROBOTS );
		}
	}

	return array(
		'errors'   => $errors,
		'warnings' => $warnings,
	);
}

/**
 * Returns true when $value is an accepted display_on targeting pattern.
 *
 * Aligned with rmb_snippet_matches_display(). The url: prefix is intentionally
 * excluded — recognised by the emitter but not yet validated on live taxonomy
 * archives.
 *
 * @param string $value Raw display_on value from the REST request.
 * @return bool
 */
function rr_validate_display_on( string $value ): bool {
	if ( '' === $value ) {
		return false;
	}

	$simple_values = array(
		'sitewide',
		'all',
		'entire_website',
		'home',
		'homepage',
		'front_page',
		'singular',
		'all_pages',
		'all_posts',
	);
	if ( in_array( $value, $simple_values, true ) ) {
		return true;
	}

	$patterns = array(
		'/^page_id:\d+$/',
		'/^post_id:\d+$/',
		'/^post_type:[a-z0-9_-]+$/',
		'/^term_id:\d+$/',
		'/^term:[a-z0-9_-]+:[a-z0-9_-]+$/',
		'/^tax:[a-z0-9_-]+$/',
		'/^\d+$/',
	);
	foreach ( $patterns as $pattern ) {
		if ( 1 === preg_match( $pattern, $value ) ) {
			return true;
		}
	}

	return false;
}

/**
 * Validates and normalizes the optional strip_third_party field on
 * POST /schema/{post_id} (issue #23): an array of schema.org @type names
 * to strip from non-plugin JSON-LD found in this post's <head>.
 *
 * @param mixed $value Raw request value.
 * @return array{errors: string[], normalized: string[]}
 */
function rr_validate_schema_strip_third_party( $value ) {
	if ( ! is_array( $value ) ) {
		return array(
			'errors'     => array( 'strip_third_party must be an array of schema.org @type names' ),
			'normalized' => array(),
		);
	}

	$normalized = array();
	foreach ( $value as $type ) {
		if ( ! is_string( $type ) || '' === trim( $type ) ) {
			return array(
				'errors'     => array( 'strip_third_party entries must be non-empty strings' ),
				'normalized' => array(),
			);
		}
		$normalized[] = sanitize_text_field( $type );
	}

	return array(
		'errors'     => array(),
		'normalized' => array_values( array_unique( $normalized ) ),
	);
}

/**
 * Validates a JSON-LD schema object.
 *
 * Accepts either a PHP array or a JSON string. Three shapes are supported:
 * a single node (`{"@type": ...}`), a bare array of nodes (`[{...}, {...}]`),
 * or a `@graph` envelope (`{"@context": ..., "@graph": [{...}, {...}]}`).
 * The latter two are normalized to a canonical `@graph` envelope on write;
 * single-node input is stored exactly as received.
 *
 * Returns array( 'errors' => string[], 'warnings' => string[], 'schema' => array|null ).
 *
 * @param array|string $schema Schema as a PHP array or raw JSON string.
 * @return array{errors: string[], warnings: string[], schema: array|null}
 */
function rr_validate_schema( $schema ) {
	$errors   = array();
	$warnings = array();

	if ( is_string( $schema ) ) {
		$decoded = json_decode( $schema, true );
		if ( json_last_error() !== JSON_ERROR_NONE ) {
			return array(
				'errors'   => array( 'schema: invalid JSON — ' . json_last_error_msg() ),
				'warnings' => array(),
				'schema'   => null,
			);
		}
		$schema = $decoded;
	}

	if ( ! is_array( $schema ) ) {
		return array(
			'errors'   => array( 'schema: must be a JSON object' ),
			'warnings' => array(),
			'schema'   => null,
		);
	}

	// Bare array of nodes, e.g. [ {...}, {...} ]. An empty array falls through
	// to single-node validation below, which reports the usual missing-field
	// errors instead of a graph-specific "no nodes" error.
	if ( ! empty( $schema ) && wp_is_numeric_array( $schema ) ) {
		return rr_validate_schema_graph( 'https://schema.org', $schema );
	}

	// @graph envelope: a top-level object carrying an @graph array of nodes.
	if ( isset( $schema['@graph'] ) && is_array( $schema['@graph'] ) ) {
		$context = empty( $schema['@context'] ) ? 'https://schema.org' : $schema['@context'];
		return rr_validate_schema_graph( $context, $schema['@graph'] );
	}

	if ( empty( $schema['@context'] ) ) {
		$errors[] = 'schema: missing required @context';
	}

	if ( empty( $schema['@type'] ) ) {
		$errors[] = 'schema: missing required @type';
	} else {
		$allowed = apply_filters( 'rrseo_allowed_schema_types', RR_ALLOWED_SCHEMA_TYPES );
		if ( ! in_array( $schema['@type'], $allowed, true ) ) {
			$errors[] = "schema: @type '{$schema['@type']}' not allowed. Allowed: " . implode( ', ', $allowed );
		}
	}

	return array(
		'errors'   => $errors,
		'warnings' => $warnings,
		'schema'   => $schema,
	);
}

/**
 * Validates a list of JSON-LD nodes and normalizes them into a canonical
 * `@graph` envelope. Shared by bare-array and `@graph`-wrapped input.
 *
 * @param string $context Top-level @context value for the envelope.
 * @param array  $nodes   List of node objects.
 * @return array{errors: string[], warnings: string[], schema: array|null, status?: int}
 */
function rr_validate_schema_graph( $context, array $nodes ) {
	if ( empty( $nodes ) ) {
		return array(
			'errors'   => array( 'schema: @graph must contain at least one node' ),
			'warnings' => array(),
			'schema'   => null,
		);
	}

	$max_nodes = apply_filters( 'rrseo_schema_graph_max_nodes', 20 );
	if ( count( $nodes ) > $max_nodes ) {
		return array(
			'errors'   => array( "schema: @graph exceeds max of {$max_nodes} nodes" ),
			'warnings' => array(),
			'schema'   => null,
			'status'   => 413,
		);
	}

	$allowed     = apply_filters( 'rrseo_allowed_schema_types', RR_ALLOWED_SCHEMA_TYPES );
	$errors      = array();
	$clean_nodes = array();

	foreach ( $nodes as $index => $node ) {
		if ( ! is_array( $node ) ) {
			$errors[] = "schema: @graph[{$index}] must be a JSON object";
			continue;
		}
		if ( empty( $node['@type'] ) ) {
			$errors[] = "schema: @graph[{$index}] missing required @type";
			continue;
		}
		if ( ! in_array( $node['@type'], $allowed, true ) ) {
			$errors[] = "schema: @graph[{$index}] @type '{$node['@type']}' not allowed. Allowed: " . implode( ', ', $allowed );
			continue;
		}
		$clean_nodes[] = $node;
	}

	if ( ! empty( $errors ) ) {
		return array(
			'errors'   => $errors,
			'warnings' => array(),
			'schema'   => null,
		);
	}

	return array(
		'errors'   => array(),
		'warnings' => array(),
		'schema'   => array(
			'@context' => $context,
			'@graph'   => $clean_nodes,
		),
	);
}


// ── Audit log ─────────────────────────────────────────────────────────────────
/**
 * Appends an entry to the per-post audit log, capped at 100 entries.
 *
 * @param int    $post_id    Post ID.
 * @param string $endpoint   REST endpoint that triggered the write.
 * @param array  $changes    Map of field => array( 'before' => mixed, 'after' => mixed ).
 * @param string $request_id X-Request-ID value for correlation.
 * @param string $status     'written', 'migrated', etc.
 */
function rr_audit_log( $post_id, $endpoint, array $changes, $request_id, $status ) {
	$log  = get_post_meta( $post_id, RR_CHANGE_LOG_KEY, true );
	$log  = is_array( $log ) ? $log : array();
	$uid  = get_current_user_id();
	$user = $uid ? get_userdata( $uid ) : null;

	$log[] = array(
		'timestamp'  => gmdate( 'Y-m-d\TH:i:s\Z' ),
		'user_id'    => $uid,
		'user_login' => $user ? $user->user_login : 'system',
		'endpoint'   => $endpoint,
		'post_id'    => $post_id,
		'changes'    => $changes,
		'request_id' => $request_id,
		'status'     => $status,
	);

	// Cap at 100 entries per post to prevent unbounded growth.
	if ( count( $log ) > 100 ) {
		$log = array_slice( $log, -100 );
	}

	update_post_meta( $post_id, RR_CHANGE_LOG_KEY, $log );
}

/**
 * Returns the X-Request-ID header value, or generates a UUID if absent.
 *
 * @param WP_REST_Request $request Current REST request.
 * @return string
 */
function rr_request_id( WP_REST_Request $request ) {
	$id = $request->get_header( 'x-request-id' );
	return $id ? $id : wp_generate_uuid4();
}


// ── llms.txt generator ────────────────────────────────────────────────────────
add_action(
	'init',
	function () {
		if ( ! isset( $_SERVER['REQUEST_URI'] ) ) {
			return;
		}
		if ( defined( 'REST_REQUEST' ) && REST_REQUEST ) {
			return;
		}
		if ( defined( 'DOING_CRON' ) && DOING_CRON ) {
			return;
		}
		$uri = strtok( $_SERVER['REQUEST_URI'], '?' );
		$uri = rtrim( $uri, '/' );
		if ( '/llms.txt' === $uri ) {
			rmb_serve_llms_txt();
			exit;
		}
	},
	1
);

/**
 * Serves the dynamic /llms.txt plain-text response.
 */
function rmb_serve_llms_txt() {
	while ( ob_get_level() ) {
		ob_end_clean();
	}
	if ( headers_sent( $hf, $hl ) ) {
		status_header( 200 );
		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Plain-text response; $hf/$hl come from PHP's headers_sent().
		echo "# llms.txt\n# Note: headers already sent from {$hf}:{$hl}\n";
		return;
	}
	status_header( 200 );
	header( 'Content-Type: text/plain; charset=UTF-8' );
	header( 'Cache-Control: no-cache' );

	$config = get_option( RR_LLMS_CONFIG_KEY, get_option( 'rmb_llms_config', array() ) );
	$result = rr_render_llms_txt( $config );

	// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Plain-text llms.txt; content is site-admin-controlled.
	echo $result['content'];
}


// ── XML Sitemap ───────────────────────────────────────────────────────────────
add_action(
	'wp',
	function () {
		if ( ! isset( $_SERVER['REQUEST_URI'] ) ) {
			return;
		}
		$uri = rtrim( strtok( $_SERVER['REQUEST_URI'], '?' ), '/' );

		// XSL stylesheet — must be registered before any XML that references it.
		if ( '/rmb-sitemap.xsl' === $uri ) {
			rmb_serve_sitemap_xsl();
			exit;
		}
		// Per-type sub-sitemaps.
		if ( '/rmb-sitemap-posts.xml' === $uri ) {
			rmb_serve_sitemap_type( 'post' );
			exit;
		}
		if ( '/rmb-sitemap-pages.xml' === $uri ) {
			rmb_serve_sitemap_type( 'page' );
			exit;
		}
		// Index — points to per-type sub-sitemaps.
		if ( '/rmb-sitemap-index.xml' === $uri || '/sitemap_index.xml' === $uri ) {
			rmb_serve_sitemap_index();
			exit;
		}
		// Legacy combined sitemap kept for backward compatibility.
		if ( '/rmb-sitemap.xml' === $uri || '/sitemap.xml' === $uri ) {
			rmb_serve_sitemap();
			exit;
		}
	}
);

/**
 * Serves the XSL stylesheet that styles sitemaps in the browser.
 *
 * Reads includes/sitemap.xsl and replaces RRSEO_* tokens with live site values
 * before output so the stylesheet is self-contained without a separate request.
 */
function rmb_serve_sitemap_xsl(): void {
	while ( ob_get_level() ) {
		ob_end_clean();
	}
	status_header( 200 );
	header( 'Content-Type: text/xsl; charset=UTF-8' );
	header( 'Cache-Control: public, max-age=86400' );

	$xsl_file = RMB_PLUGIN_DIR . 'includes/sitemap.xsl';
	if ( ! file_exists( $xsl_file ) ) {
		return;
	}

	// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- local plugin file, not remote URL.
	$xsl = file_get_contents( $xsl_file );

	$xsl = str_replace(
		array( 'RRSEO_SITE_NAME', 'RRSEO_INDEX_URL', 'RRSEO_VERSION' ),
		array(
			esc_html( get_bloginfo( 'name' ) ),
			esc_url( rtrim( get_bloginfo( 'url' ), '/' ) . '/sitemap_index.xml' ),
			esc_html( RMB_VERSION ),
		),
		$xsl
	);

	// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- XSL file is a committed plugin asset; tokens replaced above.
	echo $xsl;
}

/**
 * Outputs the sitemap index document, pointing to per-type sub-sitemaps.
 *
 * Replaces the legacy single-entry index. Each sub-sitemap carries its own
 * lastmod reflecting the most recently modified post of that type.
 */
function rmb_serve_sitemap_index(): void {
	while ( ob_get_level() ) {
		ob_end_clean();
	}
	status_header( 200 );

	$site_url = rtrim( get_bloginfo( 'url' ), '/' );
	$xsl_url  = $site_url . '/rmb-sitemap.xsl';
	$fallback = gmdate( 'Y-m-d\TH:i:s+00:00' );

	// Derive lastmod from the same filtered set the child sitemaps use so that
	// excluded posts (utility pages, noindex, test placeholders) cannot push the
	// index timestamp ahead of what the child sitemaps actually contain.
	$canonical      = rr_get_canonical_url_set( array( 'post_types' => array( 'post', 'page' ) ) );
	$posts_lastmods = array();
	$pages_lastmods = array();
	foreach ( $canonical['urls'] as $entry ) {
		if ( 'post' === $entry['post_type'] ) {
			$posts_lastmods[] = $entry['lastmod'];
		} else {
			$pages_lastmods[] = $entry['lastmod'];
		}
	}
	$posts_mod = ! empty( $posts_lastmods ) ? max( $posts_lastmods ) : $fallback;
	$pages_mod = ! empty( $pages_lastmods ) ? max( $pages_lastmods ) : $fallback;

	header( 'Content-Type: application/xml; charset=UTF-8' );
	// phpcs:disable WordPress.Security.EscapeOutput.OutputNotEscaped -- XML document; all values are from trusted WP functions or esc_url/esc_html.
	echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
	echo '<?xml-stylesheet type="text/xsl" href="' . esc_url( $xsl_url ) . '"?>' . "\n";
	echo '<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";
	echo "  <sitemap>\n";
	echo '    <loc>' . esc_url( $site_url . '/rmb-sitemap-posts.xml' ) . "</loc>\n";
	echo '    <lastmod>' . esc_html( $posts_mod ) . "</lastmod>\n";
	echo "  </sitemap>\n";
	echo "  <sitemap>\n";
	echo '    <loc>' . esc_url( $site_url . '/rmb-sitemap-pages.xml' ) . "</loc>\n";
	echo '    <lastmod>' . esc_html( $pages_mod ) . "</lastmod>\n";
	echo "  </sitemap>\n";
	echo '</sitemapindex>' . "\n";
	echo '<!-- XML Sitemap Index generated by RankRocket SEO Control Layer v' . RMB_VERSION . " -->\n";
	// phpcs:enable
}

/**
 * Outputs a per-type XML sitemap using the shared Canonical URL Set.
 *
 * Replaces the previous independent URL loop with rr_get_canonical_url_set()
 * to guarantee consistent filtering with llms.txt and the sitemap preview.
 *
 * @param string $post_type 'post' or 'page'.
 */
function rmb_serve_sitemap_type( string $post_type ): void {
	while ( ob_get_level() ) {
		ob_end_clean();
	}
	status_header( 200 );

	$site_url   = rtrim( get_bloginfo( 'url' ), '/' );
	$xsl_url    = $site_url . '/rmb-sitemap.xsl';
	$front_page = 'page' === $post_type ? (int) get_option( 'page_on_front' ) : 0;

	$canonical = rr_get_canonical_url_set( array( 'post_types' => array( $post_type ) ) );

	header( 'Content-Type: application/xml; charset=UTF-8' );
	// phpcs:disable WordPress.Security.EscapeOutput.OutputNotEscaped -- XML document; all values escaped inline below.
	echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
	echo '<?xml-stylesheet type="text/xsl" href="' . esc_url( $xsl_url ) . '"?>' . "\n";
	echo '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";
	foreach ( $canonical['urls'] as $entry ) {
		$priority = '0.6';
		if ( 'page' === $post_type ) {
			$priority = ( $entry['post_id'] === $front_page ) ? '1.0' : '0.8';
		}
		echo "  <url>\n";
		echo '    <loc>' . esc_url( $entry['url'] ) . "</loc>\n";
		echo '    <lastmod>' . esc_html( $entry['lastmod'] ) . "</lastmod>\n";
		echo '    <priority>' . esc_html( $priority ) . "</priority>\n";
		echo "  </url>\n";
	}
	echo '</urlset>' . "\n";
	echo '<!-- XML Sitemap (' . esc_html( $post_type ) . ') generated by RankRocket SEO Control Layer v' . RMB_VERSION . " -->\n";
	// phpcs:enable
}

/**
 * Outputs the legacy combined XML sitemap using the shared Canonical URL Set.
 *
 * Kept for backward compatibility; canonical sitemap is the per-type sub-sitemaps
 * linked from /sitemap_index.xml. Now uses rr_get_canonical_url_set() for
 * consistent filtering.
 */
function rmb_serve_sitemap(): void {
	while ( ob_get_level() ) {
		ob_end_clean();
	}
	status_header( 200 );

	$front_page = (int) get_option( 'page_on_front' );
	$site_url   = rtrim( get_bloginfo( 'url' ), '/' );
	$xsl_url    = $site_url . '/rmb-sitemap.xsl';

	$canonical = rr_get_canonical_url_set(
		array( 'post_types' => array( 'post', 'page' ) )
	);

	header( 'Content-Type: application/xml; charset=UTF-8' );
	// phpcs:disable WordPress.Security.EscapeOutput.OutputNotEscaped -- XML document; all values escaped inline below.
	echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
	echo '<?xml-stylesheet type="text/xsl" href="' . esc_url( $xsl_url ) . '"?>' . "\n";
	echo '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";
	foreach ( $canonical['urls'] as $entry ) {
		if ( 'page' === $entry['post_type'] ) {
			$priority = ( $entry['post_id'] === $front_page ) ? '1.0' : '0.8';
		} else {
			$priority = '0.6';
		}
		echo "  <url>\n";
		echo '    <loc>' . esc_url( $entry['url'] ) . "</loc>\n";
		echo '    <lastmod>' . esc_html( $entry['lastmod'] ) . "</lastmod>\n";
		echo '    <priority>' . esc_html( $priority ) . "</priority>\n";
		echo "  </url>\n";
	}
	echo '</urlset>' . "\n";
	echo '<!-- XML Sitemap (combined/legacy) generated by RankRocket SEO Control Layer v' . RMB_VERSION . " -->\n";
	// phpcs:enable
}


// ── Performance module ────────────────────────────────────────────────────────
add_action( 'wp_enqueue_scripts', 'rrseo_apply_dequeue_rules', 999 );
add_filter( 'script_loader_tag', 'rrseo_apply_defer_tag', 10, 2 );

/**
 * Applies stored dequeue rules on the front end.
 *
 * Runs at wp_enqueue_scripts:999 so it fires after all themes and plugins
 * have enqueued their assets. For each rule, if ANY of the when_not
 * conditional functions returns true the rule is skipped (assets stay
 * enqueued). With an empty when_not array the rule fires on every page.
 */
function rrseo_apply_dequeue_rules(): void {
	$rules = get_option( RR_PERF_DEQUEUE_KEY, array() );
	if ( empty( $rules ) || ! is_array( $rules ) ) {
		return;
	}
	$allowed = RR_PERF_ALLOWED_CONDITIONALS;
	foreach ( $rules as $rule ) {
		if ( empty( $rule['handles'] ) || ! is_array( $rule['handles'] ) ) {
			continue;
		}
		$when_not = ( isset( $rule['when_not'] ) && is_array( $rule['when_not'] ) )
			? $rule['when_not']
			: array();
		foreach ( $when_not as $cond ) {
			if ( in_array( $cond, $allowed, true ) && function_exists( $cond ) && $cond() ) {
				continue 2;
			}
		}
		$type = isset( $rule['type'] ) ? (string) $rule['type'] : 'auto';
		foreach ( $rule['handles'] as $handle ) {
			$handle = (string) $handle;
			if ( 'style' === $type || 'auto' === $type ) {
				wp_dequeue_style( $handle );
				wp_deregister_style( $handle );
			}
			if ( 'script' === $type || 'auto' === $type ) {
				wp_dequeue_script( $handle );
				wp_deregister_script( $handle );
			}
		}
	}
}

/**
 * Adds a defer attribute to script tags for handles in the defer list.
 *
 * Registered with accepted_args=2; $src is not needed.
 * Skips tags that already contain 'defer' to avoid double-adding.
 *
 * @param string $tag    The full <script> tag HTML.
 * @param string $handle The script handle.
 * @return string
 */
function rrseo_apply_defer_tag( $tag, $handle ): string {
	static $defer_handles = null;
	if ( null === $defer_handles ) {
		$defer_handles = (array) get_option( RR_PERF_DEFER_KEY, array() );
	}
	if ( ! in_array( $handle, $defer_handles, true ) ) {
		return $tag;
	}
	if ( false !== strpos( $tag, ' defer' ) ) {
		return $tag;
	}
	return str_replace( ' src=', ' defer src=', $tag );
}


// ── REST API ──────────────────────────────────────────────────────────────────
add_action(
	'rest_api_init',
	function () {
		register_shutdown_function( 'rrseo_rest_fatal_handler' );
	}
);

/**
 * Catches PHP fatals during REST requests and emits a clean JSON error response.
 *
 * Without this, a fatal inside a REST handler leaks an HTML "critical error" page
 * wrapped in a partial REST envelope. Registered on rest_api_init so it only
 * activates for REST requests, not front-end page loads.
 */
function rrseo_rest_fatal_handler() {
	if ( ! defined( 'REST_REQUEST' ) || ! REST_REQUEST ) {
		return;
	}
	$error = error_get_last();
	if ( null === $error ) {
		return;
	}
	$fatal_types = array( E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR, E_USER_ERROR );
	if ( ! in_array( $error['type'], $fatal_types, true ) ) {
		return;
	}
	while ( ob_get_level() ) {
		ob_end_clean();
	}
	if ( ! headers_sent() ) {
		status_header( 500 );
		header( 'Content-Type: application/json; charset=UTF-8' );
	}
	// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- JSON error response; no user data exposed.
	echo wp_json_encode(
		array(
			'code'    => 'internal_server_error',
			'message' => 'A server error occurred. Check the PHP error log for details.',
			'data'    => array( 'status' => 500 ),
		)
	);
}

add_action(
	'rest_api_init',
	function () {

		$admin_only = function () {
			return current_user_can( 'manage_options' );
		};

		// ── SEO Meta ──────────────────────────────────────────────────────────────
		register_rest_route(
			'rankrocket-seo/v1',
			'/update',
			array(
				'methods'             => 'POST',
				'callback'            => 'rmb_update_meta',
				'permission_callback' => $admin_only,
				'args'                => array(
					'post_id'             => array(
						'required' => true,
						'type'     => 'integer',
					),
					'title'               => array(
						'required' => false,
						'type'     => 'string',
					),
					'description'         => array(
						'required' => false,
						'type'     => 'string',
					),
					'focus_keyword'       => array(
						'required' => false,
						'type'     => 'string',
					),
					'robots'              => array(
						'required' => false,
						'type'     => 'string',
					),
					'og_title'            => array(
						'required' => false,
						'type'     => 'string',
					),
					'og_description'      => array(
						'required' => false,
						'type'     => 'string',
					),
					'og_image'            => array(
						'required' => false,
						'type'     => 'string',
					),
					'canonical'           => array(
						'required' => false,
						'type'     => 'string',
					),
					'twitter_card'        => array(
						'required' => false,
						'type'     => 'string',
					),
					'twitter_title'       => array(
						'required' => false,
						'type'     => 'string',
					),
					'twitter_description' => array(
						'required' => false,
						'type'     => 'string',
					),
					'twitter_image'       => array(
						'required' => false,
						'type'     => 'string',
					),
					'unset_fields'        => array(
						'required' => false,
						'type'     => 'array',
						'items'    => array( 'type' => 'string' ),
						'default'  => array(),
					),
				),
			)
		);

		register_rest_route(
			'rankrocket-seo/v1',
			'/get/(?P<id>\d+)',
			array(
				'methods'             => 'GET',
				'callback'            => 'rmb_get_meta',
				'permission_callback' => $admin_only,
			)
		);

		// ── Preview / dry-run ─────────────────────────────────────────────────────
		register_rest_route(
			'rankrocket-seo/v1',
			'/preview-update',
			array(
				'methods'             => 'POST',
				'callback'            => 'rmb_preview_update',
				'permission_callback' => $admin_only,
				'args'                => array(
					'post_id'             => array(
						'required' => true,
						'type'     => 'integer',
					),
					'title'               => array(
						'required' => false,
						'type'     => 'string',
					),
					'description'         => array(
						'required' => false,
						'type'     => 'string',
					),
					'focus_keyword'       => array(
						'required' => false,
						'type'     => 'string',
					),
					'robots'              => array(
						'required' => false,
						'type'     => 'string',
					),
					'og_title'            => array(
						'required' => false,
						'type'     => 'string',
					),
					'og_description'      => array(
						'required' => false,
						'type'     => 'string',
					),
					'og_image'            => array(
						'required' => false,
						'type'     => 'string',
					),
					'canonical'           => array(
						'required' => false,
						'type'     => 'string',
					),
					'twitter_card'        => array(
						'required' => false,
						'type'     => 'string',
					),
					'twitter_title'       => array(
						'required' => false,
						'type'     => 'string',
					),
					'twitter_description' => array(
						'required' => false,
						'type'     => 'string',
					),
					'twitter_image'       => array(
						'required' => false,
						'type'     => 'string',
					),
				),
			)
		);

		// ── Bulk SEO meta read/write ───────────────────────────────────────────────
		register_rest_route(
			'rankrocket-seo/v1',
			'/meta/bulk-get',
			array(
				'methods'             => 'POST',
				'callback'            => 'rmb_meta_bulk_get',
				'permission_callback' => $admin_only,
				'args'                => array(
					'post_ids' => array(
						'required' => true,
						'type'     => 'array',
					),
				),
			)
		);

		register_rest_route(
			'rankrocket-seo/v1',
			'/meta/bulk-update',
			array(
				'methods'             => 'POST',
				'callback'            => 'rmb_meta_bulk_update',
				'permission_callback' => $admin_only,
				'args'                => array(
					'updates' => array(
						'required' => true,
						'type'     => 'array',
					),
				),
			)
		);

		// ── Schema ────────────────────────────────────────────────────────────────
		register_rest_route(
			'rankrocket-seo/v1',
			'/schema/(?P<post_id>\d+)',
			array(
				array(
					'methods'             => 'GET',
					'callback'            => 'rmb_schema_get',
					'permission_callback' => $admin_only,
				),
				array(
					'methods'             => 'POST',
					'callback'            => 'rmb_schema_set',
					'permission_callback' => $admin_only,
					'args'                => array(
						'schema'            => array(
							'required' => true,
							'type'     => array( 'object', 'array' ),
						),
						'strip_third_party' => array(
							'required' => false,
							'type'     => 'array',
							'items'    => array( 'type' => 'string' ),
						),
						'dry_run'           => array(
							'required' => false,
							'type'     => 'boolean',
							'default'  => false,
						),
					),
				),
			)
		);

		// ── Audit log ─────────────────────────────────────────────────────────────
		register_rest_route(
			'rankrocket-seo/v1',
			'/log/(?P<post_id>\d+)',
			array(
				'methods'             => 'GET',
				'callback'            => 'rmb_log_get',
				'permission_callback' => $admin_only,
			)
		);

		// ── Image ALT text ─────────────────────────────────────────────────────────
		register_rest_route(
			'rankrocket-seo/v1',
			'/images',
			array(
				'methods'             => 'GET',
				'callback'            => 'rmb_images_list',
				'permission_callback' => $admin_only,
			)
		);

		// MUST be registered before the wildcard.
		register_rest_route(
			'rankrocket-seo/v1',
			'/images/(?P<id>\d+)/alt',
			array(
				array(
					'methods'             => 'GET',
					'callback'            => 'rmb_image_get_alt',
					'permission_callback' => $admin_only,
				),
				array(
					'methods'             => 'POST',
					'callback'            => 'rmb_image_set_alt',
					'permission_callback' => $admin_only,
					'args'                => array(
						'id'  => array(
							'required' => true,
							'type'     => 'integer',
						),
						'alt' => array(
							'required' => true,
							'type'     => 'string',
						),
					),
				),
			)
		);

		register_rest_route(
			'rankrocket-seo/v1',
			'/images/bulk-alt',
			array(
				'methods'             => 'POST',
				'callback'            => 'rmb_images_bulk_alt',
				'permission_callback' => $admin_only,
				'args'                => array(
					'updates' => array(
						'required' => true,
						'type'     => 'array',
					),
				),
			)
		);

		// ── Media upload ──────────────────────────────────────────────────────────
		// MUST be registered before the /media/{id}-style wildcard, if one is
		// ever added — 'placeholders' would otherwise be captured as an id.
		register_rest_route(
			'rankrocket-seo/v1',
			'/media/placeholders',
			array(
				'methods'             => 'GET',
				'callback'            => 'rmb_media_list_placeholders',
				'permission_callback' => $admin_only,
			)
		);

		register_rest_route(
			'rankrocket-seo/v1',
			'/media',
			array(
				'methods'             => 'POST',
				'callback'            => 'rmb_media_upload',
				'permission_callback' => $admin_only,
				'args'                => array(
					'alt_text'          => array(
						'required' => false,
						'type'     => 'string',
					),
					'source'            => array(
						'required' => false,
						'type'     => 'string',
					),
					'filename'          => array(
						'required' => false,
						'type'     => 'string',
					),
					'caption'           => array(
						'required' => false,
						'type'     => 'string',
					),
					'title'             => array(
						'required' => false,
						'type'     => 'string',
					),
					'attach_to_post_id' => array(
						'required' => false,
						'type'     => 'integer',
					),
					'is_placeholder'    => array(
						'required' => false,
						'type'     => 'boolean',
						'default'  => false,
					),
					'dry_run'           => array(
						'required' => false,
						'type'     => 'boolean',
						'default'  => false,
					),
				),
			)
		);

		// ── Elementor set-data ───────────────────────────────────────────────────
		register_rest_route(
			'rankrocket-seo/v1',
			'/elementor/set-data',
			array(
				'methods'             => 'POST',
				'callback'            => 'rmb_elementor_set_data',
				'permission_callback' => $admin_only,
				'args'                => array(
					'post_id'          => array(
						'required' => true,
						'type'     => 'integer',
					),
					'elementor_data'   => array(
						'required' => true,
						'type'     => 'array',
					),
					'edit_mode'        => array(
						'required' => false,
						'type'     => 'string',
						'default'  => 'builder',
					),
					'template_type'    => array(
						'required' => false,
						'type'     => 'string',
						'default'  => 'wp-page',
					),
					'css_print_method' => array(
						'required' => false,
						'type'     => 'string',
					),
					'dry_run'          => array(
						'required' => false,
						'type'     => 'boolean',
						'default'  => false,
					),
				),
			)
		);

		// ── llms.txt config ────────────────────────────────────────────────────────
		register_rest_route(
			'rankrocket-seo/v1',
			'/llms',
			array(
				array(
					'methods'             => 'GET',
					'callback'            => 'rmb_llms_get_config',
					'permission_callback' => $admin_only,
				),
				array(
					'methods'             => 'POST',
					'callback'            => 'rmb_llms_set_config',
					'permission_callback' => $admin_only,
					'args'                => array(
						'intro'                 => array(
							'required' => false,
							'type'     => 'string',
						),
						'sections'              => array(
							'required' => false,
							'type'     => 'object',
						),
						'custom_sections'       => array(
							'required' => false,
							'type'     => 'array',
						),
						'business_facts'        => array(
							'required' => false,
							'type'     => 'object',
						),
						'schema_source_post_id' => array(
							'required' => false,
							'type'     => 'integer',
						),
						'include_sitemaps'      => array(
							'required' => false,
							'type'     => 'boolean',
						),
						'include_lastmod'       => array(
							'required' => false,
							'type'     => 'boolean',
						),
						'exclude_noindex'       => array(
							'required' => false,
							'type'     => 'boolean',
						),
						'exclude_utility_pages' => array(
							'required' => false,
							'type'     => 'boolean',
						),
						'exclude_patterns'      => array(
							'required' => false,
							'type'     => 'array',
						),
						'group_by_intent'       => array(
							'required' => false,
							'type'     => 'boolean',
						),
						'max_description_chars' => array(
							'required' => false,
							'type'     => 'integer',
						),
					),
				),
			)
		);

		// ── llms.txt preview ──────────────────────────────────────────────────────
		register_rest_route(
			'rankrocket-seo/v1',
			'/llms/preview',
			array(
				'methods'             => 'GET',
				'callback'            => 'rmb_llms_preview',
				'permission_callback' => $admin_only,
				'args'                => array(
					'format' => array(
						'required' => false,
						'type'     => 'string',
						'enum'     => array( 'json', 'text' ),
						'default'  => 'json',
					),
				),
			)
		);

		// ── llms.txt regenerate ───────────────────────────────────────────────────
		register_rest_route(
			'rankrocket-seo/v1',
			'/llms-txt/regenerate',
			array(
				'methods'             => 'POST',
				'callback'            => 'rmb_llms_regenerate',
				'permission_callback' => $admin_only,
			)
		);

		// ── Sitemap config ─────────────────────────────────────────────────────────
		register_rest_route(
			'rankrocket-seo/v1',
			'/sitemap/preview',
			array(
				'methods'             => 'GET',
				'callback'            => 'rmb_sitemap_preview',
				'permission_callback' => $admin_only,
			)
		);

		// ── Canonical URL Set preview (G-18 alias) ────────────────────────────────
		register_rest_route(
			'rankrocket-seo/v1',
			'/canonical-urls/preview',
			array(
				'methods'             => 'GET',
				'callback'            => 'rmb_sitemap_preview',
				'permission_callback' => $admin_only,
			)
		);

		// ── Sitemap / discovery exclusions (G-09, G-17) ───────────────────────────
		register_rest_route(
			'rankrocket-seo/v1',
			'/sitemap/exclusions',
			array(
				array(
					'methods'             => 'GET',
					'callback'            => 'rmb_sitemap_exclusions_get',
					'permission_callback' => $admin_only,
				),
				array(
					'methods'             => 'POST',
					'callback'            => 'rmb_sitemap_exclusions_update',
					'permission_callback' => $admin_only,
					'args'                => array(
						'excluded_term_ids'   => array(
							'required' => false,
							'type'     => 'array',
							'items'    => array( 'type' => 'integer' ),
						),
						'excluded_term_slugs' => array(
							'required' => false,
							'type'     => 'array',
							'items'    => array( 'type' => 'string' ),
						),
						'excluded_taxonomies' => array(
							'required' => false,
							'type'     => 'array',
							'items'    => array( 'type' => 'string' ),
						),
						'excluded_post_slugs' => array(
							'required' => false,
							'type'     => 'array',
							'items'    => array( 'type' => 'string' ),
						),
					),
				),
			)
		);

		// ── Snippets ──────────────────────────────────────────────────────────────
		register_rest_route(
			'rankrocket-seo/v1',
			'/snippets',
			array(
				array(
					'methods'             => 'GET',
					'callback'            => 'rmb_snippets_list',
					'permission_callback' => $admin_only,
				),
				array(
					'methods'             => 'POST',
					'callback'            => 'rmb_snippets_create',
					'permission_callback' => $admin_only,
					'args'                => array(
						'title'           => array(
							'required' => true,
							'type'     => 'string',
						),
						'content'         => array(
							'required' => false,
							'type'     => 'string',
						),
						'code'            => array(
							'required' => false,
							'type'     => 'string',
						),
						'location'        => array(
							'required' => false,
							'type'     => 'string',
							'default'  => 'footer',
						),
						'display_on'      => array(
							'required' => false,
							'type'     => 'string',
							'default'  => 'entire_website',
						),
						'status'          => array(
							'required' => false,
							'type'     => 'string',
							'default'  => 'active',
						),
						'display_on_user' => array(
							'required' => false,
							'type'     => 'string',
							'enum'     => array( 'all', 'anonymous', 'logged_in' ),
							'default'  => 'all',
						),
					),
				),
			)
		);

		// ── Redirects (issue #21 Stage 1) ────────────────────────────────────────
		register_rest_route(
			'rankrocket-seo/v1',
			'/redirects',
			array(
				array(
					'methods'             => 'GET',
					'callback'            => 'rmb_redirects_list',
					'permission_callback' => $admin_only,
				),
				array(
					'methods'             => 'POST',
					'callback'            => 'rmb_redirects_create',
					'permission_callback' => $admin_only,
					'args'                => array(
						'source'      => array(
							'required' => true,
							'type'     => 'string',
						),
						'target'      => array(
							'required' => true,
							'type'     => 'string',
						),
						'status_code' => array(
							'required' => false,
							'type'     => 'integer',
						),
						'match_type'  => array(
							'required' => false,
							'type'     => 'string',
						),
						'enabled'     => array(
							'required' => false,
							'type'     => 'boolean',
						),
						'dry_run'     => array(
							'required' => false,
							'type'     => 'boolean',
							'default'  => false,
						),
					),
				),
			)
		);

		// MUST be registered BEFORE the {id} wildcard (same gotcha as /snippets/bulk).
		register_rest_route(
			'rankrocket-seo/v1',
			'/redirects/bulk',
			array(
				'methods'             => 'POST',
				'callback'            => 'rmb_redirects_bulk_create',
				'permission_callback' => $admin_only,
				'args'                => array(
					'redirects' => array(
						'required' => true,
						'type'     => 'array',
						'items'    => array( 'type' => 'object' ),
					),
					'dry_run'   => array(
						'required' => false,
						'type'     => 'boolean',
						'default'  => false,
					),
				),
			)
		);

		register_rest_route(
			'rankrocket-seo/v1',
			'/redirects/preview',
			array(
				'methods'             => 'POST',
				'callback'            => 'rmb_redirects_preview',
				'permission_callback' => $admin_only,
				'args'                => array(
					'url' => array(
						'required' => true,
						'type'     => 'string',
					),
				),
			)
		);

		register_rest_route(
			'rankrocket-seo/v1',
			'/redirects/(?P<id>[a-zA-Z0-9_-]+)',
			array(
				array(
					'methods'             => 'GET',
					'callback'            => 'rmb_redirects_get_single',
					'permission_callback' => $admin_only,
				),
				array(
					'methods'             => 'POST',
					'callback'            => 'rmb_redirects_update',
					'permission_callback' => $admin_only,
					'args'                => array(
						'source'      => array(
							'required' => false,
							'type'     => 'string',
						),
						'target'      => array(
							'required' => false,
							'type'     => 'string',
						),
						'status_code' => array(
							'required' => false,
							'type'     => 'integer',
						),
						'match_type'  => array(
							'required' => false,
							'type'     => 'string',
						),
						'enabled'     => array(
							'required' => false,
							'type'     => 'boolean',
						),
						'dry_run'     => array(
							'required' => false,
							'type'     => 'boolean',
							'default'  => false,
						),
					),
				),
				array(
					'methods'             => 'DELETE',
					'callback'            => 'rmb_redirects_delete',
					'permission_callback' => $admin_only,
				),
			)
		);

		// ── Performance module (G-04, G-05) ─────────────────────────────────────
		register_rest_route(
			'rankrocket-seo/v1',
			'/perf/dequeue-rules',
			array(
				array(
					'methods'             => 'GET',
					'callback'            => 'rmb_perf_dequeue_get',
					'permission_callback' => $admin_only,
				),
				array(
					'methods'             => 'POST',
					'callback'            => 'rmb_perf_dequeue_update',
					'permission_callback' => $admin_only,
					'args'                => array(
						'rules' => array(
							'required' => true,
							'type'     => 'array',
							'items'    => array( 'type' => 'object' ),
						),
					),
				),
			)
		);

		register_rest_route(
			'rankrocket-seo/v1',
			'/perf/defer-handles',
			array(
				array(
					'methods'             => 'GET',
					'callback'            => 'rmb_perf_defer_get',
					'permission_callback' => $admin_only,
				),
				array(
					'methods'             => 'POST',
					'callback'            => 'rmb_perf_defer_update',
					'permission_callback' => $admin_only,
					'args'                => array(
						'handles' => array(
							'required' => true,
							'type'     => 'array',
							'items'    => array( 'type' => 'string' ),
						),
					),
				),
			)
		);

		// ── Elementor cache repair (G-07) ───────────────────────────────────────
		register_rest_route(
			'rankrocket-seo/v1',
			'/elementor/repair-cache',
			array(
				'methods'             => 'POST',
				'callback'            => 'rmb_elementor_repair_cache',
				'permission_callback' => $admin_only,
				'args'                => array(
					'post_id'  => array(
						'required' => false,
						'type'     => 'integer',
					),
					'post_ids' => array(
						'required' => false,
						'type'     => 'array',
						'items'    => array( 'type' => 'integer' ),
					),
				),
			)
		);

		// ── Bulk snippet create (G-10) ───────────────────────────────────────────
		// MUST be registered BEFORE the {id} wildcard.
		register_rest_route(
			'rankrocket-seo/v1',
			'/snippets/bulk',
			array(
				'methods'             => 'POST',
				'callback'            => 'rmb_snippets_bulk_create',
				'permission_callback' => $admin_only,
				'args'                => array(
					'snippets' => array(
						'required' => true,
						'type'     => 'array',
						'items'    => array( 'type' => 'object' ),
					),
					'dry_run'  => array(
						'required' => false,
						'type'     => 'boolean',
						'default'  => false,
					),
				),
			)
		);

		// ── Snippets: Get / Update / Delete by ID (wildcard — after /bulk) ────────
		register_rest_route(
			'rankrocket-seo/v1',
			'/snippets/(?P<id>[a-zA-Z0-9_-]+)',
			array(
				array(
					'methods'             => 'GET',
					'callback'            => 'rmb_snippets_get_single',
					'permission_callback' => $admin_only,
				),
				array(
					'methods'             => 'POST',
					'callback'            => 'rmb_snippets_update',
					'permission_callback' => $admin_only,
					'args'                => array(
						'display_on_user' => array(
							'required' => false,
							'type'     => 'string',
							'enum'     => array( 'all', 'anonymous', 'logged_in' ),
						),
					),
				),
				array(
					'methods'             => 'DELETE',
					'callback'            => 'rmb_snippets_delete',
					'permission_callback' => $admin_only,
				),
			)
		);

		// ── Cache ─────────────────────────────────────────────────────────────────
		register_rest_route(
			'rankrocket-seo/v1',
			'/cache/purge',
			array(
				'methods'             => 'POST',
				'callback'            => 'rmb_cache_purge',
				'permission_callback' => $admin_only,
			)
		);

		// ── Status ────────────────────────────────────────────────────────────────
		register_rest_route(
			'rankrocket-seo/v1',
			'/status',
			array(
				'methods'             => 'GET',
				'callback'            => 'rmb_status',
				'permission_callback' => $admin_only,
			)
		);

		// ── Capabilities ──────────────────────────────────────────────────────────
		register_rest_route(
			'rankrocket-seo/v1',
			'/capabilities',
			array(
				'methods'             => 'GET',
				'callback'            => 'rmb_capabilities_get',
				'permission_callback' => $admin_only,
			)
		);

		// ── Force update check ────────────────────────────────────────────────────
		register_rest_route(
			'rankrocket-seo/v1',
			'/check-updates',
			array(
				'methods'             => 'POST',
				'callback'            => 'rmb_check_updates',
				'permission_callback' => $admin_only,
			)
		);

		// ── robots.txt ────────────────────────────────────────────────────────────
		register_rest_route(
			'rankrocket-seo/v1',
			'/robots-txt',
			array(
				array(
					'methods'             => 'GET',
					'callback'            => 'rmb_robots_get',
					'permission_callback' => $admin_only,
				),
				array(
					'methods'             => 'POST',
					'callback'            => 'rmb_robots_set',
					'permission_callback' => $admin_only,
					'args'                => array(
						'content'                  => array(
							'required' => true,
							'type'     => 'string',
						),
						'ensure_sitemap_directive' => array(
							'required' => false,
							'type'     => 'boolean',
							'default'  => false,
						),
						'preferred_sitemap_only'   => array(
							'required' => false,
							'type'     => 'boolean',
							'default'  => true,
						),
					),
				),
			)
		);

		// ── AEO/GEO audit data layer ─────────────────────────────────────────────
		register_rest_route(
			'rankrocket-seo/v1',
			'/aeo-geo/readiness',
			array(
				'methods'             => 'GET',
				'callback'            => 'rmb_aeo_geo_readiness',
				'permission_callback' => $admin_only,
			)
		);

		register_rest_route(
			'rankrocket-seo/v1',
			'/aeo-geo/entity',
			array(
				'methods'             => 'GET',
				'callback'            => 'rmb_aeo_geo_entity',
				'permission_callback' => $admin_only,
			)
		);

		register_rest_route(
			'rankrocket-seo/v1',
			'/aeo-geo/schema-audit',
			array(
				'methods'             => 'GET',
				'callback'            => 'rmb_aeo_geo_schema_audit',
				'permission_callback' => $admin_only,
			)
		);

		register_rest_route(
			'rankrocket-seo/v1',
			'/aeo-geo/source-sync',
			array(
				'methods'             => 'GET',
				'callback'            => 'rmb_aeo_geo_source_sync',
				'permission_callback' => $admin_only,
			)
		);

		// ── v3.0 Bite 1: Observation endpoints (read-only, no state mutation) ─────
		register_rest_route(
			'rankrocket-seo/v1',
			'/observe/heading-hierarchy/(?P<post_id>\d+)',
			array(
				'methods'             => 'GET',
				'callback'            => 'rmb_observe_heading_hierarchy',
				'permission_callback' => $admin_only,
			)
		);

		register_rest_route(
			'rankrocket-seo/v1',
			'/observe/broken-links',
			array(
				'methods'             => 'GET',
				'callback'            => 'rmb_observe_broken_links',
				'permission_callback' => $admin_only,
				'args'                => array(
					'page'             => array(
						'required' => false,
						'type'     => 'integer',
						'default'  => 1,
					),
					'per_page'         => array(
						'required' => false,
						'type'     => 'integer',
						'default'  => 20,
					),
					'post_type'        => array(
						'required' => false,
						'type'     => 'string',
						'default'  => '',
					),
					'include_external' => array(
						'required' => false,
						'type'     => 'boolean',
						'default'  => true,
					),
				),
			)
		);

		register_rest_route(
			'rankrocket-seo/v1',
			'/observe/alt-coverage',
			array(
				'methods'             => 'GET',
				'callback'            => 'rmb_observe_alt_coverage',
				'permission_callback' => $admin_only,
			)
		);

		register_rest_route(
			'rankrocket-seo/v1',
			'/observe/schema-graph/(?P<post_id>\d+)',
			array(
				'methods'             => 'GET',
				'callback'            => 'rmb_observe_schema_graph',
				'permission_callback' => $admin_only,
			)
		);

		register_rest_route(
			'rankrocket-seo/v1',
			'/observe/llms-diff',
			array(
				'methods'             => 'GET',
				'callback'            => 'rmb_observe_llms_diff',
				'permission_callback' => $admin_only,
			)
		);

		// ── Agentic Browsing diagnostics (issue #24) ─────────────────────────────
		register_rest_route(
			'rankrocket-seo/v1',
			'/observe/agentic-browsing/(?P<post_id>\d+)',
			array(
				'methods'             => 'GET',
				'callback'            => 'rmb_observe_agentic_browsing',
				'permission_callback' => $admin_only,
			)
		);

		// ── v3.0 Bite 2: typed action engine ─────────────────────────────────────
		$action_args = array(
			'action_type' => array(
				'required' => true,
				'type'     => 'string',
			),
			'target_id'   => array(
				'required' => false,
			),
			'payload'     => array(
				'required' => false,
				'type'     => 'object',
			),
			'dry_run'     => array(
				'required' => false,
				'type'     => 'boolean',
				'default'  => false,
			),
		);

		register_rest_route(
			'rankrocket-seo/v1',
			'/actions/dry-run',
			array(
				'methods'             => 'POST',
				'callback'            => 'rmb_actions_dry_run',
				'permission_callback' => $admin_only,
				'args'                => $action_args,
			)
		);

		register_rest_route(
			'rankrocket-seo/v1',
			'/actions/execute',
			array(
				'methods'             => 'POST',
				'callback'            => 'rmb_actions_execute',
				'permission_callback' => $admin_only,
				'args'                => $action_args,
			)
		);

		// ── v3.0 Bite 3: rollback layer ──────────────────────────────────────────
		// action_id pattern matches rr_action_id() output only, so these routes
		// cannot shadow /actions/dry-run or /actions/execute.
		register_rest_route(
			'rankrocket-seo/v1',
			'/actions/(?P<action_id>rrseo-action-\d{14}-[0-9a-f]{8})',
			array(
				'methods'             => 'GET',
				'callback'            => 'rmb_actions_get',
				'permission_callback' => $admin_only,
			)
		);

		register_rest_route(
			'rankrocket-seo/v1',
			'/actions/(?P<action_id>rrseo-action-\d{14}-[0-9a-f]{8})/rollback',
			array(
				'methods'             => 'POST',
				'callback'            => 'rmb_actions_rollback',
				'permission_callback' => $admin_only,
				'args'                => array(
					'dry_run' => array(
						'required' => false,
						'type'     => 'boolean',
						'default'  => false,
					),
					'force'   => array(
						'required' => false,
						'type'     => 'boolean',
						'default'  => false,
					),
				),
			)
		);

		// ── Legacy migration ──────────────────────────────────────────────────────
		register_rest_route(
			'rankrocket-seo/v1',
			'/migrate-legacy',
			array(
				'methods'             => 'POST',
				'callback'            => 'rmb_migrate_legacy',
				'permission_callback' => $admin_only,
				'args'                => array(
					'post_ids' => array(
						'required' => true,
						'type'     => 'array',
					),
					'dry_run'  => array(
						'required' => false,
						'type'     => 'boolean',
						'default'  => false,
					),
				),
			)
		);
	}
);


// ── SEO Meta Handlers ─────────────────────────────────────────────────────────
/**
 * Handles POST /update — writes SEO meta for a single post or taxonomy term.
 *
 * The post_id parameter accepts both post IDs and term IDs; the handler
 * resolves which type it received and routes writes accordingly.
 *
 * @param WP_REST_Request $request REST request object.
 * @return WP_REST_Response|WP_Error
 */
function rmb_update_meta( WP_REST_Request $request ) {
	$id         = intval( $request->get_param( 'post_id' ) );
	$resolved   = rr_resolve_id( $id );
	$url_fields = array( 'og_image', 'canonical', 'twitter_image' );
	$raw_fields = array();

	if ( 'none' === $resolved['type'] ) {
		return new WP_Error(
			'not_found',
			"ID {$id} does not resolve to a post or term.",
			array( 'status' => 422 )
		);
	}

	foreach ( RR_SEO_META_KEYS as $param => $native_key ) {
		$value = $request->get_param( $param );
		if ( null !== $value && '' !== $value ) {
			$raw_fields[ $param ] = $value;
		}
	}

	// Pass $id for posts so rr_validate_seo_fields() checks post type; pass null for terms.
	$validation_id = 'post' === $resolved['type'] ? $id : null;
	$validation    = rr_validate_seo_fields( $raw_fields, $validation_id );
	if ( ! empty( $validation['errors'] ) ) {
		return new WP_Error(
			'validation_failed',
			'Validation failed',
			array(
				'status'   => 422,
				'errors'   => $validation['errors'],
				'warnings' => $validation['warnings'],
			)
		);
	}

	$updated       = array();
	$audit_changes = array();
	$request_id    = rr_request_id( $request );
	$is_term       = 'term' === $resolved['type'];

	foreach ( $raw_fields as $param => $value ) {
		$meta_key = RR_SEO_META_KEYS[ $param ];
		if ( in_array( $param, $url_fields, true ) ) {
			$sanitized = esc_url_raw( $value );
		} elseif ( 'twitter_card' === $param ) {
			// sanitize_key lowercases and strips to [a-z0-9_-] — slug-like, permissive.
			$sanitized = sanitize_key( $value );
		} else {
			$sanitized = sanitize_text_field( $value );
		}
		if ( $is_term ) {
			$before = rr_get_term_seo_meta( $id, $param );
			update_term_meta( $id, $meta_key, $sanitized );
		} else {
			$before = rr_get_seo_meta( $id, $param );
			update_post_meta( $id, $meta_key, $sanitized );
		}
		$updated[ $meta_key ]    = $sanitized;
		$audit_changes[ $param ] = array(
			'before' => $before ? $before : '',
			'after'  => $sanitized,
		);
	}

	$unset_fields = $request->get_param( 'unset_fields' );
	if ( ! empty( $unset_fields ) ) {
		$valid_fields = array_keys( RR_SEO_META_KEYS );
		foreach ( $unset_fields as $param ) {
			if ( ! in_array( $param, $valid_fields, true ) ) {
				return new WP_Error(
					'invalid_unset_field',
					"'{$param}' is not a recognized SEO field.",
					array(
						'status'       => 422,
						'valid_fields' => $valid_fields,
					)
				);
			}
			if ( isset( $raw_fields[ $param ] ) ) {
				return new WP_Error(
					'unset_write_conflict',
					"'{$param}' cannot appear in both the write fields and unset_fields.",
					array( 'status' => 422 )
				);
			}
			$meta_key = RR_SEO_META_KEYS[ $param ];
			if ( $is_term ) {
				$before = rr_get_term_seo_meta( $id, $param );
				delete_term_meta( $id, $meta_key );
			} else {
				$before = rr_get_seo_meta( $id, $param );
				delete_post_meta( $id, $meta_key );
			}
			$updated[ $meta_key ]    = '';
			$audit_changes[ $param ] = array(
				'before' => $before ? $before : '',
				'after'  => '',
			);
		}
	}

	if ( $is_term ) {
		$term = $resolved['object'];
		wp_cache_delete( $id, 'term_meta' );
		clean_term_cache( $id, $term->taxonomy );
	} else {
		// llms_section classification meta is post-specific; not meaningful for terms.
		$section = $request->get_param( 'llms_section' );
		if ( null !== $section ) {
			$before_section = get_post_meta( $id, META_LLMS_SECTION, true );
			if ( '' === $section ) {
				delete_post_meta( $id, META_LLMS_SECTION );
				$audit_changes['llms_section'] = array(
					'before' => $before_section,
					'after'  => '',
				);
			} else {
				$section_validation = rr_validate_llms_section( sanitize_text_field( $section ) );
				if ( is_wp_error( $section_validation ) ) {
					return $section_validation;
				}
				update_post_meta( $id, META_LLMS_SECTION, sanitize_text_field( $section ) );
				$audit_changes['llms_section'] = array(
					'before' => $before_section,
					'after'  => $section,
				);
			}
		}
		wp_cache_delete( $id, 'post_meta' );
		clean_post_cache( $id );
	}

	if ( ! empty( $audit_changes ) ) {
		rr_audit_log( $id, '/update', $audit_changes, $request_id, 'written' );
	}

	return rest_ensure_response(
		array(
			'success'     => true,
			'object_id'   => $id,
			'object_type' => $resolved['type'],
			'post_id'     => $id,
			'updated'     => $updated,
			'warnings'    => $validation['warnings'],
		)
	);
}

/**
 * Handles GET /get/{id} — returns SEO meta for a single post or taxonomy term.
 *
 * @param WP_REST_Request $request REST request object.
 * @return WP_REST_Response|WP_Error
 */
function rmb_get_meta( WP_REST_Request $request ) {
	$id       = intval( $request->get_param( 'id' ) );
	$resolved = rr_resolve_id( $id );

	if ( 'none' === $resolved['type'] ) {
		return new WP_Error( 'not_found', "ID {$id} does not resolve to a post or term.", array( 'status' => 404 ) );
	}

	if ( 'term' === $resolved['type'] ) {
		$term = $resolved['object'];
		$meta = array();
		foreach ( array_keys( RR_SEO_META_KEYS ) as $field ) {
			$meta[ RR_SEO_META_KEYS[ $field ] ] = rr_get_term_seo_meta( $id, $field );
		}
		$meta['rr_seo_canonical']           = $meta['_rr_seo_canonical'] ?? '';
		$meta['rr_seo_twitter_card']        = $meta['_rr_seo_twitter_card'] ?? '';
		$meta['rr_seo_twitter_title']       = $meta['_rr_seo_twitter_title'] ?? '';
		$meta['rr_seo_twitter_description'] = $meta['_rr_seo_twitter_description'] ?? '';
		$meta['rr_seo_twitter_image']       = $meta['_rr_seo_twitter_image'] ?? '';
		return rest_ensure_response(
			array(
				'object_id'   => $id,
				'object_type' => 'term',
				'post_id'     => $id,
				'term_name'   => $term->name,
				'term_slug'   => $term->slug,
				'taxonomy'    => $term->taxonomy,
				'meta'        => $meta,
			)
		);
	}

	$post_id = $id;
	$meta    = array();
	foreach ( RR_SEO_META_KEYS as $field => $native_key ) {
		$meta[ $native_key ] = rr_get_seo_meta( $post_id, $field );
	}
	$meta['rr_seo_score'] = get_post_meta( $post_id, 'rank_math_seo_score', true );

	// Alias the underscore-prefixed canonical/twitter keys so external consumers can
	// reference them without knowing they are stored as hidden post meta.
	$meta['rr_seo_canonical']           = $meta['_rr_seo_canonical'] ?? '';
	$meta['rr_seo_twitter_card']        = $meta['_rr_seo_twitter_card'] ?? '';
	$meta['rr_seo_twitter_title']       = $meta['_rr_seo_twitter_title'] ?? '';
	$meta['rr_seo_twitter_description'] = $meta['_rr_seo_twitter_description'] ?? '';
	$meta['rr_seo_twitter_image']       = $meta['_rr_seo_twitter_image'] ?? '';

	$thumb_id                    = get_post_thumbnail_id( $post_id );
	$meta['_featured_image_url'] = $thumb_id ? wp_get_attachment_image_url( $thumb_id, 'large' ) : '';

	// llms.txt section classification metadata.
	$stored_section    = get_post_meta( $post_id, META_LLMS_SECTION, true );
	$config            = get_option( RR_LLMS_CONFIG_KEY, get_option( 'rmb_llms_config', array() ) );
	$sections_config   = ( ! empty( $config['sections'] ) && is_array( $config['sections'] ) && ! isset( $config['sections'][0] ) )
		? $config['sections']
		: array();
	$section_warnings  = array();
	$effective_section = $stored_section;
	if ( '' !== $stored_section && ! empty( $sections_config ) && ! isset( $sections_config[ $stored_section ] ) ) {
		// Stale key — report it.
		$effective_section  = '';
		$section_warnings[] = array(
			'code'              => 'stale_section_key',
			'stored_section'    => $stored_section,
			'effective_section' => '',
			'message'           => 'Stored llms_section is not present in current llms section config.',
		);
	}

	return rest_ensure_response(
		array(
			'object_id'              => $post_id,
			'object_type'            => 'post',
			'post_id'                => $post_id,
			'meta'                   => $meta,
			'llms_section'           => $stored_section,
			'effective_llms_section' => $effective_section,
			'llms_warnings'          => $section_warnings,
		)
	);
}

/**
 * Handles POST /meta/bulk-get — returns SEO meta for multiple posts.
 *
 * @param WP_REST_Request $request REST request object.
 * @return WP_REST_Response|WP_Error
 */
function rmb_meta_bulk_get( WP_REST_Request $request ) {
	$post_ids = array_map( 'intval', $request->get_param( 'post_ids' ) );

	if ( count( $post_ids ) > rrseo_batch_max() ) {
		return new WP_Error( 'batch_too_large', 'Batch size exceeds maximum of ' . rrseo_batch_max(), array( 'status' => 422 ) );
	}

	$results = array();
	foreach ( $post_ids as $pid ) {
		$post = get_post( $pid );
		if ( ! $post ) {
			continue;
		}
		$meta = array();
		foreach ( RR_SEO_META_KEYS as $field => $native_key ) {
			$meta[ $native_key ] = rr_get_seo_meta( $pid, $field );
		}
		$meta['rr_seo_score']               = get_post_meta( $pid, 'rank_math_seo_score', true );
		$meta['rr_seo_canonical']           = $meta['_rr_seo_canonical'] ?? '';
		$meta['rr_seo_twitter_card']        = $meta['_rr_seo_twitter_card'] ?? '';
		$meta['rr_seo_twitter_title']       = $meta['_rr_seo_twitter_title'] ?? '';
		$meta['rr_seo_twitter_description'] = $meta['_rr_seo_twitter_description'] ?? '';
		$meta['rr_seo_twitter_image']       = $meta['_rr_seo_twitter_image'] ?? '';
		$stored_section                     = get_post_meta( $pid, META_LLMS_SECTION, true );
		$results[]                          = array(
			'post_id'                => $pid,
			'slug'                   => $post->post_name,
			'title'                  => get_the_title( $post ),
			'meta'                   => $meta,
			'llms_section'           => $stored_section,
			'effective_llms_section' => $stored_section,
		);
	}
	return rest_ensure_response(
		array(
			'count' => count( $results ),
			'pages' => $results,
		)
	);
}

/**
 * Handles POST /meta/bulk-update — writes SEO meta for multiple posts.
 *
 * @param WP_REST_Request $request REST request object.
 * @return WP_REST_Response|WP_Error
 */
function rmb_meta_bulk_update( WP_REST_Request $request ) {
	$updates    = $request->get_param( 'updates' );
	$dry_run    = (bool) $request->get_param( 'dry_run' );
	$url_fields = array( 'og_image', 'canonical', 'twitter_image' );
	$request_id = rr_request_id( $request );

	if ( count( $updates ) > rrseo_batch_max() ) {
		return new WP_Error( 'batch_too_large', 'Batch size exceeds maximum of ' . rrseo_batch_max(), array( 'status' => 422 ) );
	}

	$results = array();
	foreach ( $updates as $upd ) {
		$post_id = intval( $upd['post_id'] ?? 0 );

		$raw_fields = array();
		foreach ( RR_SEO_META_KEYS as $param => $native_key ) {
			if ( isset( $upd[ $param ] ) && '' !== $upd[ $param ] ) {
				$raw_fields[ $param ] = $upd[ $param ];
			}
		}

		$validation = rr_validate_seo_fields( $raw_fields, $post_id ? $post_id : null );
		if ( ! empty( $validation['errors'] ) ) {
			$results[] = array(
				'post_id'  => $post_id,
				'success'  => false,
				'errors'   => $validation['errors'],
				'warnings' => $validation['warnings'],
			);
			continue;
		}

		$changes       = array();
		$updated       = array();
		$audit_changes = array();

		foreach ( $raw_fields as $param => $value ) {
			$meta_key = RR_SEO_META_KEYS[ $param ];
			$before   = rr_get_seo_meta( $post_id, $param );
			if ( in_array( $param, $url_fields, true ) ) {
				$sanitized = esc_url_raw( $value );
			} elseif ( 'twitter_card' === $param ) {
				$sanitized = sanitize_key( $value );
			} else {
				$sanitized = sanitize_text_field( $value );
			}
			$changes[ $param ] = array(
				'before' => $before ? $before : '',
				'after'  => $sanitized,
			);
			if ( ! $dry_run ) {
				update_post_meta( $post_id, $meta_key, $sanitized );
				$updated[ $meta_key ]    = $value;
				$audit_changes[ $param ] = $changes[ $param ];
			}
		}

		// Handle llms_section per-item if provided.
		$item_section = isset( $upd['llms_section'] ) ? $upd['llms_section'] : null;
		if ( null !== $item_section ) {
			$before_section = get_post_meta( $post_id, META_LLMS_SECTION, true );
			if ( '' === $item_section ) {
				$changes['llms_section'] = array(
					'before' => $before_section,
					'after'  => '',
				);
				if ( ! $dry_run ) {
					delete_post_meta( $post_id, META_LLMS_SECTION );
					$audit_changes['llms_section'] = $changes['llms_section'];
				}
			} else {
				$sv = rr_validate_llms_section( sanitize_text_field( $item_section ) );
				if ( ! is_wp_error( $sv ) ) {
					$changes['llms_section'] = array(
						'before' => $before_section,
						'after'  => $item_section,
					);
					if ( ! $dry_run ) {
						update_post_meta( $post_id, META_LLMS_SECTION, sanitize_text_field( $item_section ) );
						$audit_changes['llms_section'] = $changes['llms_section'];
					}
				}
			}
		}

		if ( ! $dry_run ) {
			wp_cache_delete( $post_id, 'post_meta' );
			clean_post_cache( $post_id );

			if ( ! empty( $audit_changes ) ) {
				rr_audit_log( $post_id, '/meta/bulk-update', $audit_changes, $request_id, 'written' );
			}
		}

		if ( $dry_run ) {
			$results[] = array(
				'post_id'  => $post_id,
				'dry_run'  => true,
				'changes'  => $changes,
				'warnings' => $validation['warnings'],
				'valid'    => true,
			);
		} else {
			$results[] = array(
				'post_id'  => $post_id,
				'success'  => true,
				'updated'  => $updated,
				'warnings' => $validation['warnings'],
			);
		}
	}
	return rest_ensure_response(
		array(
			'dry_run' => $dry_run,
			'count'   => count( $results ),
			'results' => $results,
		)
	);
}


// ── Preview / Dry-run Handler ─────────────────────────────────────────────────
/**
 * Handles POST /preview-update — validates and diffs without writing to DB.
 *
 * @param WP_REST_Request $request REST request object.
 * @return WP_REST_Response
 */
function rmb_preview_update( WP_REST_Request $request ) {
	$post_id  = intval( $request->get_param( 'post_id' ) );
	$resolved = rr_resolve_id( $post_id );
	if ( 'term' === $resolved['type'] ) {
		return new WP_Error(
			'term_not_supported',
			'/preview-update does not support term IDs. Use POST /update to write term meta directly.',
			array( 'status' => 422 )
		);
	}

	$raw_fields = array();
	foreach ( RR_SEO_META_KEYS as $param => $native_key ) {
		$value = $request->get_param( $param );
		if ( null !== $value && '' !== $value ) {
			$raw_fields[ $param ] = $value;
		}
	}

	$validation = rr_validate_seo_fields( $raw_fields, $post_id );

	$changes = array();
	foreach ( $raw_fields as $param => $value ) {
		$current           = rr_get_seo_meta( $post_id, $param );
		$changes[ $param ] = array(
			'before' => $current ? $current : '',
			'after'  => $value,
		);
	}

	return rest_ensure_response(
		array(
			'post_id'  => $post_id,
			'changes'  => $changes,
			'warnings' => $validation['warnings'],
			'errors'   => $validation['errors'],
			'valid'    => empty( $validation['errors'] ),
		)
	);
}


// ── Schema Handlers ───────────────────────────────────────────────────────────
/**
 * Handles GET /schema/{post_id} — returns the stored JSON-LD schema.
 *
 * @param WP_REST_Request $request REST request object.
 * @return WP_REST_Response|WP_Error
 */
function rmb_schema_get( WP_REST_Request $request ) {
	$post_id = intval( $request->get_param( 'post_id' ) );
	if ( ! get_post( $post_id ) ) {
		return new WP_Error( 'invalid_post', 'Post not found', array( 'status' => 404 ) );
	}
	$schema = get_post_meta( $post_id, RR_SCHEMA_META_KEY, true );
	return rest_ensure_response(
		array(
			'post_id' => $post_id,
			'schema'  => $schema ? $schema : null,
		)
	);
}

/**
 * Handles POST /schema/{post_id} — validates and stores a JSON-LD schema.
 *
 * @param WP_REST_Request $request REST request object.
 * @return WP_REST_Response|WP_Error
 */
function rmb_schema_set( WP_REST_Request $request ) {
	$post_id = intval( $request->get_param( 'post_id' ) );
	$dry_run = (bool) $request->get_param( 'dry_run' );
	$schema  = $request->get_param( 'schema' );

	if ( ! get_post( $post_id ) ) {
		return new WP_Error( 'invalid_post', 'Post not found', array( 'status' => 404 ) );
	}

	$validation = rr_validate_schema( $schema );
	if ( ! empty( $validation['errors'] ) ) {
		return new WP_Error(
			'validation_failed',
			'Schema validation failed',
			array(
				'status'   => isset( $validation['status'] ) ? $validation['status'] : 422,
				'errors'   => $validation['errors'],
				'warnings' => $validation['warnings'],
			)
		);
	}

	// Optional issue #23 field: schema.org @type names to strip from
	// third-party JSON-LD on this post. Omitted -> leave the stored list
	// unchanged; [] -> clear it; independent of the schema write above.
	$strip_third_party_raw = $request->get_param( 'strip_third_party' );
	$strip_third_party     = null;
	if ( null !== $strip_third_party_raw ) {
		$strip_validation = rr_validate_schema_strip_third_party( $strip_third_party_raw );
		if ( ! empty( $strip_validation['errors'] ) ) {
			return new WP_Error(
				'validation_failed',
				'strip_third_party validation failed',
				array(
					'status' => 422,
					'errors' => $strip_validation['errors'],
				)
			);
		}
		$strip_third_party = $strip_validation['normalized'];
	}

	$clean_schema  = $validation['schema'];
	$before_schema = get_post_meta( $post_id, RR_SCHEMA_META_KEY, true );
	$before        = $before_schema ? $before_schema : null;
	$node_count    = isset( $clean_schema['@graph'] ) ? count( $clean_schema['@graph'] ) : 1;

	if ( ! $dry_run ) {
		update_post_meta( $post_id, RR_SCHEMA_META_KEY, $clean_schema );

		if ( null !== $strip_third_party ) {
			if ( empty( $strip_third_party ) ) {
				delete_post_meta( $post_id, RR_SCHEMA_STRIP_KEY );
			} else {
				update_post_meta( $post_id, RR_SCHEMA_STRIP_KEY, $strip_third_party );
			}
		}

		rr_audit_log(
			$post_id,
			'/schema',
			array(
				'schema' => array(
					'before'           => $before,
					'after'            => $clean_schema,
					'graph_node_count' => $node_count,
					'bytes'            => strlen( wp_json_encode( $clean_schema ) ),
				),
			),
			rr_request_id( $request ),
			'written'
		);
	}

	if ( null !== $strip_third_party ) {
		$strip_response = $strip_third_party;
	} else {
		$stored_strip   = get_post_meta( $post_id, RR_SCHEMA_STRIP_KEY, true );
		$strip_response = is_array( $stored_strip ) ? $stored_strip : array();
	}

	return rest_ensure_response(
		array(
			'post_id'           => $post_id,
			'dry_run'           => $dry_run,
			'valid'             => true,
			'warnings'          => $validation['warnings'],
			'schema'            => $clean_schema,
			'strip_third_party' => $strip_response,
		)
	);
}


// ── Audit Log Handler ─────────────────────────────────────────────────────────
/**
 * Handles GET /log/{post_id} — returns the audit log for a post.
 *
 * @param WP_REST_Request $request REST request object.
 * @return WP_REST_Response|WP_Error
 */
function rmb_log_get( WP_REST_Request $request ) {
	$post_id = intval( $request->get_param( 'post_id' ) );
	if ( ! get_post( $post_id ) ) {
		return new WP_Error( 'invalid_post', 'Post not found', array( 'status' => 404 ) );
	}
	$log = get_post_meta( $post_id, RR_CHANGE_LOG_KEY, true );
	$log = is_array( $log ) ? $log : array();
	return rest_ensure_response(
		array(
			'post_id' => $post_id,
			'count'   => count( $log ),
			'log'     => array_reverse( $log ), // Most recent first.
		)
	);
}


// ── Image ALT Handlers ────────────────────────────────────────────────────────
/**
 * Handles GET /images — returns paginated list of media library images with ALT status.
 *
 * @param WP_REST_Request $request REST request object.
 * @return WP_REST_Response
 */
function rmb_images_list( WP_REST_Request $request ) {
	$page     = max( 1, intval( $request->get_param( 'page' ) ?? 1 ) );
	$per_page = min( 100, max( 10, intval( $request->get_param( 'per_page' ) ?? 50 ) ) );

	$attachments = get_posts(
		array(
			'post_type'      => 'attachment',
			'post_mime_type' => 'image',
			'post_status'    => 'inherit',
			'posts_per_page' => $per_page,
			'paged'          => $page,
			'orderby'        => 'date',
			'order'          => 'DESC',
		)
	);

	$images = array();
	foreach ( $attachments as $att ) {
		$alt      = get_post_meta( $att->ID, '_wp_attachment_image_alt', true );
		$images[] = array(
			'id'       => $att->ID,
			'filename' => basename( get_attached_file( $att->ID ) ),
			'url'      => wp_get_attachment_url( $att->ID ),
			'alt'      => $alt ? $alt : '',
			'title'    => $att->post_title,
			'caption'  => $att->post_excerpt,
			'missing'  => empty( $alt ),
		);
	}

	return rest_ensure_response(
		array(
			'page'              => $page,
			'per_page'          => $per_page,
			'count'             => count( $images ),
			'images'            => $images,
			'missing_alt_count' => count( array_filter( $images, fn( $i ) => $i['missing'] ) ),
		)
	);
}

/**
 * Handles POST /images/{id}/alt — sets the ALT text for a single attachment.
 *
 * @param WP_REST_Request $request REST request object.
 * @return WP_REST_Response|WP_Error
 */
function rmb_image_set_alt( WP_REST_Request $request ) {
	$id  = intval( $request->get_param( 'id' ) );
	$alt = sanitize_text_field( $request->get_param( 'alt' ) );

	if ( ! get_post( $id ) ) {
		return new WP_Error( 'not_found', 'Attachment not found', array( 'status' => 404 ) );
	}

	$before = get_post_meta( $id, '_wp_attachment_image_alt', true );
	update_post_meta( $id, '_wp_attachment_image_alt', $alt );

	return rest_ensure_response(
		array(
			'success'  => true,
			'id'       => $id,
			'filename' => basename( get_attached_file( $id ) ),
			'before'   => $before ? $before : '',
			'after'    => $alt,
		)
	);
}

/**
 * Handles GET /images/{id}/alt — returns current ALT text for a single attachment.
 *
 * @param WP_REST_Request $request REST request object.
 * @return WP_REST_Response|WP_Error
 */
function rmb_image_get_alt( WP_REST_Request $request ) {
	$id   = intval( $request->get_param( 'id' ) );
	$post = get_post( $id );
	if ( ! $post ) {
		return new WP_Error( 'not_found', 'Attachment not found', array( 'status' => 404 ) );
	}
	return rest_ensure_response(
		array(
			'id'       => $id,
			'url'      => wp_get_attachment_url( $id ),
			'filename' => basename( get_attached_file( $id ) ),
			'alt'      => get_post_meta( $id, '_wp_attachment_image_alt', true ),
			'title'    => get_the_title( $post ),
			'caption'  => $post->post_excerpt,
		)
	);
}

/**
 * Handles POST /images/bulk-alt — sets ALT text for multiple attachments.
 *
 * @param WP_REST_Request $request REST request object.
 * @return WP_REST_Response|WP_Error
 */
function rmb_images_bulk_alt( WP_REST_Request $request ) {
	$updates = $request->get_param( 'updates' );

	if ( count( $updates ) > rrseo_batch_max() ) {
		return new WP_Error( 'batch_too_large', 'Batch size exceeds maximum of ' . rrseo_batch_max(), array( 'status' => 422 ) );
	}

	$results = array();

	foreach ( $updates as $upd ) {
		$id  = intval( $upd['id'] ?? 0 );
		$alt = sanitize_text_field( $upd['alt'] ?? '' );

		if ( ! $id || ! get_post( $id ) ) {
			$results[] = array(
				'id'      => $id,
				'success' => false,
				'error'   => 'Attachment not found',
			);
			continue;
		}

		$before = get_post_meta( $id, '_wp_attachment_image_alt', true );
		update_post_meta( $id, '_wp_attachment_image_alt', $alt );
		$results[] = array(
			'id'       => $id,
			'filename' => basename( get_attached_file( $id ) ),
			'success'  => true,
			'before'   => $before ? $before : '',
			'after'    => $alt,
		);
	}

	return rest_ensure_response(
		array(
			'count'   => count( $results ),
			'results' => $results,
		)
	);
}


// ── Media Upload Validation ───────────────────────────────────────────────────
/**
 * Validates alt_text, source, and the is_placeholder/source pairing for a
 * media upload. Has no WP dependencies beyond RR_MEDIA_ALLOWED_SOURCES, so
 * it is unit-testable without a real file upload.
 *
 * @param string $alt_text       Candidate ALT text.
 * @param string $source         Candidate source value.
 * @param bool   $is_placeholder Whether is_placeholder was sent as true.
 * @return array{error: string|null, code: string|null}
 */
function rr_validate_media_fields( $alt_text, $source, $is_placeholder ) {
	if ( '' === trim( (string) $alt_text ) ) {
		return array(
			'error' => 'alt_text is required and cannot be empty',
			'code'  => 'invalid_alt_text',
		);
	}

	if ( ! in_array( $source, RR_MEDIA_ALLOWED_SOURCES, true ) ) {
		return array(
			'error' => "source '{$source}' not allowed. Allowed: " . implode( ', ', RR_MEDIA_ALLOWED_SOURCES ),
			'code'  => 'invalid_source',
		);
	}

	if ( $is_placeholder && 'ai_placeholder' !== $source ) {
		return array(
			'error' => "is_placeholder:true requires source:'ai_placeholder'",
			'code'  => 'invalid_source',
		);
	}

	return array(
		'error' => null,
		'code'  => null,
	);
}

/**
 * Validates a media file's byte size and detected MIME type against the
 * plugin's allowlist/cap. Has no WP dependencies beyond the two RR_MEDIA_*
 * constants, so it is unit-testable with a plain integer and string.
 *
 * @param int    $bytes File size in bytes.
 * @param string $mime  Detected MIME type (from wp_check_filetype_and_ext(),
 *                       not the client-supplied header), or '' if undetected.
 * @return array{error: string|null, code: string|null, status: int|null}
 */
function rr_validate_media_file( $bytes, $mime ) {
	if ( $bytes > RR_MEDIA_MAX_BYTES ) {
		return array(
			'error'  => 'File exceeds the ' . ( RR_MEDIA_MAX_BYTES / 1024 / 1024 ) . 'MB limit',
			'code'   => 'file_too_large',
			'status' => 413,
		);
	}

	if ( ! $mime || ! in_array( $mime, RR_MEDIA_ALLOWED_MIME_TYPES, true ) ) {
		return array(
			'error'  => "File type '" . ( $mime ? $mime : 'unknown' ) . "' not allowed. Allowed: " . implode( ', ', RR_MEDIA_ALLOWED_MIME_TYPES ),
			'code'   => 'invalid_mime_type',
			'status' => 415,
		);
	}

	return array(
		'error'  => null,
		'code'   => null,
		'status' => null,
	);
}


// ── Media Upload Handlers ─────────────────────────────────────────────────────
/**
 * Handles POST /media — validates and sideloads an image into the media
 * library, tagging it with _rrseo_media_source / _rrseo_media_placeholder
 * meta so programmatic page-builder workflows can track placeholder-vs-real
 * image state centrally.
 *
 * @param WP_REST_Request $request REST request object.
 * @return WP_REST_Response|WP_Error
 */
function rmb_media_upload( WP_REST_Request $request ) {
	$alt_text          = trim( (string) $request->get_param( 'alt_text' ) );
	$source            = (string) $request->get_param( 'source' );
	$is_placeholder    = (bool) $request->get_param( 'is_placeholder' );
	$dry_run           = (bool) $request->get_param( 'dry_run' );
	$attach_to_post_id = intval( $request->get_param( 'attach_to_post_id' ) );
	$filename          = $request->get_param( 'filename' );
	$title             = $request->get_param( 'title' );
	$caption           = $request->get_param( 'caption' );

	$field_check = rr_validate_media_fields( $alt_text, $source, $is_placeholder );
	if ( $field_check['error'] ) {
		return new WP_Error( $field_check['code'], $field_check['error'], array( 'status' => 422 ) );
	}

	if ( $attach_to_post_id && ! get_post( $attach_to_post_id ) ) {
		return new WP_Error( 'invalid_post', 'attach_to_post_id does not match an existing post', array( 'status' => 404 ) );
	}

	$files = $request->get_file_params();
	if ( empty( $files['file'] ) || UPLOAD_ERR_OK !== $files['file']['error'] ) {
		return new WP_Error( 'missing_file', 'file is required (multipart/form-data)', array( 'status' => 422 ) );
	}
	$file = $files['file'];
	if ( $filename ) {
		$file['name'] = sanitize_file_name( $filename );
	}

	// Verify the real file content, not just the client-supplied MIME header.
	$filetype = wp_check_filetype_and_ext( $file['tmp_name'], $file['name'] );
	$mime     = $filetype['type'];

	$file_check = rr_validate_media_file( (int) $file['size'], (string) $mime );
	if ( $file_check['error'] ) {
		return new WP_Error( $file_check['code'], $file_check['error'], array( 'status' => $file_check['status'] ) );
	}

	if ( $dry_run ) {
		return rest_ensure_response(
			array(
				'dry_run'   => true,
				'valid'     => true,
				'mime_type' => $mime,
				'bytes'     => (int) $file['size'],
				'alt_text'  => $alt_text,
				'source'    => $source,
			)
		);
	}

	require_once ABSPATH . 'wp-admin/includes/file.php';
	require_once ABSPATH . 'wp-admin/includes/media.php';
	require_once ABSPATH . 'wp-admin/includes/image.php';

	$post_data = array();
	if ( $caption ) {
		$post_data['post_excerpt'] = sanitize_text_field( $caption );
	}

	$media_id = media_handle_sideload( $file, $attach_to_post_id, $title ? sanitize_text_field( $title ) : null, $post_data );
	if ( is_wp_error( $media_id ) ) {
		return new WP_Error( 'upload_failed', $media_id->get_error_message(), array( 'status' => 500 ) );
	}

	update_post_meta( $media_id, '_wp_attachment_image_alt', $alt_text );
	update_post_meta( $media_id, RR_MEDIA_SOURCE_META_KEY, $source );
	update_post_meta( $media_id, RR_MEDIA_PLACEHOLDER_META_KEY, $is_placeholder ? '1' : '0' );

	$metadata = wp_get_attachment_metadata( $media_id );

	// Only per-post writes get an audit-log entry — rr_audit_log() is post
	// meta, and unattached library uploads (no attach_to_post_id) have no
	// post to attach one to.
	if ( $attach_to_post_id ) {
		rr_audit_log(
			$attach_to_post_id,
			'/media',
			array(
				'media' => array(
					'media_id'  => $media_id,
					'bytes'     => (int) $file['size'],
					'mime_type' => $mime,
					'source'    => $source,
				),
			),
			rr_request_id( $request ),
			'written'
		);
	}

	$response = rest_ensure_response(
		array(
			'media_id'   => $media_id,
			'source_url' => wp_get_attachment_url( $media_id ),
			'mime_type'  => $mime,
			'bytes'      => (int) $file['size'],
			'width'      => isset( $metadata['width'] ) ? $metadata['width'] : null,
			'height'     => isset( $metadata['height'] ) ? $metadata['height'] : null,
			'alt_text'   => $alt_text,
			'meta'       => array(
				RR_MEDIA_SOURCE_META_KEY      => $source,
				RR_MEDIA_PLACEHOLDER_META_KEY => $is_placeholder,
			),
		)
	);
	$response->set_status( 201 );
	return $response;
}

/**
 * Handles GET /media/placeholders — lists attachments flagged as AI
 * placeholders (_rrseo_media_placeholder = 1), for the manual-replace
 * checklist page-builder workflows generate per rollout.
 *
 * @param WP_REST_Request $request REST request object.
 * @return WP_REST_Response
 */
function rmb_media_list_placeholders( WP_REST_Request $request ) {
	$attachments = get_posts(
		array(
			'post_type'      => 'attachment',
			'post_status'    => 'inherit',
			'posts_per_page' => -1,
			'meta_key'       => RR_MEDIA_PLACEHOLDER_META_KEY,
			'meta_value'     => '1',
		)
	);

	$items = array();
	foreach ( $attachments as $att ) {
		$items[] = array(
			'id'          => $att->ID,
			'filename'    => basename( get_attached_file( $att->ID ) ),
			'url'         => wp_get_attachment_url( $att->ID ),
			'alt'         => get_post_meta( $att->ID, '_wp_attachment_image_alt', true ),
			'source'      => get_post_meta( $att->ID, RR_MEDIA_SOURCE_META_KEY, true ),
			'post_parent' => $att->post_parent,
		);
	}

	return rest_ensure_response(
		array(
			'count' => count( $items ),
			'items' => $items,
		)
	);
}


// ── Elementor Set-Data Validation ─────────────────────────────────────────────
/**
 * Validates an Elementor `_elementor_data` tree: the top level must be a
 * non-empty list of section/container nodes, each with `elType`, `elements`
 * (array), `id`, and `settings` (array). Also walks the full tree to count
 * widgets and produce a best-effort, non-blocking warning for any
 * widgetType outside the known core (free) list — see
 * RR_ELEMENTOR_CORE_WIDGET_TYPES.
 *
 * @param mixed $elementor_data Decoded elementor_data payload.
 * @return array{errors: string[], warnings: string[], widget_count: int}
 */
function rr_validate_elementor_data( $elementor_data ) {
	if ( ! is_array( $elementor_data ) || ! wp_is_numeric_array( $elementor_data ) ) {
		return array(
			'errors'       => array( 'elementor_data: must be an array of section/container objects' ),
			'warnings'     => array(),
			'widget_count' => 0,
		);
	}

	if ( empty( $elementor_data ) ) {
		return array(
			'errors'       => array( 'elementor_data: must contain at least one element' ),
			'warnings'     => array(),
			'widget_count' => 0,
		);
	}

	$errors = array();

	foreach ( $elementor_data as $index => $node ) {
		if ( ! is_array( $node ) ) {
			$errors[] = "elementor_data[{$index}]: must be a JSON object";
			continue;
		}
		if ( empty( $node['elType'] ) || ! in_array( $node['elType'], RR_ELEMENTOR_ALLOWED_TOP_LEVEL_TYPES, true ) ) {
			$errors[] = "elementor_data[{$index}]: elType must be one of " . implode( ', ', RR_ELEMENTOR_ALLOWED_TOP_LEVEL_TYPES );
			continue;
		}
		if ( ! isset( $node['elements'] ) || ! is_array( $node['elements'] ) ) {
			$errors[] = "elementor_data[{$index}]: missing required 'elements' array";
			continue;
		}
		if ( ! isset( $node['id'] ) || '' === $node['id'] ) {
			$errors[] = "elementor_data[{$index}]: missing required 'id'";
			continue;
		}
		if ( ! isset( $node['settings'] ) || ! is_array( $node['settings'] ) ) {
			$errors[] = "elementor_data[{$index}]: missing required 'settings' object";
		}
	}

	if ( ! empty( $errors ) ) {
		return array(
			'errors'       => $errors,
			'warnings'     => array(),
			'widget_count' => 0,
		);
	}

	$allowed_core_widgets = apply_filters( 'rrseo_elementor_core_widget_types', RR_ELEMENTOR_CORE_WIDGET_TYPES );
	$widget_count         = 0;
	$warnings             = array();
	rr_elementor_walk_tree( $elementor_data, $allowed_core_widgets, $widget_count, $warnings );

	return array(
		'errors'       => array(),
		'warnings'     => array_values( array_unique( $warnings ) ),
		'widget_count' => $widget_count,
	);
}

/**
 * Recursively walks an Elementor element tree, incrementing $widget_count
 * for every `elType: widget` node and appending to $warnings when a
 * widget's `widgetType` isn't in $allowed_core_widgets.
 *
 * @param array    $elements             Array of Elementor element nodes.
 * @param string[] $allowed_core_widgets Known core widgetType values.
 * @param int      $widget_count         Running count, passed by reference.
 * @param string[] $warnings             Running warnings list, by reference.
 */
function rr_elementor_walk_tree( array $elements, array $allowed_core_widgets, &$widget_count, array &$warnings ) {
	foreach ( $elements as $node ) {
		if ( ! is_array( $node ) ) {
			continue;
		}
		if ( isset( $node['elType'] ) && 'widget' === $node['elType'] ) {
			++$widget_count;
			$widget_type = isset( $node['widgetType'] ) ? $node['widgetType'] : '';
			if ( $widget_type && ! in_array( $widget_type, $allowed_core_widgets, true ) ) {
				$warnings[] = "widgetType '{$widget_type}' is not in the known Elementor core list -- may require Elementor Pro or a third-party addon";
			}
		}
		if ( isset( $node['elements'] ) && is_array( $node['elements'] ) ) {
			rr_elementor_walk_tree( $node['elements'], $allowed_core_widgets, $widget_count, $warnings );
		}
	}
}


// ── Elementor Set-Data Handler ────────────────────────────────────────────────
/**
 * Clears Elementor's CSS cache after an _elementor_data write, so the next
 * front-end render doesn't serve stale CSS. Uses the public files_manager
 * API (a global cache clear) rather than Elementor's internal per-post CSS
 * file classes, which are more likely to change shape between versions.
 * No-op if Elementor isn't loaded.
 *
 * @param int $post_id Post ID (unused by the global clear; kept for a
 *                      future page-specific clear if Elementor exposes one).
 * @return bool Whether the cache clear ran.
 */
function rr_elementor_clear_css_cache( $post_id ) {
	unset( $post_id );
	if ( ! class_exists( '\Elementor\Plugin' ) ) {
		return false;
	}
	$plugin = \Elementor\Plugin::$instance;
	if ( isset( $plugin->files_manager ) && method_exists( $plugin->files_manager, 'clear_cache' ) ) {
		$plugin->files_manager->clear_cache();
		return true;
	}
	return false;
}

/**
 * Handles POST /elementor/set-data — validates and writes an Elementor
 * page's _elementor_data / _elementor_edit_mode / _elementor_template_type
 * meta, then clears Elementor's CSS cache.
 *
 * @param WP_REST_Request $request REST request object.
 * @return WP_REST_Response|WP_Error
 */
function rmb_elementor_set_data( WP_REST_Request $request ) {
	$post_id          = intval( $request->get_param( 'post_id' ) );
	$elementor_data   = $request->get_param( 'elementor_data' );
	$edit_mode        = (string) $request->get_param( 'edit_mode' );
	$template_type    = (string) $request->get_param( 'template_type' );
	$css_print_method = $request->get_param( 'css_print_method' );
	$dry_run          = (bool) $request->get_param( 'dry_run' );

	if ( ! get_post( $post_id ) ) {
		return new WP_Error( 'invalid_post', 'Post not found', array( 'status' => 404 ) );
	}

	$validation = rr_validate_elementor_data( $elementor_data );
	if ( ! empty( $validation['errors'] ) ) {
		return new WP_Error(
			'validation_failed',
			'Elementor data validation failed',
			array(
				'status'   => 422,
				'errors'   => $validation['errors'],
				'warnings' => $validation['warnings'],
			)
		);
	}

	$encoded = wp_json_encode( $elementor_data );
	$bytes   = strlen( $encoded );

	if ( $dry_run ) {
		return rest_ensure_response(
			array(
				'post_id'              => $post_id,
				'dry_run'              => true,
				'valid'                => true,
				'elementor_data_bytes' => $bytes,
				'widget_count'         => $validation['widget_count'],
				'edit_mode'            => $edit_mode,
				'template_type'        => $template_type,
				'warnings'             => $validation['warnings'],
			)
		);
	}

	update_post_meta( $post_id, RR_ELEMENTOR_DATA_META_KEY, wp_slash( $encoded ) );
	update_post_meta( $post_id, RR_ELEMENTOR_EDIT_MODE_META_KEY, sanitize_key( $edit_mode ) );
	update_post_meta( $post_id, RR_ELEMENTOR_TEMPLATE_TYPE_META_KEY, sanitize_key( $template_type ) );

	if ( $css_print_method ) {
		$page_settings = get_post_meta( $post_id, RR_ELEMENTOR_PAGE_SETTINGS_META_KEY, true );
		$page_settings = is_array( $page_settings ) ? $page_settings : array();

		$page_settings['css_print_method'] = sanitize_text_field( $css_print_method );
		update_post_meta( $post_id, RR_ELEMENTOR_PAGE_SETTINGS_META_KEY, $page_settings );
	}

	$css_regenerated = rr_elementor_clear_css_cache( $post_id );

	rr_audit_log(
		$post_id,
		'/elementor/set-data',
		array(
			'elementor_data' => array(
				'bytes'         => $bytes,
				'widget_count'  => $validation['widget_count'],
				'edit_mode'     => $edit_mode,
				'template_type' => $template_type,
			),
		),
		rr_request_id( $request ),
		'written'
	);

	return rest_ensure_response(
		array(
			'post_id'              => $post_id,
			'elementor_data_bytes' => $bytes,
			'widget_count'         => $validation['widget_count'],
			'edit_mode'            => $edit_mode,
			'template_type'        => $template_type,
			'css_regenerated'      => $css_regenerated,
			'warnings'             => $validation['warnings'],
		)
	);
}


// ── robots.txt Handler ────────────────────────────────────────────────────────

/**
 * WordPress robots_txt filter callback.
 *
 * Returns the stored custom content when set; otherwise passes through
 * the default WordPress robots.txt content unchanged.
 * Has no effect when a physical robots.txt file exists at the webroot —
 * in that case the web server serves the file directly.
 *
 * @param string $output  WordPress-generated robots.txt content.
 * @param int    $is_public Site visibility setting (1 = public, 0 = discourage).
 * @return string
 */
function rr_robots_txt_output( string $output, int $is_public ): string {
	// phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.FoundAfterLastUsed
	$custom = get_option( 'rrseo_robots_txt', '' );
	if ( '' !== $custom ) {
		return $custom;
	}

	// Auto-sync: strip Sitemap: lines pointing to WP core's /wp-sitemap.xml and
	// append the RankRocket sitemap_index.xml directive so robots.txt agrees with
	// the active sitemap. Gated by rrseo_robots_txt_auto_sync (default on).
	$auto_sync = (bool) get_option( 'rrseo_robots_txt_auto_sync', true );
	if ( ! $auto_sync ) {
		return $output;
	}

	$site_url    = rtrim( get_bloginfo( 'url' ), '/' );
	$rr_sitemap  = $site_url . '/sitemap_index.xml';
	$wp_sitemap  = $site_url . '/wp-sitemap.xml';
	$lines       = explode( "\n", str_replace( "\r\n", "\n", $output ) );
	$kept        = array();
	$has_rr_line = false;

	foreach ( $lines as $line ) {
		$trim = trim( $line );
		if ( 0 === stripos( $trim, 'Sitemap:' ) ) {
			$url_part = trim( substr( $trim, 8 ) );
			if ( strtolower( $url_part ) === strtolower( $wp_sitemap ) ) {
				continue; // Drop core's directive.
			}
			if ( strtolower( $url_part ) === strtolower( $rr_sitemap ) ) {
				$has_rr_line = true;
			}
		}
		$kept[] = $line;
	}

	// Trim trailing blanks before appending.
	while ( ! empty( $kept ) && '' === trim( end( $kept ) ) ) {
		array_pop( $kept );
	}

	if ( ! $has_rr_line ) {
		$kept[] = '';
		$kept[] = 'Sitemap: ' . $rr_sitemap;
	}

	return implode( "\n", $kept ) . "\n";
}

/**
 * Merges per-post robots directives into WordPress core's wp_robots array.
 *
 * Core's wp_robots() callback emits a single <meta name="robots"> tag built from
 * the associative array returned by the wp_robots filter (e.g. max-image-preview
 * is added by wp_robots_max_image_preview_large()). This callback folds the
 * post-level rr_seo_robots value into that array on singular requests so only
 * one robots tag renders.
 *
 * Gated by rrseo_consolidate_wp_robots (default true) so the previous two-tag
 * behaviour remains available for users who opt out.
 *
 * @param array $directives Existing directives keyed by name.
 * @return array
 */
function rr_merge_wp_robots( array $directives ): array {
	if ( ! (bool) get_option( 'rrseo_consolidate_wp_robots', true ) ) {
		return $directives;
	}
	if ( class_exists( 'RankMath' ) ) {
		return $directives;
	}

	$robots = '';
	if ( is_singular() ) {
		$post_id = get_queried_object_id();
		if ( $post_id ) {
			$robots = rr_get_seo_meta( $post_id, 'robots' );
		}
	} elseif ( rr_is_any_tax_archive() ) {
		$term_id = get_queried_object_id();
		if ( $term_id ) {
			$robots = rr_get_term_seo_meta( $term_id, 'robots' );
		}
	}

	if ( ! $robots ) {
		// No stored directive: emit explicit index, follow as a safe default so
		// the <meta name="robots"> tag is never omitted on indexable pages.
		if ( ! isset( $directives['noindex'] ) ) {
			$directives['index']  = true;
			$directives['follow'] = true;
		}
		return $directives;
	}

	$values = is_array( $robots ) ? $robots : array_map( 'trim', explode( ',', (string) $robots ) );
	foreach ( $values as $value ) {
		if ( '' === $value ) {
			continue;
		}
		// key=value directives (e.g. max-image-preview:large) preserve their value;
		// boolean directives (index/noindex/follow/nofollow/...) flip a flag.
		if ( false !== strpos( $value, ':' ) ) {
			list($k, $v)      = array_map( 'trim', explode( ':', $value, 2 ) );
			$directives[ $k ] = $v;
		} else {
			$directives[ $value ] = true;
		}
	}

	// noindex wins over index when both are present.
	if ( ! empty( $directives['noindex'] ) ) {
		unset( $directives['index'] );
	}
	if ( ! empty( $directives['nofollow'] ) ) {
		unset( $directives['follow'] );
	}

	return $directives;
}

/**
 * Handles GET /robots-txt — returns current robots.txt content and status.
 *
 * @param WP_REST_Request $request REST request object.
 * @return WP_REST_Response
 */
function rmb_robots_get( WP_REST_Request $request ): WP_REST_Response {
	// phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.Found
	$custom        = get_option( 'rrseo_robots_txt', '' );
	$physical_path = ABSPATH . 'robots.txt';
	clearstatcache( true, $physical_path );
	$has_file = file_exists( $physical_path );
	// Plugin manages the physical file when custom content is stored and the file exists.
	$plugin_managed = '' !== $custom && $has_file;

	$warning = null;
	if ( $has_file && ! $plugin_managed ) {
		$warning = 'A physical robots.txt exists at the webroot but no custom content is stored. '
			. 'The web server serves it directly. Save content via POST /robots-txt to take ownership.';
	}

	return rest_ensure_response(
		array(
			'content'               => $custom,
			'source'                => '' !== $custom ? 'custom' : 'wordpress_default',
			'physical_file_exists'  => $has_file,
			'physical_file_managed' => $plugin_managed,
			'warning'               => $warning,
		)
	);
}

/**
 * Handles POST /robots-txt — writes a custom robots.txt body.
 *
 * When ensure_sitemap_directive is true, normalises Sitemap: directives before
 * storing. preferred_sitemap_only (default true) replaces all existing Sitemap:
 * lines with the RankRocket preferred directive; when false, existing Sitemap:
 * lines are preserved and the preferred directive is appended if absent.
 *
 * @param WP_REST_Request $request REST request object.
 * @return WP_REST_Response
 */
function rmb_robots_set( WP_REST_Request $request ): WP_REST_Response {
	$content          = sanitize_textarea_field( $request->get_param( 'content' ) );
	$ensure_directive = (bool) $request->get_param( 'ensure_sitemap_directive' );
	$preferred_only   = null !== $request->get_param( 'preferred_sitemap_only' )
		? (bool) $request->get_param( 'preferred_sitemap_only' )
		: true;
	$physical_path    = ABSPATH . 'robots.txt';

	if ( $ensure_directive && '' !== $content ) {
		$preferred_url = rtrim( get_bloginfo( 'url' ), '/' ) . '/sitemap_index.xml';
		$content       = rmb_robots_inject_sitemap_directive( $content, $preferred_url, $preferred_only );
	}

	update_option( 'rrseo_robots_txt', $content );
	// Bust WP object cache so subsequent GET requests read the fresh DB value, not a stale cache entry.
	wp_cache_delete( 'rrseo_robots_txt', 'options' );
	wp_cache_delete( 'alloptions', 'options' );

	// Write or remove the physical robots.txt so changes persist if the plugin is ever deactivated.
	// The web server serves a physical file directly — no WordPress involved.
	$physical_managed = false;
	$physical_error   = null;

	if ( '' !== $content ) {
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
		$bytes = file_put_contents( $physical_path, $content );
		if ( false === $bytes ) {
			$physical_error = 'Could not write robots.txt to the webroot — check directory permissions. Content saved to database only.';
		} else {
			$physical_managed = true;
		}
	} elseif ( file_exists( $physical_path ) ) {
		// Content cleared — remove physical file so WP virtual robots.txt takes over.
		wp_delete_file( $physical_path );
	}

	clearstatcache( true, $physical_path );
	$has_file          = file_exists( $physical_path );
	$missing_directive = '' !== $content && false === stripos( $content, 'Sitemap:' );
	$response_warnings = array();

	if ( $missing_directive ) {
		$response_warnings[] = array(
			'code'    => 'missing_sitemap_directive',
			'message' => 'robots.txt content has no Sitemap: directive. Pass ensure_sitemap_directive:true to auto-add it.',
		);
	}
	if ( null !== $physical_error ) {
		$response_warnings[] = array(
			'code'    => 'physical_file_write_failed',
			'message' => $physical_error,
		);
	}

	return rest_ensure_response(
		array(
			'success'               => true,
			'content'               => $content,
			'source'                => '' !== $content ? 'custom' : 'wordpress_default',
			'physical_file_exists'  => $has_file,
			'physical_file_managed' => $physical_managed,
			'warnings'              => $response_warnings,
		)
	);
}

/**
 * Normalises Sitemap: directives in a robots.txt body.
 *
 * Implements the v4 §15.7 five-step procedure:
 * 1. Parse all existing Sitemap: lines case-insensitively.
 * 2. Preserve non-Sitemap: lines exactly.
 * 3. If preferred_only, remove all existing Sitemap: lines and append preferred once.
 * 4. If not preferred_only, keep existing lines and append preferred if absent.
 * 5. Deduplicate identical Sitemap: lines.
 *
 * @param string $content       Current robots.txt body.
 * @param string $preferred_url Full URL of the preferred sitemap (e.g. sitemap_index.xml).
 * @param bool   $preferred_only Replace all existing Sitemap: lines when true.
 * @return string Normalised robots.txt body.
 */
function rmb_robots_inject_sitemap_directive( string $content, string $preferred_url, bool $preferred_only ): string {
	$preferred_line = 'Sitemap: ' . $preferred_url;
	$lines          = explode( "\n", str_replace( "\r\n", "\n", $content ) );
	$non_sitemap    = array();
	$existing_maps  = array();

	foreach ( $lines as $line ) {
		if ( 0 === stripos( trim( $line ), 'Sitemap:' ) ) {
			$existing_maps[] = trim( $line );
		} else {
			$non_sitemap[] = $line;
		}
	}

	// Remove trailing blank lines from non-sitemap block to keep output tidy.
	while ( ! empty( $non_sitemap ) && '' === trim( end( $non_sitemap ) ) ) {
		array_pop( $non_sitemap );
	}

	if ( $preferred_only ) {
		$sitemap_lines = array( $preferred_line );
	} else {
		$already_present = false;
		foreach ( $existing_maps as $m ) {
			if ( strtolower( $m ) === strtolower( $preferred_line ) ) {
				$already_present = true;
			}
		}
		$sitemap_lines = $existing_maps;
		if ( ! $already_present ) {
			$sitemap_lines[] = $preferred_line;
		}
		// Deduplicate (case-insensitive).
		$seen    = array();
		$deduped = array();
		foreach ( $sitemap_lines as $sl ) {
			$key = strtolower( $sl );
			if ( ! in_array( $key, $seen, true ) ) {
				$seen[]    = $key;
				$deduped[] = $sl;
			}
		}
		$sitemap_lines = $deduped;
	}

	$result_lines = array_merge( $non_sitemap, array( '' ), $sitemap_lines );
	return implode( "\n", $result_lines );
}


// ── llms.txt Handlers ─────────────────────────────────────────────────────────
/**
 * Handles GET /llms — returns the current llms.txt configuration.
 *
 * @param WP_REST_Request $request REST request object.
 * @return WP_REST_Response
 */
function rmb_llms_get_config( WP_REST_Request $request ) {
	// phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.Found
	// Read the new key first; fall back to the legacy key for migration compat.
	$config = get_option( RR_LLMS_CONFIG_KEY, get_option( 'rmb_llms_config', array() ) );
	return rest_ensure_response(
		array(
			'url'    => rtrim( get_bloginfo( 'url' ), '/' ) . '/llms.txt',
			'config' => $config,
		)
	);
}

/**
 * Handles POST /llms — updates the llms.txt configuration.
 *
 * @param WP_REST_Request $request REST request object.
 * @return WP_REST_Response
 */
function rmb_llms_set_config( WP_REST_Request $request ) {
	// Read from the new key first; migrate legacy config if new key is absent.
	$config = get_option( RR_LLMS_CONFIG_KEY, get_option( 'rmb_llms_config', array() ) );

	// Simple scalar / text fields.
	$scalar_fields = array( 'intro', 'max_description_chars', 'schema_source_post_id' );
	foreach ( $scalar_fields as $field ) {
		$val = $request->get_param( $field );
		if ( null !== $val ) {
			$config[ $field ] = 'intro' === $field ? sanitize_textarea_field( $val ) : (int) $val;
		}
	}

	// Boolean flags.
	$bool_fields = array( 'include_sitemaps', 'include_lastmod', 'exclude_noindex', 'exclude_utility_pages', 'group_by_intent' );
	foreach ( $bool_fields as $field ) {
		$val = $request->get_param( $field );
		if ( null !== $val ) {
			$config[ $field ] = (bool) $val;
		}
	}

	// sections (object form — URL classifier config).
	$sections = $request->get_param( 'sections' );
	if ( null !== $sections && is_array( $sections ) && ! isset( $sections[0] ) ) {
		$config['sections'] = $sections;
	}

	// custom_sections (array of {heading, items} text blocks — legacy).
	$custom_sections = $request->get_param( 'custom_sections' );
	if ( null !== $custom_sections && is_array( $custom_sections ) ) {
		$config['custom_sections'] = $custom_sections;
	}

	// exclude_patterns (array of URL path strings).
	$patterns = $request->get_param( 'exclude_patterns' );
	if ( null !== $patterns && is_array( $patterns ) ) {
		$config['exclude_patterns'] = array_map( 'sanitize_text_field', $patterns );
	}

	// business_facts (object) — merged onto the stored value (issue #11) and
	// validated as a whole (issue #9) before it is accepted.
	$facts = $request->get_param( 'business_facts' );
	if ( null !== $facts ) {
		if ( ! is_array( $facts ) ) {
			return new WP_Error(
				'invalid_business_facts',
				'business_facts must be an object.',
				array( 'status' => 422 )
			);
		}
		$stored_facts = isset( $config['business_facts'] ) && is_array( $config['business_facts'] ) ? $config['business_facts'] : array();
		$merged_facts = rr_merge_llms_business_facts( $stored_facts, $facts );
		$validated    = rr_validate_llms_business_facts( $merged_facts );
		if ( is_wp_error( $validated ) ) {
			return $validated;
		}
		$config['business_facts'] = $merged_facts;
	}

	// Invalidate the canonical counts transient after config change.
	rr_invalidate_canonical_cache();

	// Write to the new canonical key; the legacy key is no longer updated.
	update_option( RR_LLMS_CONFIG_KEY, $config );

	return rest_ensure_response(
		array(
			'success' => true,
			'url'     => rtrim( get_bloginfo( 'url' ), '/' ) . '/llms.txt',
			'config'  => $config,
		)
	);
}


/**
 * Handles POST /llms-txt/regenerate — invalidates cached data and re-renders llms.txt.
 *
 * The llms.txt file is served dynamically, so no file rebuild is needed. This endpoint
 * invalidates the canonical URL set transient, forces a fresh render, and
 * returns metadata so callers can confirm the content is up to date.
 *
 * @param WP_REST_Request $request REST request object.
 * @return WP_REST_Response
 */
function rmb_llms_regenerate( WP_REST_Request $request ) {
	// phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.Found
	rr_invalidate_canonical_cache();
	$config  = get_option( RR_LLMS_CONFIG_KEY, get_option( 'rmb_llms_config', array() ) );
	$result  = rr_render_llms_txt( $config );
	$content = $result['content'];
	return rest_ensure_response(
		array(
			'success'     => true,
			'url'         => rtrim( get_bloginfo( 'url' ), '/' ) . '/llms.txt',
			'line_count'  => substr_count( $content, "\n" ),
			'byte_size'   => strlen( $content ),
			'regenerated' => current_time( 'mysql' ),
		)
	);
}


// ── Elementor Cache Handler ───────────────────────────────────────────────────
/**
 * Handles POST /elementor/repair-cache — clears stale Elementor render cache.
 *
 * Deletes _elementor_element_cache and _elementor_css for the specified post(s)
 * so the next page load rebuilds fresh output. Accepts post_id (int) for a
 * single post, post_ids (array) for a batch, or both.
 *
 * @param WP_REST_Request $request REST request object.
 * @return WP_REST_Response|WP_Error
 */
function rmb_elementor_repair_cache( WP_REST_Request $request ) {
	$single   = $request->get_param( 'post_id' );
	$batch    = $request->get_param( 'post_ids' );
	$post_ids = array();

	if ( null !== $single ) {
		$post_ids[] = absint( $single );
	}
	if ( null !== $batch && is_array( $batch ) ) {
		foreach ( $batch as $pid ) {
			$post_ids[] = absint( $pid );
		}
	}
	$post_ids = array_unique( array_filter( $post_ids ) );

	if ( empty( $post_ids ) ) {
		return new WP_Error(
			'missing_post_id',
			'Provide post_id (int) or post_ids (array) — at least one is required.',
			array( 'status' => 400 )
		);
	}

	$repaired = array();
	foreach ( $post_ids as $post_id ) {
		if ( ! get_post( $post_id ) ) {
			$repaired[] = array(
				'post_id' => $post_id,
				'status'  => 'not_found',
			);
			continue;
		}
		$deleted = array();
		foreach ( array( '_elementor_element_cache', '_elementor_css' ) as $meta_key ) {
			if ( '' !== get_post_meta( $post_id, $meta_key, true ) ) {
				delete_post_meta( $post_id, $meta_key );
				$deleted[] = $meta_key;
			}
		}
		wp_cache_delete( $post_id, 'post_meta' );
		clean_post_cache( $post_id );
		$repaired[] = array(
			'post_id'      => $post_id,
			'status'       => 'repaired',
			'deleted_keys' => $deleted,
		);
	}

	return rest_ensure_response(
		array(
			'success'  => true,
			'repaired' => $repaired,
		)
	);
}


// ── Performance Handlers ──────────────────────────────────────────────────────
/**
 * Handles GET /perf/dequeue-rules — returns current dequeue rules and allowed conditionals.
 *
 * @param WP_REST_Request $request REST request object.
 * @return WP_REST_Response
 */
function rmb_perf_dequeue_get( WP_REST_Request $request ) {
	// phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.Found
	return rest_ensure_response(
		array(
			'rules'                => get_option( RR_PERF_DEQUEUE_KEY, array() ),
			'allowed_conditionals' => RR_PERF_ALLOWED_CONDITIONALS,
		)
	);
}

/**
 * Handles POST /perf/dequeue-rules — replaces the stored dequeue rule set.
 *
 * Each rule: { handles: string[], type: 'auto'|'script'|'style', when_not: string[] }.
 * when_not values must be in RR_PERF_ALLOWED_CONDITIONALS.
 * Passing an empty rules array clears all rules.
 *
 * @param WP_REST_Request $request REST request object.
 * @return WP_REST_Response|WP_Error
 */
function rmb_perf_dequeue_update( WP_REST_Request $request ) {
	$raw_rules = $request->get_param( 'rules' );
	if ( ! is_array( $raw_rules ) ) {
		return new WP_Error( 'invalid_rules', 'rules must be an array.', array( 'status' => 400 ) );
	}

	$clean   = array();
	$allowed = RR_PERF_ALLOWED_CONDITIONALS;

	foreach ( $raw_rules as $idx => $rule ) {
		if ( ! is_array( $rule ) || empty( $rule['handles'] ) || ! is_array( $rule['handles'] ) ) {
			return new WP_Error(
				'invalid_rule',
				"Rule at index {$idx} must have a non-empty handles array.",
				array( 'status' => 422 )
			);
		}

		$type = sanitize_text_field( $rule['type'] ?? 'auto' );
		if ( ! in_array( $type, array( 'auto', 'script', 'style' ), true ) ) {
			return new WP_Error(
				'invalid_type',
				"Rule at index {$idx}: type must be auto, script, or style.",
				array( 'status' => 422 )
			);
		}

		$when_not = array();
		if ( ! empty( $rule['when_not'] ) && is_array( $rule['when_not'] ) ) {
			foreach ( $rule['when_not'] as $cond ) {
				$cond = sanitize_key( (string) $cond );
				if ( ! in_array( $cond, $allowed, true ) ) {
					return new WP_Error(
						'invalid_conditional',
						"Unknown conditional '{$cond}'. See allowed_conditionals in GET /perf/dequeue-rules.",
						array(
							'status'               => 422,
							'allowed_conditionals' => $allowed,
						)
					);
				}
				$when_not[] = $cond;
			}
		}

		$clean[] = array(
			'handles'  => array_values( array_map( 'sanitize_text_field', $rule['handles'] ) ),
			'type'     => $type,
			'when_not' => $when_not,
		);
	}

	update_option( RR_PERF_DEQUEUE_KEY, $clean );
	rrseo_bust_option_cache( RR_PERF_DEQUEUE_KEY );
	rrseo_purge_rest_cache( array( 'status' ) );

	return rest_ensure_response(
		array(
			'success' => true,
			'rules'   => $clean,
		)
	);
}

/**
 * Handles GET /perf/defer-handles — returns the list of script handles marked for defer.
 *
 * @param WP_REST_Request $request REST request object.
 * @return WP_REST_Response
 */
function rmb_perf_defer_get( WP_REST_Request $request ) {
	// phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.Found
	return rest_ensure_response(
		array(
			'handles' => get_option( RR_PERF_DEFER_KEY, array() ),
		)
	);
}

/**
 * Handles POST /perf/defer-handles — replaces the stored defer handle list.
 *
 * Passing an empty handles array clears all deferred handles.
 *
 * @param WP_REST_Request $request REST request object.
 * @return WP_REST_Response|WP_Error
 */
function rmb_perf_defer_update( WP_REST_Request $request ) {
	$handles = $request->get_param( 'handles' );
	if ( ! is_array( $handles ) ) {
		return new WP_Error( 'invalid_handles', 'handles must be an array.', array( 'status' => 400 ) );
	}
	$clean = array_values( array_filter( array_map( 'sanitize_text_field', $handles ) ) );
	update_option( RR_PERF_DEFER_KEY, $clean );
	rrseo_bust_option_cache( RR_PERF_DEFER_KEY );
	rrseo_purge_rest_cache( array( 'status' ) );
	return rest_ensure_response(
		array(
			'success' => true,
			'handles' => $clean,
		)
	);
}


// ── Sitemap Preview Handler ───────────────────────────────────────────────────
/**
 * Handles GET /sitemap/preview — Canonical URL Set preview with inclusion/exclusion audit.
 *
 * Now acts as the authoritative Canonical URL Set preview endpoint: uses the same
 * rr_get_canonical_url_set() as all sitemap and llms.txt generators, guaranteeing
 * the preview reflects exactly what will be served.
 *
 * Also fixes a prior bug where lastmod used post_modified (local time) instead of
 * post_modified_gmt (UTC), and reported the legacy sitemap URL instead of the index.
 *
 * @param WP_REST_Request $request REST request object.
 * @return WP_REST_Response
 */
function rmb_sitemap_preview( WP_REST_Request $request ) {
	// phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.Found
	$front_page = (int) get_option( 'page_on_front' );
	$site_url   = rtrim( get_bloginfo( 'url' ), '/' );

	$canonical = rr_get_canonical_url_set(
		array( 'post_types' => array( 'post', 'page' ) )
	);

	$entries = array();
	foreach ( $canonical['urls'] as $url_entry ) {
		if ( 'page' === $url_entry['post_type'] ) {
			$priority = ( $url_entry['post_id'] === $front_page ) ? '1.0' : '0.8';
		} else {
			$priority = '0.6';
		}
		$entries[] = array(
			'id'               => $url_entry['post_id'],
			'post_id'          => $url_entry['post_id'],
			'type'             => $url_entry['post_type'],
			'loc'              => $url_entry['url'],
			'lastmod'          => $url_entry['lastmod'],
			'priority'         => $priority,
			'noindex'          => false,
			'included'         => true,
			'exclusion_reason' => null,
			'warnings'         => $url_entry['warnings'],
		);
	}

	$excluded_entries = array();
	foreach ( $canonical['excluded'] as $excl ) {
		$excluded_entries[] = array(
			'id'               => $excl['post_id'],
			'post_id'          => $excl['post_id'],
			'type'             => $excl['post_type'],
			'loc'              => $excl['url'],
			'included'         => false,
			'exclusion_reason' => $excl['reason'],
		);
	}

	return rest_ensure_response(
		array(
			'sitemap_url'    => $site_url . '/sitemap_index.xml',
			'total'          => count( $entries ) + count( $excluded_entries ),
			'included_count' => count( $entries ),
			'excluded_count' => count( $excluded_entries ),
			'entries'        => array_values( $entries ),
			'excluded_urls'  => array_values( $excluded_entries ),
			'warnings'       => array_values( $canonical['warnings'] ),
		)
	);
}


// ── Snippet Handlers ──────────────────────────────────────────────────────────
/**
 * Handles GET /snippets — returns all managed snippets.
 *
 * @param WP_REST_Request $request REST request object.
 * @return WP_REST_Response
 */
function rmb_snippets_list( WP_REST_Request $request ) {
	// phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.Found
	$snippets = get_option( RMB_SNIPPETS_KEY, array() );
	return rest_ensure_response(
		array(
			'count'    => count( $snippets ),
			'snippets' => array_values( $snippets ),
		)
	);
}

/**
 * Handles GET /snippets/{id} — returns a single managed snippet by slug.
 *
 * @param WP_REST_Request $request REST request object.
 * @return WP_REST_Response|WP_Error
 */
function rmb_snippets_get_single( WP_REST_Request $request ) {
	$snippets = get_option( RMB_SNIPPETS_KEY, array() );
	$id       = $request->get_param( 'id' );
	if ( ! isset( $snippets[ $id ] ) ) {
		return new WP_Error( 'not_found', "Snippet '{$id}' not found.", array( 'status' => 404 ) );
	}
	return rest_ensure_response( $snippets[ $id ] );
}

/**
 * Handles POST /snippets — creates a new managed snippet.
 *
 * @param WP_REST_Request $request REST request object.
 * @return WP_REST_Response
 */
function rmb_snippets_create( WP_REST_Request $request ) {
	$snippets = get_option( RMB_SNIPPETS_KEY, array() );

	$title = sanitize_text_field( $request->get_param( 'title' ) );
	$id    = sanitize_title( $title );

	// Accept 'code' as an alias for 'content' so both field names work.
	// 'code_b64' wins over both when present (WAF-safe transport, issue #8).
	$body_b64 = $request->get_param( 'code_b64' );
	if ( null !== $body_b64 ) {
		$body = rr_decode_snippet_b64( $body_b64 );
		if ( null === $body ) {
			return new WP_Error(
				'invalid_base64',
				'code_b64 must be valid base64 that decodes to UTF-8 content.',
				array( 'status' => 422 )
			);
		}
	} else {
		$body = $request->get_param( 'content' );
		if ( null === $body ) {
			$body = $request->get_param( 'code' );
		}
	}
	if ( null === $body || '' === $body ) {
		return new WP_Error(
			'missing_content',
			'A snippet body is required. Send it as "content", "code", or base64-encoded "code_b64".',
			array( 'status' => 400 )
		);
	}

	$base_id = $id;
	$attempt = 1;
	while ( isset( $snippets[ $id ] ) ) {
		$id = $base_id . '_' . $attempt;
		++$attempt;
	}

	$display_on_val = sanitize_text_field( $request->get_param( 'display_on' ) );
	if ( '' !== $display_on_val && ! rr_validate_display_on( $display_on_val ) ) {
		return new WP_Error(
			'invalid_display_on',
			"Invalid display_on value: '{$display_on_val}'.",
			array(
				'status'            => 422,
				'hint'              => 'url: patterns are not yet supported. Use one of the accepted_patterns values.',
				'accepted_patterns' => array(
					'entire_website',
					'front_page',
					'singular',
					'all_pages',
					'all_posts',
					'page_id:<int>',
					'post_id:<int>',
					'post_type:<slug>',
					'term_id:<int>',
					'term:<taxonomy>:<slug>',
					'tax:<taxonomy>',
				),
			)
		);
	}

	$snippet = array(
		'id'              => $id,
		'title'           => $title,
		'content'         => $body,
		'location'        => sanitize_text_field( $request->get_param( 'location' ) ),
		'display_on'      => $display_on_val,
		'display_on_user' => sanitize_text_field( (string) ( $request->get_param( 'display_on_user' ) ?? 'all' ) ),
		'status'          => sanitize_text_field( $request->get_param( 'status' ) ),
		'created_at'      => current_time( 'mysql' ),
		'updated_at'      => current_time( 'mysql' ),
	);

	$priority_raw = $request->get_param( 'priority' );
	if ( null !== $priority_raw ) {
		$priority_val = rr_validate_snippet_priority( $priority_raw );
		if ( null === $priority_val ) {
			return new WP_Error(
				'invalid_priority',
				'priority must be an integer between 0 and ' . RR_SNIPPET_PRIORITY_MAX,
				array( 'status' => 422 )
			);
		}
		$snippet['priority'] = $priority_val;
	}

	$snippets[ $id ] = $snippet;
	update_option( RMB_SNIPPETS_KEY, $snippets );
	rrseo_bust_option_cache( RMB_SNIPPETS_KEY );
	rrseo_purge_rest_cache( array( 'status', 'snippets' ) );

	return rest_ensure_response(
		array(
			'success' => true,
			'snippet' => $snippet,
		)
	);
}

/**
 * Handles POST /snippets/{id} — updates an existing snippet.
 *
 * @param WP_REST_Request $request REST request object.
 * @return WP_REST_Response|WP_Error
 */
function rmb_snippets_update( WP_REST_Request $request ) {
	$snippets = get_option( RMB_SNIPPETS_KEY, array() );
	$id       = $request->get_param( 'id' );

	if ( ! isset( $snippets[ $id ] ) ) {
		return new WP_Error( 'not_found', "Snippet '{$id}' not found", array( 'status' => 404 ) );
	}

	foreach ( array( 'title', 'location', 'status' ) as $field ) {
		$val = $request->get_param( $field );
		if ( null !== $val ) {
			$snippets[ $id ][ $field ] = sanitize_text_field( $val );
		}
	}

	$display_on_val = $request->get_param( 'display_on' );
	if ( null !== $display_on_val ) {
		$display_on_val = sanitize_text_field( $display_on_val );
		if ( '' !== $display_on_val && ! rr_validate_display_on( $display_on_val ) ) {
			return new WP_Error(
				'invalid_display_on',
				"Invalid display_on value: '{$display_on_val}'.",
				array(
					'status'            => 422,
					'hint'              => 'term:, tax:, and url: patterns are gated. Use one of the accepted_patterns values.',
					'accepted_patterns' => array(
						'entire_website',
						'front_page',
						'singular',
						'all_pages',
						'all_posts',
						'page_id:<int>',
						'post_type:<slug>',
						'term_id:<int>',
					),
				)
			);
		}
		$snippets[ $id ]['display_on'] = $display_on_val;
	}

	$user_filter = $request->get_param( 'display_on_user' );
	if ( null !== $user_filter ) {
		$user_filter = sanitize_text_field( $user_filter );
		if ( ! in_array( $user_filter, array( 'all', 'anonymous', 'logged_in' ), true ) ) {
			return new WP_Error(
				'invalid_display_on_user',
				"display_on_user must be 'all', 'anonymous', or 'logged_in'.",
				array( 'status' => 422 )
			);
		}
		$snippets[ $id ]['display_on_user'] = $user_filter;
	}

	$priority_raw = $request->get_param( 'priority' );
	if ( null !== $priority_raw ) {
		$priority_val = rr_validate_snippet_priority( $priority_raw );
		if ( null === $priority_val ) {
			return new WP_Error(
				'invalid_priority',
				'priority must be an integer between 0 and ' . RR_SNIPPET_PRIORITY_MAX,
				array( 'status' => 422 )
			);
		}
		$snippets[ $id ]['priority'] = $priority_val;
	}

	// Accept 'code' as an alias for 'content'.
	// 'code_b64' wins over both when present (WAF-safe transport, issue #8).
	$content_b64 = $request->get_param( 'code_b64' );
	if ( null !== $content_b64 ) {
		$content = rr_decode_snippet_b64( $content_b64 );
		if ( null === $content ) {
			return new WP_Error(
				'invalid_base64',
				'code_b64 must be valid base64 that decodes to UTF-8 content.',
				array( 'status' => 422 )
			);
		}
	} else {
		$content = $request->get_param( 'content' );
		if ( null === $content ) {
			$content = $request->get_param( 'code' );
		}
	}
	if ( null !== $content ) {
		$snippets[ $id ]['content'] = $content;
	}

	$snippets[ $id ]['updated_at'] = current_time( 'mysql' );

	update_option( RMB_SNIPPETS_KEY, $snippets );
	rrseo_bust_option_cache( RMB_SNIPPETS_KEY );
	rrseo_purge_rest_cache( array( 'status', 'snippets' ) );
	return rest_ensure_response(
		array(
			'success' => true,
			'snippet' => $snippets[ $id ],
		)
	);
}

/**
 * Handles POST /snippets/bulk — atomically creates multiple snippets in one request.
 *
 * Validates all snippets before writing; returns 422 with per-item errors if any
 * fail. No snippets are saved unless every item passes validation. Honors
 * dry_run:true — validates and returns the would-be created snippets without
 * persisting (issue #25).
 *
 * @param WP_REST_Request $request REST request object.
 * @return WP_REST_Response|WP_Error
 */
function rmb_snippets_bulk_create( WP_REST_Request $request ) {
	$incoming = $request->get_param( 'snippets' );
	$dry_run  = (bool) $request->get_param( 'dry_run' );
	if ( ! is_array( $incoming ) || empty( $incoming ) ) {
		return new WP_Error( 'missing_snippets', 'snippets must be a non-empty array.', array( 'status' => 400 ) );
	}

	$batch_max = rrseo_batch_max();
	if ( count( $incoming ) > $batch_max ) {
		return new WP_Error(
			'batch_too_large',
			"Maximum {$batch_max} snippets per request.",
			array(
				'status' => 422,
				'limit'  => $batch_max,
			)
		);
	}

	$existing = get_option( RMB_SNIPPETS_KEY, array() );
	$prepared = array();
	$errors   = array();
	$ts       = current_time( 'mysql' );

	foreach ( $incoming as $idx => $item ) {
		if ( ! is_array( $item ) ) {
			$errors[] = array(
				'index' => $idx,
				'error' => 'each snippet must be an object',
			);
			continue;
		}

		$title = sanitize_text_field( $item['title'] ?? '' );
		if ( '' === $title ) {
			$errors[] = array(
				'index' => $idx,
				'error' => 'title is required',
			);
			continue;
		}

		// 'code_b64' wins over content/code when present (WAF-safe transport, issue #8).
		if ( isset( $item['code_b64'] ) ) {
			$body = rr_decode_snippet_b64( $item['code_b64'] );
			if ( null === $body ) {
				$errors[] = array(
					'index' => $idx,
					'error' => 'code_b64 must be valid base64 that decodes to UTF-8 content',
				);
				continue;
			}
		} else {
			$body = isset( $item['content'] ) ? $item['content'] : ( isset( $item['code'] ) ? $item['code'] : null );
		}
		if ( null === $body || '' === (string) $body ) {
			$errors[] = array(
				'index' => $idx,
				'error' => 'content, code, or base64-encoded code_b64 is required',
			);
			continue;
		}

		$display_on_val = sanitize_text_field( $item['display_on'] ?? 'entire_website' );
		if ( '' !== $display_on_val && ! rr_validate_display_on( $display_on_val ) ) {
			$errors[] = array(
				'index' => $idx,
				'error' => "invalid display_on: '{$display_on_val}'",
			);
			continue;
		}

		$base_id = sanitize_title( $title );
		$id      = $base_id;
		$attempt = 1;
		while ( isset( $existing[ $id ] ) || isset( $prepared[ $id ] ) ) {
			$id = $base_id . '_' . $attempt;
			++$attempt;
		}

		$user_filter_val = sanitize_text_field( (string) ( $item['display_on_user'] ?? 'all' ) );
		if ( ! in_array( $user_filter_val, array( 'all', 'anonymous', 'logged_in' ), true ) ) {
			$user_filter_val = 'all';
		}

		$prepared[ $id ] = array(
			'id'              => $id,
			'title'           => $title,
			'content'         => (string) $body,
			'location'        => sanitize_text_field( $item['location'] ?? 'head' ),
			'display_on'      => $display_on_val,
			'display_on_user' => $user_filter_val,
			'status'          => sanitize_text_field( $item['status'] ?? 'active' ),
			'created_at'      => $ts,
			'updated_at'      => $ts,
		);

		if ( isset( $item['priority'] ) ) {
			$priority_val = rr_validate_snippet_priority( $item['priority'] );
			if ( null === $priority_val ) {
				$errors[] = array(
					'index' => $idx,
					'error' => 'priority must be an integer between 0 and ' . RR_SNIPPET_PRIORITY_MAX,
				);
				unset( $prepared[ $id ] );
				continue;
			}
			$prepared[ $id ]['priority'] = $priority_val;
		}
	}

	if ( ! empty( $errors ) ) {
		return new WP_Error(
			'validation_failed',
			'One or more snippets failed validation. No snippets were saved.',
			array(
				'status' => 422,
				'errors' => $errors,
			)
		);
	}

	if ( ! $dry_run ) {
		update_option( RMB_SNIPPETS_KEY, array_merge( $existing, $prepared ) );
		rrseo_bust_option_cache( RMB_SNIPPETS_KEY );
		rrseo_purge_rest_cache( array( 'status', 'snippets' ) );
	}

	return rest_ensure_response(
		array(
			'success'  => true,
			'dry_run'  => $dry_run,
			'count'    => count( $prepared ),
			'snippets' => array_values( $prepared ),
		)
	);
}

/**
 * Handles GET /sitemap/exclusions — returns the current sitemap exclusion config.
 *
 * @param WP_REST_Request $request REST request object.
 * @return WP_REST_Response
 */
function rmb_sitemap_exclusions_get( WP_REST_Request $request ) {
	// phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.Found
	$defaults = array(
		'excluded_term_ids'   => array(),
		'excluded_term_slugs' => array(),
		'excluded_taxonomies' => array(),
		'excluded_post_slugs' => array(),
	);
	$config   = get_option( RR_SITEMAP_EXCLUSIONS_KEY, array() );
	return rest_ensure_response( array_merge( $defaults, $config ) );
}

/**
 * Handles POST /sitemap/exclusions — updates the sitemap exclusion config.
 *
 * All four arrays are optional; omitted keys are left unchanged.
 * excluded_post_slugs is applied immediately to rr_is_url_allowed_for_discovery().
 * excluded_term_ids, excluded_term_slugs, and excluded_taxonomies are stored for
 * when taxonomy archive support is added to the sitemap/llms.txt generators.
 *
 * @param WP_REST_Request $request REST request object.
 * @return WP_REST_Response
 */
function rmb_sitemap_exclusions_update( WP_REST_Request $request ) {
	$config = get_option( RR_SITEMAP_EXCLUSIONS_KEY, array() );

	$int_lists    = array( 'excluded_term_ids' );
	$string_lists = array( 'excluded_term_slugs', 'excluded_taxonomies', 'excluded_post_slugs' );

	foreach ( $int_lists as $key ) {
		$val = $request->get_param( $key );
		if ( null !== $val && is_array( $val ) ) {
			$config[ $key ] = array_values( array_map( 'absint', $val ) );
		}
	}
	foreach ( $string_lists as $key ) {
		$val = $request->get_param( $key );
		if ( null !== $val && is_array( $val ) ) {
			$config[ $key ] = array_values( array_map( 'sanitize_text_field', $val ) );
		}
	}

	update_option( RR_SITEMAP_EXCLUSIONS_KEY, $config );
	rrseo_bust_option_cache( RR_SITEMAP_EXCLUSIONS_KEY );
	rrseo_purge_rest_cache( array( 'status' ) );
	rr_invalidate_canonical_cache();

	return rest_ensure_response(
		array(
			'success' => true,
			'config'  => $config,
		)
	);
}

/**
 * Handles DELETE /snippets/{id} — removes a snippet.
 *
 * @param WP_REST_Request $request REST request object.
 * @return WP_REST_Response|WP_Error
 */
function rmb_snippets_delete( WP_REST_Request $request ) {
	$snippets = get_option( RMB_SNIPPETS_KEY, array() );
	$id       = $request->get_param( 'id' );

	if ( ! isset( $snippets[ $id ] ) ) {
		return new WP_Error( 'not_found', "Snippet '{$id}' not found", array( 'status' => 404 ) );
	}

	$deleted = $snippets[ $id ];
	unset( $snippets[ $id ] );
	update_option( RMB_SNIPPETS_KEY, $snippets );
	rrseo_bust_option_cache( RMB_SNIPPETS_KEY );
	rrseo_purge_rest_cache( array( 'status', 'snippets' ) );

	return rest_ensure_response(
		array(
			'success'    => true,
			'deleted_id' => $id,
			'deleted'    => $deleted,
		)
	);
}


// ── Cache Purge ───────────────────────────────────────────────────────────────
/**
 * Handles POST /cache/purge — clears all known cache layers.
 *
 * @param WP_REST_Request $request REST request object.
 * @return WP_REST_Response
 */
function rmb_cache_purge( WP_REST_Request $request ) {
	// phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.Found
	$purged = array();
	$errors = array();

	// Always flush the WordPress object cache first so subsequent get_option()
	// calls read from the DB rather than a stale in-memory or persistent cache.
	wp_cache_flush();
	$purged[] = 'WordPress object cache';

	if ( class_exists( '\LiteSpeed\Purge' ) ) {
		do_action( 'litespeed_purge_all' );
		$purged[] = 'LiteSpeed';
	}

	if ( class_exists( 'Breeze_Admin' ) || function_exists( 'breeze_flush_cache' ) ) {
		do_action( 'breeze_clear_all_cache' );
		$purged[] = 'Breeze';
	}

	$site_url        = get_site_url();
	$host            = wp_parse_url( $site_url, PHP_URL_HOST );
	$varnish_targets = array( 'http://localhost/.*', 'http://127.0.0.1/.*' );
	foreach ( $varnish_targets as $target ) {
		$response = wp_remote_request(
			$target,
			array(
				'method'    => 'PURGE',
				'timeout'   => 5,
				'headers'   => array(
					'Host'           => $host,
					'X-Purge-Method' => 'regex',
				),
				'sslverify' => false,
			)
		);
		if ( ! is_wp_error( $response ) ) {
			$code = wp_remote_retrieve_response_code( $response );
			if ( in_array( $code, array( 200, 201, 204, 404 ), true ) ) {
				if ( ! in_array( 'Varnish', $purged, true ) ) {
					$purged[] = 'Varnish';
				}
				break;
			} else {
				$errors[] = 'Varnish HTTP ' . $code;
			}
		} else {
			$errors[] = 'Varnish: ' . $response->get_error_message();
		}
	}

	if ( function_exists( 'sg_cachepress_purge_cache' ) ) {
		sg_cachepress_purge_cache();
		$purged[] = 'SiteGround';
	}
	if ( function_exists( 'rocket_clean_domain' ) ) {
		rocket_clean_domain();
		$purged[] = 'WP Rocket';
	}
	if ( function_exists( 'w3tc_flush_all' ) ) {
		w3tc_flush_all();
		$purged[] = 'W3TC';
	}

	$msg_parts = array();
	if ( ! empty( $purged ) ) {
		$msg_parts[] = 'Purged: ' . implode( ', ', $purged );
	}
	if ( ! empty( $errors ) ) {
		$msg_parts[] = 'Errors: ' . implode( '; ', $errors );
	}

	return rest_ensure_response(
		array(
			'success' => true,
			'purged'  => $purged,
			'errors'  => $errors,
			'message' => empty( $msg_parts ) ? 'No supported cache plugin detected' : implode( ' | ', $msg_parts ),
		)
	);
}


// ── Status ────────────────────────────────────────────────────────────────────
/**
 * Handles GET /status — returns plugin health and configuration summary.
 *
 * @param WP_REST_Request $request REST request object.
 * @return WP_REST_Response
 */
function rmb_status( WP_REST_Request $request ) {
	$snippets    = get_option( RMB_SNIPPETS_KEY, array() );
	$rankmath_on = class_exists( 'RankMath' );
	$site_url    = rtrim( get_bloginfo( 'url' ), '/' );
	$robots_path = ABSPATH . 'robots.txt';
	clearstatcache( true, $robots_path );
	$physical_robots_file = file_exists( $robots_path );
	$robots_managed       = '' !== (string) get_option( 'rrseo_robots_txt', '' ) && $physical_robots_file;

	$status_warnings = array();
	if ( $physical_robots_file && ! $robots_managed ) {
		$status_warnings[] = array(
			'code'    => 'physical_robots_txt_bypass',
			'message' => 'A physical robots.txt file exists and may bypass RankRocket robots.txt output.',
		);
	}

	$response = array(
		'plugin'                     => 'RankRocket SEO Control Layer',
		'version'                    => RMB_VERSION,
		'namespace'                  => 'rankrocket-seo/v1',
		'rankmath_active'            => $rankmath_on,
		'sitemap_index_url'          => $site_url . '/sitemap_index.xml',
		'legacy_sitemap_url'         => $site_url . '/rmb-sitemap.xml',
		'llms_url'                   => $site_url . '/llms.txt',
		'robots_txt_url'             => $site_url . '/robots.txt',
		'physical_robots_txt_exists' => $physical_robots_file,
		'robots_txt_auto_sync'       => (bool) get_option( 'rrseo_robots_txt_auto_sync', true ),
		'consolidate_wp_robots'      => (bool) get_option( 'rrseo_consolidate_wp_robots', true ),
		'consolidate_canonical'      => (bool) get_option( 'rrseo_consolidate_canonical', true ),
		'emit_snippets'              => (bool) get_option( 'rrseo_emit_snippets', true ),
		'emit_routing_version'       => 2,
		'perf_dequeue_rules_count'   => count( (array) get_option( RR_PERF_DEQUEUE_KEY, array() ) ),
		'perf_defer_handles_count'   => count( (array) get_option( RR_PERF_DEFER_KEY, array() ) ),
		'snippet_count'              => count( $snippets ),
		'snippet_ids'                => array_keys( $snippets ),
		'update_url'                 => RMB_UPDATE_URL,
		'php_version'                => PHP_VERSION,
		'wp_version'                 => get_bloginfo( 'version' ),
		'allowed_post_types'         => apply_filters( 'rrseo_allowed_post_types', RR_ALLOWED_POST_TYPES ),
		'allowed_schema_types'       => apply_filters( 'rrseo_allowed_schema_types', RR_ALLOWED_SCHEMA_TYPES ),
		'warnings'                   => $status_warnings,
	);

	// Optional canonical URL counts — transient-cached; computed on demand only.
	if ( $request->get_param( 'include_counts' ) ) {
		$counts = get_transient( 'rrseo_canonical_counts' );
		if ( false === $counts ) {
			$canonical = rr_get_canonical_url_set();
			$counts    = array(
				'canonical_url_count' => count( $canonical['urls'] ),
				'excluded_url_count'  => count( $canonical['excluded'] ),
				'llms_url_count'      => count( $canonical['urls'] ),
			);
			set_transient( 'rrseo_canonical_counts', $counts, 12 * HOUR_IN_SECONDS );
		}
		$response = array_merge( $response, $counts );

		if ( $counts['canonical_url_count'] !== $counts['llms_url_count'] ) {
			$response['warnings'][] = array(
				'code'    => 'canonical_llms_mismatch',
				'message' => 'Canonical URL count and llms URL count differ.',
			);
		}
	}

	return rest_ensure_response( $response );
}


// ── Capabilities ─────────────────────────────────────────────────────────────
/**
 * Returns the plugin's capability map: dotted, stable feature keys mapped
 * to availability, the route that implements them, the version they
 * shipped in, and (for anything not yet available) the tracking issue.
 *
 * `since` is `null` for routes that predate this plugin's earliest tracked
 * CHANGELOG entry (v2.11.3) — the exact introducing version isn't
 * reliably known, so it's left unset rather than guessed.
 *
 * @return array<string, array{available: bool, route: string, since: string|null, issue?: string}>
 */
function rr_get_capabilities_map() {
	return array(
		'seo.meta.update'          => array(
			'available' => true,
			'route'     => 'POST /update',
			'since'     => null,
		),
		'seo.meta.get'             => array(
			'available' => true,
			'route'     => 'GET /get/{id}',
			'since'     => null,
		),
		'seo.meta.bulk_update'     => array(
			'available' => true,
			'route'     => 'POST /meta/bulk-update',
			'since'     => null,
		),
		'images.alt.update'        => array(
			'available' => true,
			'route'     => 'POST /images/{id}/alt',
			'since'     => null,
		),
		'schema.write.single_node' => array(
			'available' => true,
			'route'     => 'POST /schema/{post_id}',
			'since'     => null,
		),
		'schema.write.graph'       => array(
			'available' => true,
			'route'     => 'POST /schema/{post_id} (bare array or @graph envelope)',
			'since'     => '3.5.0',
		),
		'media.upload'             => array(
			'available' => true,
			'route'     => 'POST /media',
			'since'     => '3.6.0',
		),
		'elementor.set_data'       => array(
			'available' => true,
			'route'     => 'POST /elementor/set-data',
			'since'     => '3.7.0',
		),
		'llms.write'               => array(
			'available' => true,
			'route'     => 'POST /llms',
			'since'     => null,
		),
		'llms.business_facts'      => array(
			'available' => true,
			'route'     => 'POST /llms (business_facts)',
			'since'     => '3.4.0',
		),
		'snippets.set'             => array(
			'available' => true,
			'route'     => 'POST /snippets',
			'since'     => null,
		),
		'snippets.bulk_create'     => array(
			'available' => true,
			'route'     => 'POST /snippets/bulk',
			'since'     => null,
		),
		'actions.execute'          => array(
			'available' => true,
			'route'     => 'POST /actions/execute',
			'since'     => null,
		),
		'actions.rollback'         => array(
			'available' => true,
			'route'     => 'POST /actions/{action_id}/rollback',
			'since'     => null,
		),
		'aeo_geo.readiness'        => array(
			'available' => true,
			'route'     => 'GET /aeo-geo/readiness',
			'since'     => null,
		),
		'redirects.list'           => array(
			'available' => true,
			'route'     => 'GET /redirects',
			'since'     => '3.9.0',
		),
		'redirects.write'          => array(
			'available' => true,
			'route'     => 'POST /redirects',
			'since'     => '3.9.0',
		),
		'observe.agentic_browsing' => array(
			'available' => true,
			'route'     => 'GET /observe/agentic-browsing/{post_id}',
			'since'     => '3.10.0',
		),
		'schema.strip_third_party' => array(
			'available' => true,
			'route'     => 'POST /schema/{post_id} (strip_third_party)',
			'since'     => '3.11.0',
		),
	);
}

/**
 * Handles GET /capabilities — machine-readable route inventory and version
 * manifest, recommended as the first call for any new integration so a
 * consumer can probe what this plugin build supports in one round trip
 * instead of per-route OPTIONS calls or trial-and-error POSTs.
 *
 * Pure read, no side effects; response is cacheable for a short window.
 *
 * @param WP_REST_Request $request REST request object.
 * @return WP_REST_Response
 */
function rmb_capabilities_get( WP_REST_Request $request ) {
	unset( $request );

	$response = rest_ensure_response(
		array(
			'plugin_version'       => RMB_VERSION,
			'plugin_namespace'     => 'rankrocket-seo/v1',
			'wp_version'           => get_bloginfo( 'version' ),
			'elementor_active'     => class_exists( '\Elementor\Plugin' ),
			'elementor_pro_active' => class_exists( '\ElementorPro\Plugin' ),
			'rank_math_active'     => class_exists( 'RankMath' ),
			'capabilities'         => rr_get_capabilities_map(),
			'allowed_schema_types' => apply_filters( 'rrseo_allowed_schema_types', RR_ALLOWED_SCHEMA_TYPES ),
			'audit_log_enabled'    => true,
		)
	);
	$response->header( 'Cache-Control', 'public, max-age=60' );

	return $response;
}

// WordPress core forces `Cache-Control: no-cache, must-revalidate, max-age=0`
// on every authenticated REST response regardless of what the response
// object's own header says (confirmed live on two unrelated hosting
// stacks -- issue #17). rmb_capabilities_get()'s own $response->header()
// call is overridden downstream by the time WP_REST_Server sends headers.
// rest_pre_serve_request is the latest filter in the dispatch cycle, right
// before output is echoed, so a raw header() call here reliably wins.
add_filter(
	'rest_pre_serve_request',
	function ( $served, $result, $request ) {
		if ( is_a( $request, 'WP_REST_Request' ) && '/rankrocket-seo/v1/capabilities' === $request->get_route() ) {
			header( 'Cache-Control: public, max-age=60' );
		}
		return $served;
	},
	10,
	3
);

/**
 * Handles POST /check-updates — clears the WordPress and PUC update-check caches.
 *
 * WordPress caches the update-check result in the update_plugins site transient for
 * 12 hours. PUC stores its own last-check timestamp in a site option. Both must be
 * cleared before WordPress will fetch the manifest and detect new versions.
 *
 * This endpoint is the server-side equivalent of clicking "Check Again" on the
 * WordPress Dashboard > Updates page, with the addition of clearing PUC's own state.
 *
 * @param WP_REST_Request $request REST request object.
 * @return WP_REST_Response
 */
function rmb_check_updates( WP_REST_Request $request ): WP_REST_Response {
	// phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.Found
	// Clear PUC's cached state so the next check fetches a fresh manifest.
	// We do NOT touch update_plugins site transient — that would trigger
	// WordPress.org communication for all plugins, which is wrong for a private plugin.
	delete_site_option( 'external_updates-rankmath-rest-bridge' );

	// Trigger an immediate fetch of our private GitHub manifest via PUC.
	// This contacts only our own manifest URL, never WordPress.org.
	$message = 'You are running the latest version.';
	if ( isset( $GLOBALS['rrseo_puc_checker'] ) ) {
		$update = $GLOBALS['rrseo_puc_checker']->checkForUpdates();
		if ( $update && ! empty( $update->version ) ) {
			$message = 'Version ' . sanitize_text_field( $update->version ) . ' is available. Visit Dashboard > Updates to install.';
		}
	}

	return rest_ensure_response(
		array(
			'success' => true,
			'message' => $message,
		)
	);
}


// ── Legacy Migration Handler ──────────────────────────────────────────────────
/**
 * Handles POST /migrate-legacy — copies rank_math_* meta into rr_seo_* keys.
 *
 * Skips fields where the native key is already populated. Supports dry_run:true
 * to preview migrations without writing. All writes are recorded in the audit log.
 *
 * @param WP_REST_Request $request REST request object.
 * @return WP_REST_Response|WP_Error
 */
function rmb_migrate_legacy( WP_REST_Request $request ) {
	$post_ids   = array_map( 'intval', (array) $request->get_param( 'post_ids' ) );
	$dry_run    = (bool) $request->get_param( 'dry_run' );
	$request_id = rr_request_id( $request );

	if ( count( $post_ids ) > rrseo_batch_max() ) {
		return new WP_Error(
			'batch_too_large',
			'Batch size exceeds maximum of ' . rrseo_batch_max(),
			array( 'status' => 422 )
		);
	}

	$results = array();

	foreach ( $post_ids as $post_id ) {
		$post = get_post( $post_id );
		if ( ! $post ) {
			$results[] = array(
				'post_id'  => $post_id,
				'status'   => 'skipped',
				'reason'   => 'post not found',
				'migrated' => array(),
				'skipped'  => array(),
			);
			continue;
		}

		$allowed_types = apply_filters( 'rrseo_allowed_post_types', RR_ALLOWED_POST_TYPES );
		if ( ! in_array( $post->post_type, $allowed_types, true ) ) {
			$results[] = array(
				'post_id'  => $post_id,
				'status'   => 'skipped',
				'reason'   => "post type '{$post->post_type}' not in allowed list",
				'migrated' => array(),
				'skipped'  => array(),
			);
			continue;
		}

		$migrated       = array();
		$skipped_fields = array();
		$audit_changes  = array();

		foreach ( RR_SEO_META_KEYS as $field => $native_key ) {
			$legacy_key   = RR_SEO_LEGACY_META_KEYS[ $field ];
			$native_value = get_post_meta( $post_id, $native_key, true );
			$legacy_value = get_post_meta( $post_id, $legacy_key, true );

			if ( '' !== $native_value && false !== $native_value ) {
				$skipped_fields[ $field ] = array(
					'reason' => 'native key already set',
					'value'  => $native_value,
				);
				continue;
			}

			if ( '' === $legacy_value || false === $legacy_value ) {
				$skipped_fields[ $field ] = array( 'reason' => 'no legacy value found' );
				continue;
			}

			// Reject RankMath template tokens (%title%, %sitename%, %excerpt%, etc.).
			// Migrating literal token strings produces broken meta; callers must
			// write real values manually for these fields.
			if ( preg_match( '/%[a-z_]+%/', (string) $legacy_value ) ) {
				$skipped_fields[ $field ] = array(
					'reason' => 'skipped_due_to_template_token',
					'value'  => $legacy_value,
				);
				continue;
			}

			if ( ! $dry_run ) {
				update_post_meta( $post_id, $native_key, $legacy_value );
			}

			$migrated[ $field ]      = array(
				'from_key' => $legacy_key,
				'value'    => $legacy_value,
			);
			$audit_changes[ $field ] = array(
				'before' => '',
				'after'  => $legacy_value,
			);
		}

		if ( ! $dry_run && ! empty( $audit_changes ) ) {
			rr_audit_log( $post_id, '/migrate-legacy', $audit_changes, $request_id, 'migrated' );
			wp_cache_delete( $post_id, 'post_meta' );
			clean_post_cache( $post_id );
		}

		$post_status = 'skipped';
		if ( ! empty( $migrated ) ) {
			$post_status = $dry_run ? 'would_migrate' : 'migrated';
		}

		$results[] = array(
			'post_id'  => $post_id,
			'status'   => $post_status,
			'migrated' => $migrated,
			'skipped'  => $skipped_fields,
		);
	}

	$migrated_count      = count( array_filter( $results, fn( $r ) => 'migrated' === $r['status'] ) );
	$would_migrate_count = count( array_filter( $results, fn( $r ) => 'would_migrate' === $r['status'] ) );
	$skipped_count       = count( array_filter( $results, fn( $r ) => 'skipped' === $r['status'] ) );

	return rest_ensure_response(
		array(
			'dry_run'        => $dry_run,
			'post_count'     => count( $results ),
			'migrated_count' => $dry_run ? $would_migrate_count : $migrated_count,
			'skipped_count'  => $skipped_count,
			'results'        => $results,
		)
	);
}


// ── Self-Update ───────────────────────────────────────────────────────────────
// POST /wp-json/rankrocket-seo/v1/self-update — zip_url defaults to the GitHub manifest.
add_action(
	'rest_api_init',
	function () {
		$admin_only = function () {
			return current_user_can( 'manage_options' );
		};

		register_rest_route(
			'rankrocket-seo/v1',
			'/self-update',
			array(
				'methods'             => 'POST',
				'callback'            => 'rmb_self_update',
				'permission_callback' => $admin_only,
				'args'                => array(
					'zip_url' => array(
						'required' => false,
						'type'     => 'string',
					),
				),
			)
		);
	}
);

/**
 * Handles POST /self-update — downloads and installs a new plugin zip.
 *
 * Uses the download_url from update-manifest.json when no explicit zip_url is provided.
 *
 * @param WP_REST_Request $request REST request object.
 * @return WP_REST_Response|WP_Error
 */
function rmb_self_update( WP_REST_Request $request ) {
	require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
	require_once ABSPATH . 'wp-admin/includes/misc.php';
	require_once ABSPATH . 'wp-admin/includes/file.php';
	require_once ABSPATH . 'wp-admin/includes/plugin.php';

	$zip_url = $request->get_param( 'zip_url' );
	if ( ! $zip_url ) {
		$manifest = wp_remote_get( RMB_UPDATE_URL, array( 'timeout' => 15 ) );
		if ( is_wp_error( $manifest ) ) {
			return new WP_Error( 'manifest_fetch_failed', $manifest->get_error_message(), array( 'status' => 500 ) );
		}
		$manifest_data = json_decode( wp_remote_retrieve_body( $manifest ), true );
		$zip_url       = $manifest_data['download_url'] ?? null;
		$remote_ver    = $manifest_data['version'] ?? 'unknown';
	} else {
		$remote_ver = 'provided';
	}

	if ( ! $zip_url ) {
		return new WP_Error( 'no_zip_url', 'Could not determine zip URL from manifest', array( 'status' => 500 ) );
	}

	$current_ver = RMB_VERSION;

	$plugins_dir = WP_PLUGIN_DIR;
	$old_copies  = array( 'rankmath-rest-bridge', 'rankrocket-seo' );
	foreach ( $old_copies as $folder ) {
		$path            = "{$plugins_dir}/{$folder}";
		$plugin_dir_path = WP_PLUGIN_DIR . '/' . dirname( RMB_PLUGIN_FILE );
		if ( is_dir( $path ) && $plugin_dir_path !== $path ) {
			$active = WP_PLUGIN_DIR . '/' . plugin_basename( RMB_PLUGIN_FILE );
			if ( realpath( $path ) !== realpath( dirname( $active ) ) ) {
				WP_Filesystem();
				global $wp_filesystem;
				if ( $wp_filesystem ) {
					$wp_filesystem->delete( $path, true );
				}
			}
		}
	}

	$skin     = new WP_Ajax_Upgrader_Skin();
	$upgrader = new Plugin_Upgrader( $skin );
	$result   = $upgrader->install( esc_url_raw( $zip_url ), array( 'overwrite_package' => true ) );

	if ( is_wp_error( $result ) ) {
		return new WP_Error( 'upgrade_failed', $result->get_error_message(), array( 'status' => 500 ) );
	}

	if ( false === $result ) {
		return new WP_Error( 'upgrade_failed', 'Upgrader returned false — check filesystem permissions', array( 'status' => 500 ) );
	}

	// GitHub repo folder name is the active disk slug.
	$plugin_file = 'rankmath-rest-bridge/rankmath-rest-bridge.php';
	if ( ! is_plugin_active( $plugin_file ) ) {
		activate_plugin( $plugin_file );
	}

	// Re-read the freshly-installed version from disk before reporting success
	// (issue #20). RMB_VERSION is a PHP constant compiled from whatever was
	// loaded at the start of this request, so it cannot be used to verify a
	// write that just happened in the same request -- only a fresh file read
	// can confirm the install actually persisted (filesystem permissions and
	// host-level deploy sync have both been observed to silently no-op the
	// upgrader's write on some hosts).
	$installed_data = get_plugin_data( WP_PLUGIN_DIR . '/' . $plugin_file, false, false );
	$installed_ver  = ( isset( $installed_data['Version'] ) && '' !== $installed_data['Version'] )
		? $installed_data['Version']
		: null;

	if ( null === $installed_ver ) {
		return new WP_Error(
			'update_verification_failed',
			'The upgrader reported success but the installed plugin file could not be read back to confirm its version. Check filesystem permissions.',
			array(
				'status'  => 500,
				'zip_url' => $zip_url,
			)
		);
	}

	// An explicitly-provided zip_url has no known expected version to compare
	// against; only the manifest path resolves a real $remote_ver to check.
	if ( 'provided' !== $remote_ver && $installed_ver !== $remote_ver ) {
		return new WP_Error(
			'update_did_not_persist',
			"Upgrader reported success but the installed version ({$installed_ver}) does not match the expected"
				. " version ({$remote_ver}). The write may not have persisted -- check filesystem permissions or"
				. ' host-level deploy sync.',
			array(
				'status'            => 500,
				'installed_version' => $installed_ver,
				'expected_version'  => $remote_ver,
			)
		);
	}

	return rest_ensure_response(
		array(
			'success'      => true,
			'from_version' => $current_ver,
			'to_version'   => $installed_ver,
			'zip_url'      => $zip_url,
			'message'      => "Updated from {$current_ver} to {$installed_ver}. Plugin re-activated.",
		)
	);
}
