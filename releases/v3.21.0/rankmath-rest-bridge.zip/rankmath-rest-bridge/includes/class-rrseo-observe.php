<?php
/**
 * Module/Script Name: RankRocket SEO — Observation Endpoints (v3.0 Bite 1)
 * Path: includes/class-rrseo-observe.php
 *
 * Description:
 * Read-only observation endpoints that export structured WordPress-resident
 * signals for the external Audit Engine: heading hierarchy, link inventory,
 * image ALT coverage, per-post schema graph, and llms.txt drift. None of these
 * endpoints mutate state and none perform external HTTP calls — external link
 * verification is the Audit Engine's job (see docs/plugin-v3-executor-spec.md).
 * The one exception is heading-hierarchy, which can fetch the post's own
 * public permalink (same host only, unauthenticated) to see the full document.
 *
 * Author(s):
 * Rank Rocket Co (C) Copyright 2026 - All Rights Reserved
 *
 * Created Date: 2026-07-06
 * Last Modified Date: 2026-10-01
 *
 * Comments:
 * v1.00 - Initial release. Five GET /observe/* endpoints per the Shape B spec.
 * v1.01 - GET /observe/agentic-browsing/{post_id} (issue #24): 3 static-DOM
 *         checks (primary action, schema completeness, BreadcrumbList
 *         presence) matching PSI's Agentic Browsing sub-audits. Extracted
 *         rr_observe_extract_schema_types() out of rmb_observe_schema_graph()
 *         so both endpoints share one graph-walk implementation.
 * v1.02 - Source-aware heading observation (issue #29): scope/source/complete
 *         metadata, document source via same-host loopback fetch, fragment
 *         H1 absence reported as no_h1_in_fragment, inert-markup stripping.
 * v1.03 - rr_observe_normalize_text(): &nbsp;/Unicode/zero-width-only headings
 *         and links count as empty (empty_heading was missed for &nbsp;).
 *
 * @package RankRocket_SEO
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// ── Pure helpers (unit-testable without WordPress) ────────────────────────────

/**
 * Normalizes rendered text for emptiness checks and display.
 *
 * Decodes entities, then collapses every kind of space -- including the
 * non-breaking space (&nbsp; / U+00A0), other Unicode space separators and
 * zero-width characters that PHP's trim() and \s leave alone -- into single
 * ASCII spaces and trims the result. A heading or link whose only content is
 * &nbsp; is therefore empty, as it is to a visitor.
 *
 * @param string $html_fragment Inner HTML of a heading or link.
 * @return string Normalized plain text.
 */
function rr_observe_normalize_text( string $html_fragment ): string {
	$text = html_entity_decode( wp_strip_all_tags( $html_fragment ), ENT_QUOTES | ENT_HTML5, 'UTF-8' );
	// \p{Z} = Unicode space/line/paragraph separators (includes U+00A0);
	// the explicit class adds zero-width space/joiners and the BOM.
	$collapsed = preg_replace( '/[\s\p{Z}\x{200B}\x{200C}\x{200D}\x{2060}\x{FEFF}]+/u', ' ', $text );
	if ( null === $collapsed ) {
		// Invalid UTF-8: fall back to ASCII whitespace handling.
		$collapsed = preg_replace( '/\s+/', ' ', $text );
	}
	return trim( (string) $collapsed );
}

/**
 * Extracts H1-H6 headings from rendered HTML as a flat ordered list.
 *
 * @param string $html Rendered post content.
 * @return array<int, array{level: int, text: string}> Headings in document order.
 */
function rr_observe_parse_headings( string $html ): array {
	$headings = array();
	if ( '' === trim( $html ) ) {
		return $headings;
	}
	if ( ! preg_match_all( '/<h([1-6])\b[^>]*>(.*?)<\/h\1\s*>/is', $html, $matches, PREG_SET_ORDER ) ) {
		return $headings;
	}
	foreach ( $matches as $m ) {
		$text = rr_observe_normalize_text( $m[2] );

		$headings[] = array(
			'level' => (int) $m[1],
			'text'  => $text,
		);
	}
	return $headings;
}

/**
 * Builds a nested heading tree from a flat heading list.
 *
 * Each node has the shape { tag, text, depth, children } per the v3.0 spec.
 * A heading becomes a child of the nearest preceding heading with a lower
 * level; equal or higher levels pop back up the stack.
 *
 * @param array<int, array{level: int, text: string}> $flat Flat heading list.
 * @return array<int, array> Nested tree of heading nodes.
 */
function rr_observe_build_heading_tree( array $flat ): array {
	$tree  = array();
	$stack = array(); // Each entry: array{ level: int, path: int[] } — path walks children arrays.

	foreach ( $flat as $h ) {
		$top = end( $stack );
		while ( false !== $top && $top['level'] >= $h['level'] ) {
			array_pop( $stack );
			$top = end( $stack );
		}

		$node = array(
			'tag'      => 'h' . $h['level'],
			'text'     => $h['text'],
			'depth'    => $h['level'],
			'children' => array(),
		);

		if ( empty( $stack ) ) {
			$tree[] = $node;
			$path   = array( count( $tree ) - 1 );
		} else {
			$parent_path = $stack[ count( $stack ) - 1 ]['path'];
			$ref         = &$tree;
			foreach ( $parent_path as $idx ) {
				$ref = &$ref[ $idx ]['children'];
			}
			$ref[] = $node;
			$path  = array_merge( $parent_path, array( count( $ref ) - 1 ) );
			unset( $ref );
		}

		$stack[] = array(
			'level' => $h['level'],
			'path'  => $path,
		);
	}

	return $tree;
}

/**
 * Removes markup that can contain heading-like text but is not rendered
 * content: comments, script, style, template and noscript blocks.
 *
 * Applied to full-document HTML before heading extraction so JSON blobs,
 * inline templates and commented-out markup are not counted as headings.
 *
 * @param string $html Full-document HTML.
 * @return string HTML with inert blocks removed.
 */
function rr_observe_strip_inert_markup( string $html ): string {
	$html = (string) preg_replace( '/<!--.*?-->/s', '', $html );
	return (string) preg_replace( '/<(script|style|template|noscript)\b[^>]*>.*?<\/\1\s*>/is', '', $html );
}

/**
 * Derives structural warnings from a flat heading list.
 *
 * Warning codes: no_h1, no_h1_in_fragment, multiple_h1, skipped_level,
 * empty_heading.
 *
 * Scope decides what a missing H1 means. In 'document' scope the headings
 * are the whole page, so zero H1s (even with zero headings at all) is a real
 * 'no_h1'. In 'fragment' scope the headings are only a slice of the page,
 * so a missing H1 is reported as 'no_h1_in_fragment' and never as a claim
 * about the whole page (issue #29).
 *
 * @param array<int, array{level: int, text: string}> $flat  Flat heading list.
 * @param string                                      $scope 'fragment' | 'document'.
 * @return string[] Warning codes (deduplicated, ordered by first occurrence).
 */
function rr_observe_heading_warnings( array $flat, string $scope = 'fragment' ): array {
	$warnings = array();
	$h1_count = 0;
	$prev     = 0;

	foreach ( $flat as $h ) {
		if ( 1 === $h['level'] ) {
			++$h1_count;
		}
		if ( $prev > 0 && $h['level'] > $prev + 1 ) {
			$warnings[] = 'skipped_level';
		}
		if ( '' === $h['text'] ) {
			$warnings[] = 'empty_heading';
		}
		$prev = $h['level'];
	}

	if ( 0 === $h1_count ) {
		if ( 'document' === $scope ) {
			$warnings[] = 'no_h1';
		} elseif ( ! empty( $flat ) ) {
			$warnings[] = 'no_h1_in_fragment';
		}
	}
	if ( $h1_count > 1 ) {
		$warnings[] = 'multiple_h1';
	}

	return array_values( array_unique( $warnings ) );
}

/**
 * Extracts anchor links from rendered HTML.
 *
 * Skips non-navigational schemes (mailto, tel, javascript, data) and
 * fragment-only hrefs. Anchor text is stripped and whitespace-collapsed.
 *
 * @param string $html Rendered post content.
 * @return array<int, array{url: string, anchor_text: string}>
 */
function rr_observe_extract_links( string $html ): array {
	$links = array();
	if ( '' === trim( $html ) ) {
		return $links;
	}
	if ( ! preg_match_all( '/<a\b[^>]*href\s*=\s*(["\'])(.*?)\1[^>]*>(.*?)<\/a\s*>/is', $html, $matches, PREG_SET_ORDER ) ) {
		return $links;
	}
	foreach ( $matches as $m ) {
		$href = trim( html_entity_decode( $m[2], ENT_QUOTES | ENT_HTML5, 'UTF-8' ) );
		if ( '' === $href || '#' === $href[0] ) {
			continue;
		}
		if ( preg_match( '/^(mailto|tel|javascript|data):/i', $href ) ) {
			continue;
		}
		$links[] = array(
			'url'         => $href,
			'anchor_text' => rr_observe_normalize_text( $m[3] ),
		);
	}
	return $links;
}

/**
 * Extracts absolute http(s) URLs from markdown link syntax in llms.txt content.
 *
 * @param string $content Rendered llms.txt markdown.
 * @return string[] URLs in document order (may contain duplicates).
 */
function rr_observe_extract_markdown_urls( string $content ): array {
	if ( ! preg_match_all( '/\]\((https?:\/\/[^)\s]+)\)/i', $content, $matches ) ) {
		return array();
	}
	return $matches[1];
}

/**
 * Normalizes a URL for set comparison: lowercased, trailing slash stripped.
 *
 * @param string $url Absolute URL.
 * @return string
 */
function rr_observe_normalize_compare_url( string $url ): string {
	return strtolower( rtrim( $url, '/' ) );
}

/**
 * Computes the drift between the llms.txt URL list and the canonical URL set.
 *
 * Comparison is normalized (case, trailing slash). Non-page discovery links
 * (the sitemap index) and off-host URLs on the llms side are ignored — llms.txt
 * may legitimately reference external resources the canonical set never contains.
 *
 * @param string[] $llms_urls      URLs extracted from llms.txt content.
 * @param string[] $canonical_urls URLs from rr_get_canonical_url_set().
 * @param string   $home_host      Host of the site URL (lowercased).
 * @return array{ in_both: string[], in_llms_not_canonical: string[], in_canonical_not_llms: string[] }
 */
function rr_observe_diff_url_sets( array $llms_urls, array $canonical_urls, string $home_host ): array {
	$llms_map = array();
	foreach ( $llms_urls as $url ) {
		$host = wp_parse_url( $url, PHP_URL_HOST );
		if ( ! is_string( $host ) || strtolower( $host ) !== $home_host ) {
			continue;
		}
		$path = wp_parse_url( $url, PHP_URL_PATH );
		if ( is_string( $path ) && false !== strpos( $path, 'sitemap_index.xml' ) ) {
			continue;
		}
		$llms_map[ rr_observe_normalize_compare_url( $url ) ] = $url;
	}

	$canonical_map = array();
	foreach ( $canonical_urls as $url ) {
		$canonical_map[ rr_observe_normalize_compare_url( $url ) ] = $url;
	}

	$in_both               = array();
	$in_llms_not_canonical = array();
	$in_canonical_not_llms = array();

	foreach ( $llms_map as $key => $url ) {
		if ( isset( $canonical_map[ $key ] ) ) {
			$in_both[] = $canonical_map[ $key ];
		} else {
			$in_llms_not_canonical[] = $url;
		}
	}
	foreach ( $canonical_map as $key => $url ) {
		if ( ! isset( $llms_map[ $key ] ) ) {
			$in_canonical_not_llms[] = $url;
		}
	}

	return array(
		'in_both'               => $in_both,
		'in_llms_not_canonical' => $in_llms_not_canonical,
		'in_canonical_not_llms' => $in_canonical_not_llms,
	);
}

/**
 * Flattens a stored schema graph (single node or @graph envelope) into a
 * deduplicated list of @type values.
 *
 * @param mixed $graph Value from get_post_meta( $post_id, RR_SCHEMA_META_KEY, true ).
 * @return string[]
 */
function rr_observe_extract_schema_types( $graph ): array {
	if ( empty( $graph ) || ! is_array( $graph ) ) {
		return array();
	}

	// Shared recursive walker: single object, bare array, @graph, nested entities.
	return rr_schema_inventory( $graph )['types'];
}

/**
 * Detects whether rendered HTML exposes a machine-readable primary action:
 * a <form>, an aria-labelled button/link, or an anchor with clear,
 * non-generic link text. Static-DOM heuristic (issue #24 check #1) — does
 * not execute JS or follow links.
 *
 * @param string $html Rendered post content.
 * @return array{status: string, detail: string}
 */
function rr_observe_check_primary_action( string $html ): array {
	if ( '' === trim( $html ) ) {
		return array(
			'status' => 'fail',
			'detail' => 'No rendered content to inspect.',
		);
	}

	if ( preg_match( '/<form\b/i', $html ) ) {
		return array(
			'status' => 'pass',
			'detail' => 'A <form> element was found — forms are an unambiguous machine-readable primary action.',
		);
	}

	if ( preg_match( '/<(a|button)\b[^>]*\baria-label\s*=\s*(["\'])(.*?)\2/is', $html, $m ) ) {
		return array(
			'status' => 'pass',
			'detail' => 'An aria-labelled ' . strtolower( $m[1] ) . ' was found: "' . trim( wp_strip_all_tags( $m[3] ) ) . '".',
		);
	}

	$vague = array( 'click here', 'here', 'more', 'read more', 'learn more', 'submit', 'go' );
	if ( preg_match_all( '/<a\b[^>]*>(.*?)<\/a\s*>/is', $html, $matches ) ) {
		foreach ( $matches[1] as $raw_text ) {
			$text = rr_observe_normalize_text( $raw_text );
			if ( '' === $text || in_array( strtolower( $text ), $vague, true ) ) {
				continue;
			}
			if ( str_word_count( $text ) >= 3 ) {
				return array(
					'status' => 'pass',
					'detail' => 'A link with unambiguous text was found: "' . $text . '".',
				);
			}
		}
	}

	return array(
		'status' => 'fail',
		'detail' => 'No <form>, aria-labelled control, or link with clear action text was found.',
	);
}

/**
 * Checks whether the post declares any substantive schema type (issue #24
 * check #2). A coarse but honest proxy for "structured data matches the
 * page's declared entity type" — this plugin has no independent signal for
 * what a page's entity type "should" be outside of the schema itself.
 *
 * @param string[] $types Schema @type values present on the post (see
 *                         rr_observe_extract_schema_types()).
 * @return array{status: string, detail: string, remediation_hint: string|null}
 */
function rr_observe_check_schema_completeness( array $types ): array {
	if ( empty( $types ) ) {
		return array(
			'status'           => 'fail',
			'detail'           => 'No schema is registered for this post.',
			'remediation_hint' => 'add_schema_via_post_schema_endpoint',
		);
	}
	return array(
		'status'           => 'pass',
		'detail'           => 'Schema present: ' . implode( ', ', $types ) . '.',
		'remediation_hint' => null,
	);
}

/**
 * Checks whether the post's own schema graph includes a BreadcrumbList node
 * — a static-DOM proxy for navigation predictability (issue #24 check #3).
 *
 * @param string[] $types Schema @type values present on the post.
 * @return array{status: string, detail: string, remediation_hint: string|null}
 */
function rr_observe_check_breadcrumb_navigation( array $types ): array {
	if ( in_array( 'BreadcrumbList', $types, true ) ) {
		return array(
			'status'           => 'pass',
			'detail'           => 'BreadcrumbList schema is registered for this post.',
			'remediation_hint' => null,
		);
	}
	return array(
		'status'           => 'fail',
		'detail'           => 'No BreadcrumbList schema was found on this post.',
		'remediation_hint' => 'add_breadcrumblist_via_post_schema_endpoint',
	);
}

// ── Frontend document source (issue #29) ───────────────────────────────────

/**
 * Decides whether a same-site frontend fetch produced usable document HTML.
 *
 * Pure so it is unit-testable. Anything other than a 200 text/html response
 * from the site's own host is an error: the caller must treat it as
 * "document unavailable", never as "page has no headings".
 *
 * @param int    $status       HTTP status code (0 when the request failed).
 * @param string $content_type Content-Type response header.
 * @param string $final_host   Host of the final response URL (after redirects).
 * @param string $home_host    Host of this site.
 * @param string $body         Response body.
 * @return array{html: string|null, error: string|null}
 */
function rr_observe_classify_frontend_response( int $status, string $content_type, string $final_host, string $home_host, string $body ): array {
	if ( 0 === $status ) {
		return array(
			'html'  => null,
			'error' => 'fetch_failed',
		);
	}
	if ( '' !== $final_host && strtolower( $final_host ) !== strtolower( $home_host ) ) {
		return array(
			'html'  => null,
			'error' => 'redirected_off_host',
		);
	}
	if ( 200 !== $status ) {
		return array(
			'html'  => null,
			'error' => 'http_status_' . $status,
		);
	}
	if ( false === stripos( $content_type, 'html' ) || '' === trim( $body ) ) {
		return array(
			'html'  => null,
			'error' => 'not_html',
		);
	}
	return array(
		'html'  => $body,
		'error' => null,
	);
}

// ── Link classification (pure) ────────────────────────────────────────────────

/**
 * Maps a post status to a local link-resolution state.
 *
 * Only publicly viewable statuses count as healthy; a draft/private target
 * must not be reported as a working link just because its post ID resolves.
 *
 * @param string $post_status WordPress post status.
 * @return string 'ok' | 'not_public'
 */
function rr_observe_status_to_resolution( string $post_status ): string {
	return in_array( $post_status, array( 'publish', 'inherit' ), true ) ? 'ok' : 'not_public';
}

/**
 * Builds a link-inventory record for an internal link, or null if healthy.
 *
 * Local resolution never measures HTTP, so every record returned here has
 * status_code null, checked false and verification 'unverified' (issue #31).
 * A local miss that matches an enabled plugin redirect rule is reported as
 * 'redirect_registered' with the rule's target rather than as a candidate
 * broken link.
 *
 * @param array  $link       Link as returned by rr_observe_extract_links().
 * @param string $url        Absolute internal URL.
 * @param int    $source_id  Post ID containing the link.
 * @param string $resolution Result of rr_observe_resolve_internal_url().
 * @param array  $redirects  Redirect rules, as from rr_redirect_list().
 * @return array|null Inventory record, or null when the link resolves publicly.
 */
function rr_observe_internal_link_item( array $link, string $url, int $source_id, string $resolution, array $redirects ): ?array {
	if ( 'ok' === $resolution ) {
		return null;
	}

	$item = array(
		'url'            => $url,
		'status_code'    => null,
		'anchor_text'    => $link['anchor_text'],
		'source_post_id' => $source_id,
		'scope'          => 'internal',
		'resolution'     => $resolution,
		'checked'        => false,
		'verification'   => 'unverified',
	);

	if ( 'not_found' === $resolution ) {
		$rule = rr_redirect_match( rr_redirect_normalize_path( $url ), $redirects );
		if ( null !== $rule ) {
			$item['resolution']      = 'redirect_registered';
			$item['redirect_target'] = (string) $rule['target'];
		}
	}

	return $item;
}

/**
 * Summarizes a link inventory as occurrence and unique-destination counts.
 *
 * Several occurrences of one target are one destination to verify; both
 * counts are kept so a consumer can measure each URL once and still report
 * every source reference.
 *
 * @param array $items Inventory records.
 * @return array{occurrences:int, unique_urls:int}
 */
function rr_observe_link_summary( array $items ): array {
	$urls = array();
	foreach ( $items as $item ) {
		$urls[ (string) $item['url'] ] = true;
	}
	return array(
		'occurrences' => count( $items ),
		'unique_urls' => count( $urls ),
	);
}

// ── WordPress-bound helpers ───────────────────────────────────────────────────

/**
 * Renders a post's content through the_content filters for observation parsing.
 *
 * @param WP_Post $post Post object.
 * @return string Rendered HTML.
 */
function rr_observe_rendered_content( WP_Post $post ): string {
	return (string) apply_filters( 'the_content', $post->post_content );
}

/**
 * Fetches a post's full public frontend document from this site's own host.
 *
 * Stored post content is only a fragment: theme templates, Elementor Theme
 * Builder headers and page-title bars render headings outside it. This
 * requests the post's own permalink so the observer sees what a visitor
 * gets. The target URL comes from the database (never from request input),
 * must be on the site's own host, is fetched unauthenticated (no cookies, no
 * credentials) with a short timeout, a redirect cap and a response size cap,
 * and any off-host redirect, non-200 or non-HTML result is an error.
 *
 * @param WP_Post $post Published post.
 * @return array{html: string|null, error: string|null}
 */
function rr_observe_fetch_frontend_html( WP_Post $post ): array {
	$permalink = get_permalink( $post );
	$home_host = strtolower( (string) wp_parse_url( home_url( '/' ), PHP_URL_HOST ) );
	$host      = is_string( $permalink ) ? wp_parse_url( $permalink, PHP_URL_HOST ) : null;

	if ( ! is_string( $host ) || strtolower( $host ) !== $home_host ) {
		return array(
			'html'  => null,
			'error' => 'bad_permalink',
		);
	}

	$response = wp_safe_remote_get(
		$permalink,
		array(
			'timeout'             => 8,
			'redirection'         => 3,
			'limit_response_size' => 3 * MB_IN_BYTES,
			'headers'             => array( 'Accept' => 'text/html' ),
		)
	);
	if ( is_wp_error( $response ) ) {
		return array(
			'html'  => null,
			'error' => 'fetch_failed',
		);
	}

	$final_url  = '';
	$http_class = isset( $response['http_response'] ) ? $response['http_response'] : null;
	if ( is_object( $http_class ) && method_exists( $http_class, 'get_response_object' ) ) {
		$final_url = (string) $http_class->get_response_object()->url;
	}
	$final_host = (string) wp_parse_url( $final_url, PHP_URL_HOST );

	return rr_observe_classify_frontend_response(
		(int) wp_remote_retrieve_response_code( $response ),
		(string) wp_remote_retrieve_header( $response, 'content-type' ),
		$final_host,
		$home_host,
		(string) wp_remote_retrieve_body( $response )
	);
}

/**
 * Resolves an internal URL against WordPress content without HTTP.
 *
 * Returns 'ok' when the URL maps to a published post/page, 'not_public' when
 * it maps to a post that exists but is not publicly viewable (draft, private,
 * pending, trash), 'unverified' for archive-shaped URLs this helper cannot
 * resolve locally (term/author/date archives), and 'not_found' otherwise.
 *
 * A 'not_found' result is a local lookup miss only. It is NOT a measured HTTP
 * status: WordPress, the host, a CDN, or a third-party plugin can still
 * redirect or serve the URL (issue #31).
 *
 * @param string $url Absolute internal URL.
 * @return string 'ok' | 'not_public' | 'not_found' | 'unverified'
 */
function rr_observe_resolve_internal_url( string $url ): string {
	$path = wp_parse_url( $url, PHP_URL_PATH );
	$path = is_string( $path ) ? $path : '/';

	// A bare site root always resolves. A root path carrying a query string
	// (?p=ID, ?page_id=ID) can still target a specific post, so look it up.
	$is_root = '' === trim( $path, '/' );
	$post_id = ( $is_root && '' === (string) wp_parse_url( $url, PHP_URL_QUERY ) ) ? 0 : url_to_postid( $url );
	if ( $is_root && $post_id <= 0 ) {
		return 'ok';
	}

	if ( $post_id > 0 ) {
		$resolved = get_post( $post_id );
		return $resolved ? rr_observe_status_to_resolution( (string) $resolved->post_status ) : 'not_found';
	}

	// Hierarchical page paths that url_to_postid() sometimes misses.
	$page = get_page_by_path( trim( $path, '/' ), OBJECT, apply_filters( 'rrseo_allowed_post_types', RR_ALLOWED_POST_TYPES ) );
	if ( $page ) {
		return rr_observe_status_to_resolution( (string) $page->post_status );
	}

	// Archive-shaped URLs (term, author, date, feed) cannot be resolved to a
	// post ID locally — report them unverified rather than falsely broken.
	$category_base = (string) get_option( 'category_base' );
	$tag_base      = (string) get_option( 'tag_base' );
	$archive_bases = array_filter(
		array(
			'' !== $category_base ? $category_base : 'category',
			'' !== $tag_base ? $tag_base : 'tag',
			'author',
			'feed',
			'shop',
			'product-category',
			'product-tag',
		)
	);
	$first_segment = strtok( trim( $path, '/' ), '/' );
	if ( in_array( $first_segment, $archive_bases, true ) ) {
		return 'unverified';
	}
	if ( preg_match( '/^\/\d{4}(\/\d{2})?/', $path ) ) {
		return 'unverified';
	}

	return 'not_found';
}

// ── REST handlers ─────────────────────────────────────────────────────────────

/**
 * Handles GET /observe/heading-hierarchy/{post_id} — exports the H1-H6 structure.
 *
 * The `source` parameter picks the evidence: 'document' (the full public
 * page, fetched from this site's own permalink), 'content' (the stored post
 * content rendered through the_content only — a fragment), or 'auto' (the
 * default: document, falling back to content when the fetch fails). The
 * response always reports `scope`, `source` and `complete` so a consumer
 * never has to infer whole-page meaning from the endpoint name (issue #29).
 *
 * @param WP_REST_Request $request REST request object.
 * @return WP_REST_Response|WP_Error
 */
function rmb_observe_heading_hierarchy( WP_REST_Request $request ) {
	$post_id = intval( $request->get_param( 'post_id' ) );
	$post    = get_post( $post_id );
	if ( ! $post || 'publish' !== $post->post_status ) {
		return new WP_Error( 'invalid_post', 'Published post not found', array( 'status' => 404 ) );
	}

	$source = (string) $request->get_param( 'source' );
	if ( ! in_array( $source, array( 'auto', 'document', 'content' ), true ) ) {
		$source = 'auto';
	}

	$html            = null;
	$scope           = 'fragment';
	$evidence        = 'post_content';
	$fallback_reason = null;

	if ( 'content' !== $source ) {
		$fetched = rr_observe_fetch_frontend_html( $post );
		if ( null !== $fetched['html'] ) {
			$html     = rr_observe_strip_inert_markup( $fetched['html'] );
			$scope    = 'document';
			$evidence = 'frontend_html';
		} else {
			$fallback_reason = $fetched['error'];
		}
	}

	if ( null === $html && 'document' !== $source ) {
		$html = rr_observe_rendered_content( $post );
	}

	// Document requested but unavailable: report partial/unverified, never a
	// confirmed absence of headings.
	if ( null === $html ) {
		return new WP_REST_Response(
			array(
				'post_id'       => $post_id,
				'post_title'    => get_the_title( $post ),
				'scope'         => 'document',
				'source'        => 'frontend_html',
				'complete'      => false,
				'verification'  => 'unverified',
				'error'         => $fallback_reason,
				'heading_count' => null,
				'warnings'      => array(),
				'tree'          => array(),
			),
			200
		);
	}

	$flat = rr_observe_parse_headings( $html );

	return new WP_REST_Response(
		array(
			'post_id'         => $post_id,
			'post_title'      => get_the_title( $post ),
			'scope'           => $scope,
			'source'          => $evidence,
			'complete'        => 'document' === $scope,
			'fallback_reason' => $fallback_reason,
			'heading_count'   => count( $flat ),
			'warnings'        => rr_observe_heading_warnings( $flat, $scope ),
			'tree'            => rr_observe_build_heading_tree( $flat ),
		),
		200
	);
}

/**
 * Handles GET /observe/broken-links — paginated internal/external link inventory.
 *
 * Internal links are resolved against WordPress content locally (no HTTP), so
 * a lookup miss is an unverified candidate with status_code null and
 * checked=false, never a measured 404 (issue #31). External links are
 * returned the same way — the Audit Engine performs HTTP verification; the
 * plugin never calls out.
 *
 * @param WP_REST_Request $request REST request object.
 * @return WP_REST_Response
 */
function rmb_observe_broken_links( WP_REST_Request $request ): WP_REST_Response {
	$page             = max( 1, intval( $request->get_param( 'page' ) ) );
	$per_page         = min( 100, max( 1, intval( $request->get_param( 'per_page' ) ) ) );
	$post_type        = (string) $request->get_param( 'post_type' );
	$include_external = (bool) $request->get_param( 'include_external' );

	$allowed_types = apply_filters( 'rrseo_allowed_post_types', RR_ALLOWED_POST_TYPES );
	$types         = ( '' !== $post_type && in_array( $post_type, $allowed_types, true ) )
		? array( $post_type )
		: $allowed_types;

	$query = new WP_Query(
		array(
			'post_type'      => $types,
			'post_status'    => 'publish',
			'posts_per_page' => $per_page,
			'paged'          => $page,
			'orderby'        => 'ID',
			'order'          => 'ASC',
			'fields'         => 'ids',
		)
	);

	$home_host = strtolower( (string) wp_parse_url( home_url( '/' ), PHP_URL_HOST ) );
	$items     = array();
	$redirects = rr_redirect_list();

	foreach ( $query->posts as $source_id ) {
		$post = get_post( $source_id );
		if ( ! $post ) {
			continue;
		}
		$links = rr_observe_extract_links( rr_observe_rendered_content( $post ) );
		foreach ( $links as $link ) {
			$url  = $link['url'];
			$host = wp_parse_url( $url, PHP_URL_HOST );

			// Relative URLs are internal by definition.
			if ( ! is_string( $host ) || '' === $host ) {
				$url  = home_url( '/' === $url[0] ? $url : '/' . $url );
				$host = $home_host;
			}

			if ( strtolower( $host ) === $home_host ) {
				// Healthy internal links yield null and stay out of the inventory.
				$item = rr_observe_internal_link_item( $link, $url, $source_id, rr_observe_resolve_internal_url( $url ), $redirects );
				if ( null !== $item ) {
					$items[] = $item;
				}
			} elseif ( $include_external ) {
				$items[] = array(
					'url'            => $url,
					'status_code'    => null,
					'anchor_text'    => $link['anchor_text'],
					'source_post_id' => $source_id,
					'scope'          => 'external',
					'resolution'     => 'external_unchecked',
					'checked'        => false,
					'verification'   => 'unverified',
				);
			}
		}
	}

	return new WP_REST_Response(
		array(
			'page'        => $page,
			'per_page'    => $per_page,
			'total_posts' => (int) $query->found_posts,
			'total_pages' => (int) $query->max_num_pages,
			'note'        => 'No HTTP requests are made. status_code is always null and checked always false: ' .
				'resolution reflects a local WordPress lookup only, so not_found is a candidate to verify, ' .
				'not a confirmed 404. The Audit Engine performs HTTP verification.',
			'summary'     => rr_observe_link_summary( $items ),
			'links'       => $items,
		),
		200
	);
}

/**
 * Handles GET /observe/alt-coverage — image ALT text rollup by parent post type.
 *
 * 'missing' counts image attachments with no _wp_attachment_image_alt row;
 * 'empty' counts rows that exist but hold an empty string. Results are cached
 * in a 5-minute transient — this is observational data, not a live counter.
 *
 * @param WP_REST_Request $request REST request object.
 * @return WP_REST_Response
 */
function rmb_observe_alt_coverage( WP_REST_Request $request ): WP_REST_Response { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.Found
	$cached = get_transient( 'rrseo_observe_alt_coverage' );
	if ( is_array( $cached ) ) {
		return new WP_REST_Response( $cached, 200 );
	}

	global $wpdb;

	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- aggregate rollup over all attachments; result cached in a transient above.
	$rows = $wpdb->get_results(
		$wpdb->prepare(
			"SELECT COALESCE( parent.post_type, 'unattached' ) AS parent_type, m.meta_value AS alt_value
			 FROM {$wpdb->posts} a
			 LEFT JOIN {$wpdb->posts} parent ON parent.ID = a.post_parent
			 LEFT JOIN {$wpdb->postmeta} m ON m.post_id = a.ID AND m.meta_key = %s
			 WHERE a.post_type = 'attachment' AND a.post_mime_type LIKE %s",
			'_wp_attachment_image_alt',
			$wpdb->esc_like( 'image/' ) . '%'
		)
	);

	$overall = array(
		'total'   => 0,
		'missing' => 0,
		'empty'   => 0,
	);
	$by_type = array();

	foreach ( (array) $rows as $row ) {
		$ptype = (string) $row->parent_type;
		if ( ! isset( $by_type[ $ptype ] ) ) {
			$by_type[ $ptype ] = array(
				'total'   => 0,
				'missing' => 0,
				'empty'   => 0,
			);
		}
		++$overall['total'];
		++$by_type[ $ptype ]['total'];

		if ( null === $row->alt_value ) {
			++$overall['missing'];
			++$by_type[ $ptype ]['missing'];
		} elseif ( '' === trim( (string) $row->alt_value ) ) {
			++$overall['empty'];
			++$by_type[ $ptype ]['empty'];
		}
	}

	$with_pct = function ( array $bucket ): array {
		$covered                = $bucket['total'] - $bucket['missing'] - $bucket['empty'];
		$bucket['coverage_pct'] = $bucket['total'] > 0 ? round( ( $covered / $bucket['total'] ) * 100, 1 ) : 100.0;
		return $bucket;
	};

	$overall = $with_pct( $overall );
	foreach ( $by_type as $ptype => $bucket ) {
		$by_type[ $ptype ] = $with_pct( $bucket );
	}

	$payload = array_merge(
		array( 'generated_at' => gmdate( 'Y-m-d\TH:i:s+00:00' ) ),
		$overall,
		array( 'by_parent_type' => $by_type )
	);

	set_transient( 'rrseo_observe_alt_coverage', $payload, 5 * MINUTE_IN_SECONDS );

	return new WP_REST_Response( $payload, 200 );
}

/**
 * Handles GET /observe/schema-graph/{post_id} — full stored JSON-LD graph.
 *
 * @param WP_REST_Request $request REST request object.
 * @return WP_REST_Response|WP_Error
 */
function rmb_observe_schema_graph( WP_REST_Request $request ) {
	$post_id = intval( $request->get_param( 'post_id' ) );
	if ( ! get_post( $post_id ) ) {
		return new WP_Error( 'invalid_post', 'Post not found', array( 'status' => 404 ) );
	}

	$graph      = get_post_meta( $post_id, RR_SCHEMA_META_KEY, true );
	$has_schema = ! empty( $graph ) && is_array( $graph );
	$types      = $has_schema ? rr_observe_extract_schema_types( $graph ) : array();

	return new WP_REST_Response(
		array(
			'post_id'    => $post_id,
			'has_schema' => $has_schema,
			'types'      => $types,
			'graph'      => $has_schema ? $graph : null,
		),
		200
	);
}

/**
 * Handles GET /observe/llms-diff — drift between llms.txt and the canonical set.
 *
 * @param WP_REST_Request $request REST request object.
 * @return WP_REST_Response
 */
function rmb_observe_llms_diff( WP_REST_Request $request ): WP_REST_Response { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.Found
	$config = get_option( RR_LLMS_CONFIG_KEY, get_option( 'rmb_llms_config', array() ) );
	$render = rr_render_llms_txt( is_array( $config ) ? $config : array() );

	$llms_urls = rr_observe_extract_markdown_urls( $render['content'] );

	$canonical      = rr_get_canonical_url_set();
	$canonical_urls = array();
	foreach ( $canonical['urls'] as $entry ) {
		$canonical_urls[] = (string) $entry['url'];
	}

	$home_host = strtolower( (string) wp_parse_url( home_url( '/' ), PHP_URL_HOST ) );
	$diff      = rr_observe_diff_url_sets( $llms_urls, $canonical_urls, $home_host );

	return new WP_REST_Response(
		array(
			'llms_url_count'        => count( $llms_urls ),
			'canonical_url_count'   => count( $canonical_urls ),
			'in_both'               => $diff['in_both'],
			'in_llms_not_canonical' => $diff['in_llms_not_canonical'],
			'in_canonical_not_llms' => $diff['in_canonical_not_llms'],
			'in_sync'               => empty( $diff['in_llms_not_canonical'] ) && empty( $diff['in_canonical_not_llms'] ),
		),
		200
	);
}

/**
 * Handles GET /observe/agentic-browsing/{post_id} — reports pass/fail on
 * the three publicly documented Agentic Browsing sub-audits (issue #24):
 * machine-readable primary action, schema completeness, and navigation
 * predictability (BreadcrumbList presence). Static-DOM checks only, no JS
 * execution or external network calls, recomputed on every call (no
 * caching, matching the rest of this module).
 *
 * @param WP_REST_Request $request REST request object.
 * @return WP_REST_Response|WP_Error
 */
function rmb_observe_agentic_browsing( WP_REST_Request $request ) {
	$post_id = intval( $request->get_param( 'post_id' ) );
	$post    = get_post( $post_id );
	if ( ! $post || 'publish' !== $post->post_status ) {
		return new WP_Error( 'invalid_post', 'Published post not found', array( 'status' => 404 ) );
	}

	$html  = rr_observe_rendered_content( $post );
	$graph = get_post_meta( $post_id, RR_SCHEMA_META_KEY, true );
	$types = rr_observe_extract_schema_types( $graph );

	$checks = array(
		array_merge(
			array( 'id' => 'primary_action_machine_readable' ),
			rr_observe_check_primary_action( $html )
		),
		array_merge(
			array( 'id' => 'schema_matches_content' ),
			rr_observe_check_schema_completeness( $types )
		),
		array_merge(
			array( 'id' => 'navigation_predictability' ),
			rr_observe_check_breadcrumb_navigation( $types )
		),
	);

	$score = 0;
	foreach ( $checks as $check ) {
		if ( 'pass' === $check['status'] ) {
			++$score;
		}
	}

	return new WP_REST_Response(
		array(
			'post_id'     => $post_id,
			'url'         => get_permalink( $post ),
			'score'       => $score,
			'max_score'   => count( $checks ),
			'checks'      => $checks,
			'measured_at' => gmdate( 'Y-m-d\TH:i:s\Z' ),
		),
		200
	);
}
